package com.ragate;

import com.ragate.config.AppProps;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.scheduling.annotation.EnableAsync;
import java.util.TimeZone;

@SpringBootApplication
@EnableAsync
@EnableConfigurationProperties(AppProps.class)
public class RagateApplication {
    public static void main(String[] args) {
        // Persist and exchange timestamps consistently as UTC across the API and database.
        TimeZone.setDefault(TimeZone.getTimeZone("UTC"));
        SpringApplication.run(RagateApplication.class, args);
    }
}
