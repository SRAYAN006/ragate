package com.ragate.config;

import org.springframework.boot.context.properties.ConfigurationProperties;

@ConfigurationProperties(prefix = "app")
public record AppProps(Jwt jwt, Ml ml, String storage, String corsOrigin, int rateLimitPerMinute) {
    public record Jwt(String secret, long ttlMinutes) {}
    public record Ml(String baseUrl, String apiKey) {}
}
