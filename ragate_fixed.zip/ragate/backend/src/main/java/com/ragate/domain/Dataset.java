package com.ragate.domain;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.JdbcTypeCode;
import org.hibernate.type.SqlTypes;
import java.math.BigDecimal;
import java.time.Instant;
import java.util.*;

@Entity @Table(name = "datasets") @Getter @Setter @NoArgsConstructor
public class Dataset {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private Long ownerId;
    private String name;
    private String source;
    private String symbol;
    private Double intervalSeconds;
    private Integer rowCount;
    private Integer columnCount;
    private Instant startTs;
    private Instant endTs;
    private Double missingPct;
    private String qualityStatus;
    private String status;
    private String uploadPath;
    @Column(columnDefinition = "text")
    private String errorMessage;
    @JdbcTypeCode(SqlTypes.JSON) @Column(columnDefinition = "jsonb")
    private Map<String, Object> mapping;
    @JdbcTypeCode(SqlTypes.JSON) @Column(columnDefinition = "jsonb")
    private Map<String, Object> report;
    @JdbcTypeCode(SqlTypes.JSON) @Column(columnDefinition = "jsonb")
    private List<Object> cleaningLog;
    private Instant createdAt;
}
