package com.ragate.domain;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.JdbcTypeCode;
import org.hibernate.type.SqlTypes;
import java.math.BigDecimal;
import java.time.Instant;
import java.util.*;

@Entity @Table(name = "expert_predictions") @Getter @Setter @NoArgsConstructor
public class ExpertPrediction {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String modelKey;
    private String symbol;
    private String expert;
    private String horizon;
    private Instant asof;
    private Instant targetEnd;
    private Double predictedReturn;
    private Double probPositive;
    private Double uncertainty;
    private Double actualReturn;
    private Double loss;
    private Boolean scored;
    private Instant scoredAt;
    private Instant createdAt;
}
