package com.ragate.domain;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.JdbcTypeCode;
import org.hibernate.type.SqlTypes;
import java.math.BigDecimal;
import java.time.Instant;
import java.util.*;

@Entity @Table(name = "model_registry") @Getter @Setter @NoArgsConstructor
public class ModelRegistryEntry {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String modelKey;
    private Long datasetId;
    private String symbol;
    private Double intervalSeconds;
    private String status;
    @Column(columnDefinition = "text")
    private String error;
    @JdbcTypeCode(SqlTypes.JSON) @Column(columnDefinition = "jsonb")
    private Map<String, Object> metrics;
    @JdbcTypeCode(SqlTypes.JSON) @Column(columnDefinition = "jsonb")
    private Map<String, Object> meta;
    private Long createdBy;
    private Instant createdAt;
}
