package com.ragate.domain;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.JdbcTypeCode;
import org.hibernate.type.SqlTypes;
import java.math.BigDecimal;
import java.time.Instant;
import java.util.*;

@Entity @Table(name = "orders") @Getter @Setter @NoArgsConstructor
public class OrderEntity {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private Long portfolioId;
    private String symbol;
    private String side;
    private BigDecimal quantity;
    private BigDecimal filledQuantity;
    private BigDecimal refPrice;
    private BigDecimal execPrice;
    private BigDecimal fee;
    private BigDecimal slippageCost;
    private String status;
    private String rejectReason;
    private String source;
    private Long decisionId;
    private Long datasetId;
    private Boolean paper;
    private Instant createdAt;
}
