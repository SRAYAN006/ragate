package com.ragate.domain;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.JdbcTypeCode;
import org.hibernate.type.SqlTypes;
import java.math.BigDecimal;
import java.time.Instant;
import java.util.*;

@Entity @Table(name = "portfolios") @Getter @Setter @NoArgsConstructor
public class Portfolio {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private Long ownerId;
    private String name;
    private String baseCurrency;
    private BigDecimal startingBalance;
    private BigDecimal cash;
    private Boolean paperTrading;
    private BigDecimal feeRate;
    private BigDecimal slippageBps;
    private Instant createdAt;
}
