package com.ragate.domain;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.JdbcTypeCode;
import org.hibernate.type.SqlTypes;
import java.math.BigDecimal;
import java.time.Instant;
import java.util.*;

@Entity @Table(name = "portfolio_snapshots") @Getter @Setter @NoArgsConstructor
public class PortfolioSnapshot {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private Long portfolioId;
    private Instant ts;
    private BigDecimal equity;
    private BigDecimal cash;
    private BigDecimal unrealizedPnl;
}
