package com.ragate.repo;

import com.ragate.domain.*;
import org.springframework.data.jpa.repository.JpaRepository;
import java.time.Instant;
import java.util.*;

public interface AppUserRepo extends JpaRepository<AppUser, Long> {
    Optional<AppUser> findByUsername(String u);
    boolean existsByUsername(String u);
    boolean existsByEmail(String e);
}
