package com.ragate.repo;

import com.ragate.domain.*;
import org.springframework.data.jpa.repository.JpaRepository;
import java.time.Instant;
import java.util.*;

public interface BacktestRunRepo extends JpaRepository<BacktestRun, Long> {
    Optional<BacktestRun> findByIdAndOwnerId(Long id,Long o);
    List<BacktestRun> findTop20ByOwnerIdOrderByCreatedAtDesc(Long o);
}
