package com.ragate.repo;

import com.ragate.domain.*;
import org.springframework.data.jpa.repository.JpaRepository;
import java.time.Instant;
import java.util.*;

public interface DatasetRepo extends JpaRepository<Dataset, Long> {
    List<Dataset> findByOwnerIdOrderByCreatedAtDesc(Long o);
}
