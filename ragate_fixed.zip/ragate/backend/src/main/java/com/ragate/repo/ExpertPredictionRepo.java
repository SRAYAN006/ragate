package com.ragate.repo;

import com.ragate.domain.*;
import org.springframework.data.jpa.repository.JpaRepository;
import java.time.Instant;
import java.util.*;

public interface ExpertPredictionRepo extends JpaRepository<ExpertPrediction, Long> {
    boolean existsByModelKeyAndSymbolAndExpertAndHorizonAndAsof(String m,String s,String e,String h,Instant a);
    List<ExpertPrediction> findByModelKeyAndSymbolAndHorizonAndScoredFalseAndTargetEndLessThanEqual(String m,String s,String h,Instant t);
    List<ExpertPrediction> findTop200ByModelKeyAndSymbolOrderByAsofDesc(String m,String s);
}
