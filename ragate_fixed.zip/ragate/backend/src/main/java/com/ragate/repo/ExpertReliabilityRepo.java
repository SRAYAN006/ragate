package com.ragate.repo;

import com.ragate.domain.*;
import org.springframework.data.jpa.repository.JpaRepository;
import java.time.Instant;
import java.util.*;

public interface ExpertReliabilityRepo extends JpaRepository<ExpertReliability, Long> {
    Optional<ExpertReliability> findByModelKeyAndSymbolAndHorizon(String m,String s,String h);
    List<ExpertReliability> findByModelKey(String m);
}
