package com.ragate.repo;

import com.ragate.domain.*;
import org.springframework.data.jpa.repository.JpaRepository;
import java.time.Instant;
import java.util.*;

public interface ModelRegistryEntryRepo extends JpaRepository<ModelRegistryEntry, Long> {
    Optional<ModelRegistryEntry> findByModelKey(String k);
    List<ModelRegistryEntry> findAllByOrderByCreatedAtDesc();
}
