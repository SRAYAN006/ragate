package com.ragate.repo;

import com.ragate.domain.*;
import org.springframework.data.jpa.repository.JpaRepository;
import java.time.Instant;
import java.util.*;

public interface OrderEntityRepo extends JpaRepository<OrderEntity, Long> {
    List<OrderEntity> findTop200ByPortfolioIdOrderByCreatedAtDesc(Long p);
    boolean existsByDecisionIdAndStatus(Long d,String s);
    void deleteByPortfolioId(Long p);
}
