package com.ragate.repo;

import com.ragate.domain.*;
import org.springframework.data.jpa.repository.JpaRepository;
import java.time.Instant;
import java.util.*;

public interface PortfolioRepo extends JpaRepository<Portfolio, Long> {
    Optional<Portfolio> findFirstByOwnerIdOrderByIdAsc(Long o);
    Optional<Portfolio> findByIdAndOwnerId(Long id,Long o);
}
