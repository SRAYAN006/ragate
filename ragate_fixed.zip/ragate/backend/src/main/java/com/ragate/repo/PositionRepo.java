package com.ragate.repo;

import com.ragate.domain.*;
import org.springframework.data.jpa.repository.JpaRepository;
import java.time.Instant;
import java.util.*;

public interface PositionRepo extends JpaRepository<Position, Long> {
    List<Position> findByPortfolioId(Long p);
    Optional<Position> findByPortfolioIdAndSymbol(Long p,String s);
    void deleteByPortfolioId(Long p);
}
