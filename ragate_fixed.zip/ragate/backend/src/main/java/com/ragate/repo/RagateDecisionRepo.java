package com.ragate.repo;

import com.ragate.domain.*;
import org.springframework.data.jpa.repository.JpaRepository;
import java.time.Instant;
import java.util.*;

public interface RagateDecisionRepo extends JpaRepository<RagateDecision, Long> {
    Optional<RagateDecision> findByIdAndUserId(Long id,Long u);
    List<RagateDecision> findTop50ByUserIdOrderByCreatedAtDesc(Long u);
}
