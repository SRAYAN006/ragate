package com.ragate.repo;

import com.ragate.domain.*;
import org.springframework.data.jpa.repository.JpaRepository;
import java.time.Instant;
import java.util.*;

public interface TradeRepo extends JpaRepository<Trade, Long> {
    List<Trade> findTop200ByPortfolioIdOrderByExecutedAtDesc(Long p);
    void deleteByPortfolioId(Long p);
}
