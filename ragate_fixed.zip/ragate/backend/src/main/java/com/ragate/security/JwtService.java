package com.ragate.security;

import com.ragate.config.AppProps;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.security.Keys;
import org.springframework.stereotype.Service;
import javax.crypto.SecretKey;
import java.nio.charset.StandardCharsets;
import java.util.Date;

@Service
public class JwtService {
    private final SecretKey key;
    private final long ttlMs;

    public JwtService(AppProps p) {
        this.key = Keys.hmacShaKeyFor(p.jwt().secret().getBytes(StandardCharsets.UTF_8));
        this.ttlMs = p.jwt().ttlMinutes() * 60_000L;
    }

    public String generate(String username, String role) {
        return Jwts.builder().subject(username).claim("role", role).issuedAt(new Date())
                .expiration(new Date(System.currentTimeMillis() + ttlMs)).signWith(key).compact();
    }

    public Claims parse(String token) {
        return Jwts.parser().verifyWith(key).build().parseSignedClaims(token).getPayload();
    }
}
