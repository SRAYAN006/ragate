package com.ragate.security;

import com.ragate.config.AppProps;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;
import java.io.IOException;
import java.util.ArrayDeque;
import java.util.Deque;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/** Sliding-window limiter per client IP; auth endpoints get a much stricter limit (brute-force protection). */
@Component
public class RateLimitFilter extends OncePerRequestFilter {
    private final Map<String, Deque<Long>> hits = new ConcurrentHashMap<>();
    private final int limit;
    public RateLimitFilter(AppProps p) { this.limit = p.rateLimitPerMinute(); }

    // CORS preflight requests must not consume rate-limit quota or be rejected here.
    @Override
    protected boolean shouldNotFilter(HttpServletRequest request) {
        return "OPTIONS".equalsIgnoreCase(request.getMethod());
    }

    @Override
    protected void doFilterInternal(HttpServletRequest req, HttpServletResponse res, FilterChain chain)
            throws ServletException, IOException {
        boolean auth = req.getRequestURI().startsWith("/api/auth/");
        int max = auth ? 20 : limit;
        String key = req.getRemoteAddr() + (auth ? "|auth" : "");
        long now = System.currentTimeMillis();
        Deque<Long> q = hits.computeIfAbsent(key, k -> new ArrayDeque<>());
        synchronized (q) {
            while (!q.isEmpty() && now - q.peekFirst() > 60_000) q.pollFirst();
            if (q.size() >= max) { res.sendError(429, "Too many requests"); return; }
            q.addLast(now);
        }
        chain.doFilter(req, res);
    }
}
