package com.ragate.service;

import com.ragate.domain.AppUser;
import com.ragate.repo.AppUserRepo;
import com.ragate.security.JwtService;
import org.springframework.http.HttpStatus;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;
import java.time.Instant;
import java.util.Map;

@Service
public class AuthService {
    private final AppUserRepo users; private final PasswordEncoder enc; private final JwtService jwt; private final PaperTradingService paper;

    public AuthService(AppUserRepo users, PasswordEncoder enc, JwtService jwt, PaperTradingService paper) {
        this.users = users; this.enc = enc; this.jwt = jwt; this.paper = paper;
    }

    public Map<String, Object> register(String username, String email, String password) {
        if (users.existsByUsername(username)) throw new ResponseStatusException(HttpStatus.CONFLICT, "Username already taken");
        if (users.existsByEmail(email)) throw new ResponseStatusException(HttpStatus.CONFLICT, "Email already registered");
        AppUser u = new AppUser();
        u.setUsername(username); u.setEmail(email); u.setPasswordHash(enc.encode(password));
        u.setRole(users.count() == 0 ? "ADMIN" : "USER");   // first account administers model training
        u.setCreatedAt(Instant.now());
        users.save(u);
        paper.defaultPortfolio(u.getId());
        return session(u);
    }

    public Map<String, Object> login(String username, String password) {
        AppUser u = users.findByUsername(username).orElseThrow(() -> new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Invalid credentials"));
        if (!enc.matches(password, u.getPasswordHash())) throw new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Invalid credentials");
        return session(u);
    }

    private Map<String, Object> session(AppUser u) {
        return Map.of("token", jwt.generate(u.getUsername(), u.getRole()),
                "user", Map.of("id", u.getId(), "username", u.getUsername(), "email", u.getEmail(), "role", u.getRole()));
    }
}
