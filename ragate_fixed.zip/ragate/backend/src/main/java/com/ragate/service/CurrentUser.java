package com.ragate.service;

import com.ragate.domain.AppUser;
import com.ragate.repo.AppUserRepo;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Component;
import org.springframework.web.server.ResponseStatusException;

@Component
public class CurrentUser {
    private final AppUserRepo users;
    public CurrentUser(AppUserRepo users) { this.users = users; }
    public AppUser get(Authentication a) {
        return users.findByUsername(a.getName()).orElseThrow(() -> new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Unknown user"));
    }
}
