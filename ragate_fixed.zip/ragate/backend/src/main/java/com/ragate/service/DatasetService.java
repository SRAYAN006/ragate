package com.ragate.service;

import com.ragate.config.AppProps;
import com.ragate.domain.AppUser;
import com.ragate.domain.Dataset;
import com.ragate.repo.DatasetRepo;
import org.springframework.http.HttpStatus;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.server.ResponseStatusException;
import java.io.IOException;
import java.nio.file.*;
import java.sql.Timestamp;
import java.time.Instant;
import java.util.*;

@Service
public class DatasetService {
    private static final Set<String> EXT = Set.of("csv", "xlsx", "xls");
    private final DatasetRepo repo; private final MlClient ml; private final JdbcTemplate jdbc; private final Path uploadDir;

    public DatasetService(DatasetRepo repo, MlClient ml, JdbcTemplate jdbc, AppProps p) throws IOException {
        this.repo = repo; this.ml = ml; this.jdbc = jdbc;
        this.uploadDir = Paths.get(p.storage()).toAbsolutePath().normalize().resolve("uploads");
        Files.createDirectories(uploadDir);
    }

    public Dataset get(Long id, AppUser u) {
        Dataset d = repo.findById(id).orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Dataset not found"));
        if (!d.getOwnerId().equals(u.getId()) && !"ADMIN".equals(u.getRole())) throw new ResponseStatusException(HttpStatus.FORBIDDEN, "Not your dataset");
        return d;
    }

    public List<Dataset> list(AppUser u) { return repo.findByOwnerIdOrderByCreatedAtDesc(u.getId()); }

    /** Step 1: store the file (restricted extension, random name) and return the validation report; nothing is modified. */
    @SuppressWarnings("unchecked")
    public Dataset upload(MultipartFile f, AppUser u) throws IOException {
        String orig = Optional.ofNullable(f.getOriginalFilename()).orElse("upload");
        String ext = orig.contains(".") ? orig.substring(orig.lastIndexOf('.') + 1).toLowerCase() : "";
        if (!EXT.contains(ext)) throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Only CSV or XLSX files are accepted");
        if (f.isEmpty()) throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "File is empty");
        String stored = UUID.randomUUID() + "." + ext;
        Files.copy(f.getInputStream(), uploadDir.resolve(stored));
        Dataset d = new Dataset();
        d.setOwnerId(u.getId()); d.setName(orig.replaceAll("[^A-Za-z0-9._ -]", "_")); d.setSource("UPLOAD"); d.setUploadPath("uploads/" + stored);
        d.setCreatedAt(Instant.now()); d.setStatus("UPLOADED");
        try {
            Map<String, Object> rep = ml.post("/internal/v1/data/validate", Map.of("path", d.getUploadPath()));
            d.setReport(rep); d.setMapping((Map<String, Object>) rep.get("mapping"));
            d.setRowCount(((Number) rep.get("n_rows")).intValue()); d.setColumnCount(((Number) rep.get("n_columns")).intValue());
            d.setQualityStatus((String) rep.get("status"));
            d.setStatus(Boolean.TRUE.equals(rep.get("supported")) ? "NEEDS_REVIEW" : "UNSUPPORTED");
            if (!Boolean.TRUE.equals(rep.get("supported"))) d.setErrorMessage((String) rep.get("message"));
        } catch (ResponseStatusException e) {
            d.setStatus("REJECTED"); d.setErrorMessage(e.getReason());
        }
        return repo.save(d);
    }

    /** Step 2: user confirms mapping + handling options; ML service cleans (with a modification log) and stores canonical data. */
    @SuppressWarnings("unchecked")
    public Dataset commit(Long id, Map<String, Object> mapping, Map<String, Object> options, String symbol, AppUser u) {
        Dataset d = get(id, u);
        if (d.getUploadPath() == null) throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Dataset has no uploaded file");
        Map<String, Object> body = new HashMap<>();
        body.put("path", d.getUploadPath()); body.put("commit", true); body.put("dataset_id", d.getId().toString());
        if (mapping != null) body.put("mapping", mapping);
        if (options != null) body.put("options", options);
        if (symbol != null && !symbol.isBlank()) body.put("symbol", symbol.toUpperCase());
        Map<String, Object> r = ml.post("/internal/v1/data/validate", body);   // 422 + message if issues need a decision
        applyMeta(d, r);
        d.setCleaningLog((List<Object>) r.get("cleaning_log"));
        if (mapping != null) d.setMapping(mapping);
        repo.save(d);
        syncCandles(d);
        return d;
    }

    @SuppressWarnings("unchecked")
    public Dataset fetchBinance(String symbol, String interval, String start, String end, AppUser u) {
        Dataset d = new Dataset();
        d.setOwnerId(u.getId()); d.setName(symbol.toUpperCase() + " " + interval + " (Binance)"); d.setSource("BINANCE");
        d.setSymbol(symbol.toUpperCase()); d.setStatus("FETCHING"); d.setCreatedAt(Instant.now()); repo.save(d);
        try {
            Map<String, Object> body = new HashMap<>(Map.of("symbol", symbol, "interval", interval, "start", start, "dataset_id", d.getId().toString()));
            if (end != null && !end.isBlank()) body.put("end", end);
            Map<String, Object> r = ml.post("/internal/v1/data/binance", body, true);
            applyMeta(d, r);
            Map<String, Object> info = (Map<String, Object>) r.get("symbol_info");
            if (info != null) upsertAsset(info);
            repo.save(d);
            syncCandles(d);
        } catch (RuntimeException e) {
            d.setStatus("FAILED"); d.setErrorMessage(e.getMessage()); repo.save(d); throw e;
        }
        return d;
    }

    @SuppressWarnings("unchecked")
    private void applyMeta(Dataset d, Map<String, Object> r) {
        Map<String, Object> m = (Map<String, Object>) r.get("dataset");
        Map<String, Object> rep = (Map<String, Object>) r.get("report");
        d.setRowCount(((Number) m.get("rows")).intValue());
        d.setStartTs(Instant.parse((String) m.get("start"))); d.setEndTs(Instant.parse((String) m.get("end")));
        d.setIntervalSeconds(((Number) m.get("interval_seconds")).doubleValue());
        d.setSymbol((String) m.get("symbol")); d.setMissingPct(((Number) m.get("overall_missing_pct")).doubleValue());
        d.setReport(rep); d.setQualityStatus((String) rep.get("status")); d.setStatus("READY"); d.setErrorMessage(null);
    }

    private void upsertAsset(Map<String, Object> i) {
        jdbc.update("INSERT INTO assets(symbol, base_asset, quote_asset, tick_size, step_size, min_notional) VALUES (?,?,?,?,?,?) " +
                        "ON CONFLICT (symbol) DO UPDATE SET tick_size=EXCLUDED.tick_size, step_size=EXCLUDED.step_size, min_notional=EXCLUDED.min_notional, updated_at=now()",
                i.get("symbol"), i.get("base"), i.get("quote"), i.get("tick_size"), i.get("step_size"), i.get("min_notional"));
    }

    /** Persist canonical candles in PostgreSQL (the ML service reads the same data from its dataset file). */
    @SuppressWarnings("unchecked")
    void syncCandles(Dataset d) {
        int offset = 0, page = 5000, total = Integer.MAX_VALUE;
        jdbc.update("DELETE FROM market_candles WHERE dataset_id = ?", d.getId());
        while (offset < total) {
            Map<String, Object> r = ml.get("/internal/v1/data/" + d.getId() + "/candles?offset=" + offset + "&limit=" + page);
            total = ((Number) r.get("total")).intValue();
            List<Map<String, Object>> rows = (List<Map<String, Object>>) r.get("candles");
            if (rows.isEmpty()) break;
            jdbc.batchUpdate("INSERT INTO market_candles(dataset_id, open_time, symbol, interval_seconds, open, high, low, close, volume) VALUES (?,?,?,?,?,?,?,?,?) ON CONFLICT DO NOTHING",
                    rows, 1000, (ps, c) -> {
                        ps.setLong(1, d.getId()); ps.setTimestamp(2, Timestamp.from(Instant.parse((String) c.get("timestamp"))));
                        ps.setString(3, d.getSymbol()); ps.setDouble(4, d.getIntervalSeconds());
                        ps.setDouble(5, ((Number) c.get("open")).doubleValue()); ps.setDouble(6, ((Number) c.get("high")).doubleValue());
                        ps.setDouble(7, ((Number) c.get("low")).doubleValue()); ps.setDouble(8, ((Number) c.get("close")).doubleValue());
                        Object v = c.get("volume"); if (v == null) ps.setNull(9, java.sql.Types.DOUBLE); else ps.setDouble(9, ((Number) v).doubleValue());
                    });
            offset += rows.size();
        }
    }

    public Map<String, Object> candles(Long id, int tail, AppUser u) { get(id, u); return ml.get("/internal/v1/data/" + id + "/candles?tail=" + tail); }

    public Map<String, Object> features(Long id, int tail, AppUser u) {
        get(id, u); return ml.post("/internal/v1/data/features", Map.of("dataset_id", id.toString(), "tail", tail));
    }
}
