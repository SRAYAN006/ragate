package com.ragate.service;

import com.ragate.domain.*;
import com.ragate.repo.*;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;
import java.time.Instant;
import java.util.*;

/** Long-running jobs (training, backtests) run on a small executor; status lives in the database. */
@Component
public class JobRunner {
    private final MlClient ml; private final ModelRegistryEntryRepo models; private final BacktestRunRepo backtests; private final JdbcTemplate jdbc;

    public JobRunner(MlClient ml, ModelRegistryEntryRepo models, BacktestRunRepo backtests, JdbcTemplate jdbc) {
        this.ml = ml; this.models = models; this.backtests = backtests; this.jdbc = jdbc;
    }

    @Async("taskExecutor")
    @SuppressWarnings("unchecked")
    public void train(Long entryId, Long datasetId, String symbol, Map<String, Object> config) {
        ModelRegistryEntry e = models.findById(entryId).orElseThrow();
        try {
            Map<String, Object> meta = ml.post("/internal/v1/train", Map.of("dataset_id", datasetId.toString(), "symbol", symbol, "config", config == null ? Map.of() : config), true);
            e.setModelKey((String) meta.get("model_id")); e.setStatus("READY"); e.setMeta(meta);
            e.setMetrics((Map<String, Object>) meta.get("metrics")); e.setIntervalSeconds(((Number) meta.get("interval_seconds")).doubleValue());
            models.save(e);
            Map<String, Object> metrics = (Map<String, Object>) meta.get("metrics");
            for (var scope : metrics.entrySet())
                for (var ex : ((Map<String, Object>) scope.getValue()).entrySet())
                    for (var hz : ((Map<String, Object>) ex.getValue()).entrySet())
                        for (var met : ((Map<String, Object>) hz.getValue()).entrySet())
                            if (met.getValue() instanceof Number n)
                                jdbc.update("INSERT INTO model_metrics(model_key, scope, expert, horizon, metric, value) VALUES (?,?,?,?,?,?)",
                                        e.getModelKey(), scope.getKey(), ex.getKey(), hz.getKey(), met.getKey(), n.doubleValue());
        } catch (Exception ex) {
            e.setStatus("FAILED"); e.setError(String.valueOf(ex.getMessage())); models.save(e);
        }
    }

    @Async("taskExecutor")
    public void backtest(Long runId) {
        BacktestRun r = backtests.findById(runId).orElseThrow();
        try {
            r.setResult(ml.post("/internal/v1/backtest", r.getConfig(), true)); r.setStatus("DONE");
        } catch (Exception ex) { r.setStatus("FAILED"); r.setError(String.valueOf(ex.getMessage())); }
        r.setFinishedAt(Instant.now()); backtests.save(r);
    }
}
