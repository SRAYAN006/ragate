package com.ragate.service;

import com.ragate.config.AppProps;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpStatus;
import org.springframework.http.client.JdkClientHttpRequestFactory;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestClient;
import org.springframework.web.client.RestClientResponseException;
import org.springframework.web.server.ResponseStatusException;
import java.net.http.HttpClient;
import java.time.Duration;
import java.util.List;
import java.util.Map;

/** Thin client for the Python ML service. ML error messages are passed through to the caller. */
@Component
public class MlClient {
    private final RestClient quick, slow;

    public MlClient(AppProps p) {
        this.quick = build(p, Duration.ofSeconds(120));
        this.slow = build(p, Duration.ofHours(2));
    }

    private static RestClient build(AppProps p, Duration read) {
        JdkClientHttpRequestFactory f = new JdkClientHttpRequestFactory(HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(5)).build());
        f.setReadTimeout(read);
        return RestClient.builder().baseUrl(p.ml().baseUrl()).requestFactory(f)
                .defaultHeader("X-Internal-Key", p.ml().apiKey()).build();
    }

    private <T> T call(java.util.function.Supplier<T> s) {
        try { return s.get(); }
        catch (RestClientResponseException e) {
            throw new ResponseStatusException(HttpStatus.valueOf(e.getStatusCode().value()), e.getResponseBodyAsString());
        } catch (Exception e) {
            throw new ResponseStatusException(HttpStatus.SERVICE_UNAVAILABLE, "ML service unavailable: " + e.getMessage());
        }
    }

    public Map<String, Object> post(String path, Object body) { return post(path, body, false); }

    public Map<String, Object> post(String path, Object body, boolean longRunning) {
        return call(() -> (longRunning ? slow : quick).post().uri(path).body(body)
                .retrieve().body(new ParameterizedTypeReference<Map<String, Object>>() {}));
    }

    public Map<String, Object> get(String path) {
        return call(() -> quick.get().uri(path).retrieve().body(new ParameterizedTypeReference<Map<String, Object>>() {}));
    }

    public List<Map<String, Object>> getList(String path) {
        return call(() -> quick.get().uri(path).retrieve().body(new ParameterizedTypeReference<List<Map<String, Object>>>() {}));
    }
}
