package com.ragate.service;

import com.ragate.domain.*;
import com.ragate.repo.*;
import org.springframework.http.HttpStatus;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;
import java.math.BigDecimal;
import java.math.MathContext;
import java.math.RoundingMode;
import java.time.Instant;
import java.util.*;

/** PAPER TRADING ONLY. No exchange order endpoint is ever called; the DB also forbids paper_trading=false. */
@Service
public class PaperTradingService {
    private static final MathContext MC = new MathContext(28, RoundingMode.HALF_EVEN);
    private static final BigDecimal BPS = BigDecimal.valueOf(10_000);
    public record OrderRequest(String symbol, String side, BigDecimal quantity, Long datasetId, Long portfolioId) {}

    private final PortfolioRepo portfolios; private final PositionRepo positions; private final OrderEntityRepo orders;
    private final TradeRepo trades; private final PortfolioSnapshotRepo snaps; private final RagateDecisionRepo decisions;
    private final PriceService prices; private final JdbcTemplate jdbc; private final MlClient ml;

    public PaperTradingService(PortfolioRepo portfolios, PositionRepo positions, OrderEntityRepo orders, TradeRepo trades,
                               PortfolioSnapshotRepo snaps, RagateDecisionRepo decisions, PriceService prices, JdbcTemplate jdbc, MlClient ml) {
        this.portfolios = portfolios; this.positions = positions; this.orders = orders; this.trades = trades;
        this.snaps = snaps; this.decisions = decisions; this.prices = prices; this.jdbc = jdbc; this.ml = ml;
    }

    public Portfolio defaultPortfolio(Long ownerId) {
        return portfolios.findFirstByOwnerIdOrderByIdAsc(ownerId).orElseGet(() -> create(ownerId, BigDecimal.valueOf(10_000)));
    }

    private Portfolio create(Long ownerId, BigDecimal start) {
        Portfolio p = new Portfolio();
        p.setOwnerId(ownerId); p.setName("Paper portfolio"); p.setBaseCurrency("USDT"); p.setStartingBalance(start); p.setCash(start);
        p.setPaperTrading(true); p.setFeeRate(new BigDecimal("0.001")); p.setSlippageBps(BigDecimal.valueOf(5)); p.setCreatedAt(Instant.now());
        p = portfolios.save(p); snapshot(p, Map.of()); return p;
    }

    @Transactional
    public Portfolio reset(Long ownerId, BigDecimal startingBalance, BigDecimal feeRate, BigDecimal slippageBps) {
        if (startingBalance == null || startingBalance.signum() <= 0) throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Starting balance must be positive");
        Portfolio p = defaultPortfolio(ownerId);
        positions.deleteByPortfolioId(p.getId()); orders.deleteByPortfolioId(p.getId()); trades.deleteByPortfolioId(p.getId()); snaps.deleteByPortfolioId(p.getId());
        p.setStartingBalance(startingBalance); p.setCash(startingBalance);
        if (feeRate != null) p.setFeeRate(feeRate);
        if (slippageBps != null) p.setSlippageBps(slippageBps);
        portfolios.save(p); snapshot(p, Map.of()); return p;
    }

    record Filters(BigDecimal tick, BigDecimal step, BigDecimal minNotional, boolean defaulted) {}

    @SuppressWarnings("unchecked")
    Filters filters(String symbol) {
        String q = "SELECT tick_size, step_size, min_notional FROM assets WHERE symbol = ?";
        List<Filters> l = jdbc.query(q, (rs, i) -> new Filters(rs.getBigDecimal(1), rs.getBigDecimal(2), rs.getBigDecimal(3), false), symbol);
        if (!l.isEmpty()) return l.get(0);
        try {
            Map<String, Object> i = ml.get("/internal/v1/market/" + symbol + "/info");
            jdbc.update("INSERT INTO assets(symbol, base_asset, quote_asset, tick_size, step_size, min_notional) VALUES (?,?,?,?,?,?) ON CONFLICT DO NOTHING",
                    i.get("symbol"), i.get("base"), i.get("quote"), i.get("tick_size"), i.get("step_size"), i.get("min_notional"));
            return filters(symbol);
        } catch (RuntimeException e) {   // offline / uploaded dataset for an unknown pair: conservative defaults, flagged in response
            return new Filters(new BigDecimal("0.01"), new BigDecimal("0.00001"), BigDecimal.valueOf(5), true);
        }
    }

    @Transactional
    public OrderEntity placeOrder(Long ownerId, OrderRequest r, String source, Long decisionId) {
        Portfolio p = r.portfolioId() == null ? defaultPortfolio(ownerId)
                : portfolios.findByIdAndOwnerId(r.portfolioId(), ownerId).orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Portfolio not found"));
        String side = r.side() == null ? "" : r.side().toUpperCase();
        if (!side.equals("BUY") && !side.equals("SELL")) throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "side must be BUY or SELL");
        String symbol = r.symbol().toUpperCase();
        BigDecimal ref = prices.price(symbol, r.datasetId());
        Filters f = filters(symbol);

        BigDecimal slip = p.getSlippageBps().divide(BPS, MC);
        BigDecimal px = side.equals("BUY") ? ref.multiply(BigDecimal.ONE.add(slip), MC) : ref.multiply(BigDecimal.ONE.subtract(slip), MC);
        px = px.divide(f.tick(), 0, RoundingMode.HALF_UP).multiply(f.tick());                    // tick-size precision
        BigDecimal qty = r.quantity() == null ? BigDecimal.ZERO : r.quantity().divide(f.step(), 0, RoundingMode.DOWN).multiply(f.step());   // lot-size precision
        BigDecimal notional = px.multiply(qty, MC), fee = notional.multiply(p.getFeeRate(), MC);

        OrderEntity o = new OrderEntity();
        o.setPortfolioId(p.getId()); o.setSymbol(symbol); o.setSide(side); o.setQuantity(qty); o.setRefPrice(ref); o.setSource(source);
        o.setDecisionId(decisionId); o.setDatasetId(r.datasetId()); o.setPaper(true); o.setCreatedAt(Instant.now());

        Position pos = positions.findByPortfolioIdAndSymbol(p.getId(), symbol).orElseGet(() -> {
            Position n = new Position(); n.setPortfolioId(p.getId()); n.setSymbol(symbol);
            n.setQuantity(BigDecimal.ZERO); n.setAvgCost(BigDecimal.ZERO); n.setRealizedPnl(BigDecimal.ZERO); return n; });

        String reject = null;
        if (qty.signum() <= 0) reject = "Quantity rounds to zero at step size " + f.step().stripTrailingZeros().toPlainString();
        else if (notional.compareTo(f.minNotional()) < 0) reject = "Order value " + notional.setScale(2, RoundingMode.HALF_UP) + " is below minimum notional " + f.minNotional();
        else if (side.equals("BUY") && p.getCash().compareTo(notional.add(fee)) < 0) reject = "Insufficient virtual cash";
        else if (side.equals("SELL") && pos.getQuantity().compareTo(qty) < 0) reject = "Insufficient position (no short selling)";
        if (reject != null) { o.setStatus("REJECTED"); o.setRejectReason(reject + (f.defaulted() ? " [default exchange filters used]" : "")); return orders.save(o); }

        BigDecimal realized = BigDecimal.ZERO;
        if (side.equals("BUY")) {
            BigDecimal newQty = pos.getQuantity().add(qty);
            pos.setAvgCost(pos.getQuantity().multiply(pos.getAvgCost(), MC).add(notional).add(fee).divide(newQty, MC));  // fee capitalised into cost basis
            pos.setQuantity(newQty); p.setCash(p.getCash().subtract(notional).subtract(fee));
        } else {
            realized = px.subtract(pos.getAvgCost()).multiply(qty, MC).subtract(fee);
            pos.setQuantity(pos.getQuantity().subtract(qty)); pos.setRealizedPnl(pos.getRealizedPnl().add(realized));
            p.setCash(p.getCash().add(notional).subtract(fee));
        }
        o.setStatus("FILLED"); o.setFilledQuantity(qty); o.setExecPrice(px); o.setFee(fee); o.setSlippageCost(px.subtract(ref).abs().multiply(qty, MC));
        o = orders.save(o); positions.save(pos); portfolios.save(p);
        Trade t = new Trade();
        t.setPortfolioId(p.getId()); t.setOrderId(o.getId()); t.setSymbol(symbol); t.setSide(side); t.setQuantity(qty); t.setPrice(px);
        t.setFee(fee); t.setRealizedPnl(realized); t.setExecutedAt(Instant.now()); trades.save(t);
        snapshot(p, Map.of(symbol, ref));
        return o;
    }

    /** Executes an APPROVED RAGATE decision: sizes the order from the decision's risk-adjusted target weight. */
    @Transactional
    public OrderEntity executeDecision(Long ownerId, Long decisionId) {
        RagateDecision d = decisions.findByIdAndUserId(decisionId, ownerId).orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Decision not found"));
        if (orders.existsByDecisionIdAndStatus(decisionId, "FILLED")) throw new ResponseStatusException(HttpStatus.CONFLICT, "Decision already executed");
        String a = d.getAction();
        if (!List.of("BUY", "REDUCE", "EXIT").contains(a)) throw new ResponseStatusException(HttpStatus.BAD_REQUEST, a + " requires no trade");
        Portfolio p = defaultPortfolio(ownerId);
        BigDecimal px = prices.price(d.getSymbol(), d.getDatasetId());
        BigDecimal equity = equity(p, Map.of(d.getSymbol(), px));
        Position pos = positions.findByPortfolioIdAndSymbol(p.getId(), d.getSymbol()).orElse(null);
        BigDecimal curQty = pos == null ? BigDecimal.ZERO : pos.getQuantity();
        BigDecimal tw = a.equals("EXIT") ? BigDecimal.ZERO : BigDecimal.valueOf(d.getTargetWeight());
        BigDecimal deltaQty = equity.multiply(tw, MC).divide(px, MC).subtract(curQty);
        if (a.equals("BUY") && deltaQty.signum() <= 0) throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Portfolio already at or above the target exposure");
        if (!a.equals("BUY") && deltaQty.signum() >= 0) throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Portfolio already at or below the target exposure");
        if (a.equals("EXIT")) deltaQty = curQty.negate();
        return placeOrder(ownerId, new OrderRequest(d.getSymbol(), deltaQty.signum() > 0 ? "BUY" : "SELL", deltaQty.abs(), d.getDatasetId(), p.getId()), "DECISION", decisionId);
    }

    BigDecimal equity(Portfolio p, Map<String, BigDecimal> known) {
        BigDecimal eq = p.getCash();
        for (Position pos : positions.findByPortfolioId(p.getId())) {
            if (pos.getQuantity().signum() == 0) continue;
            BigDecimal px = known.get(pos.getSymbol());
            if (px == null) px = prices.priceOrNull(pos.getSymbol(), null);
            if (px == null) px = pos.getAvgCost();   // last resort when no price source is reachable
            eq = eq.add(pos.getQuantity().multiply(px, MC));
        }
        return eq;
    }

    void snapshot(Portfolio p, Map<String, BigDecimal> known) {
        BigDecimal eq = equity(p, known);
        PortfolioSnapshot s = new PortfolioSnapshot();
        s.setPortfolioId(p.getId()); s.setTs(Instant.now()); s.setEquity(eq); s.setCash(p.getCash());
        BigDecimal cost = positions.findByPortfolioId(p.getId()).stream().map(x -> x.getQuantity().multiply(x.getAvgCost(), MC)).reduce(BigDecimal.ZERO, BigDecimal::add);
        s.setUnrealizedPnl(eq.subtract(p.getCash()).subtract(cost));   // market value of holdings minus their cost basis
        snaps.save(s);
    }

    public Map<String, Object> view(Long ownerId) {
        Portfolio p = defaultPortfolio(ownerId);
        List<Map<String, Object>> rows = new ArrayList<>();
        BigDecimal mv = BigDecimal.ZERO, unreal = BigDecimal.ZERO, realized = BigDecimal.ZERO; boolean priceFallback = false;
        for (Position pos : positions.findByPortfolioId(p.getId())) {
            realized = realized.add(pos.getRealizedPnl());
            if (pos.getQuantity().signum() == 0) continue;
            BigDecimal px = prices.priceOrNull(pos.getSymbol(), null);
            boolean fb = px == null; if (fb) { px = pos.getAvgCost(); priceFallback = true; }
            BigDecimal val = pos.getQuantity().multiply(px, MC), un = px.subtract(pos.getAvgCost()).multiply(pos.getQuantity(), MC);
            mv = mv.add(val); unreal = unreal.add(un);
            rows.add(Map.of("symbol", pos.getSymbol(), "quantity", pos.getQuantity(), "avgCost", pos.getAvgCost(), "price", px, "marketValue", val,
                    "unrealizedPnl", un, "realizedPnl", pos.getRealizedPnl(), "priceIsFallback", fb));
        }
        BigDecimal equity = p.getCash().add(mv);
        double peak = 0, mdd = 0; List<Map<String, Object>> curve = new ArrayList<>();
        for (PortfolioSnapshot s : snaps.findByPortfolioIdOrderByTsAsc(p.getId())) {
            double e = s.getEquity().doubleValue(); peak = Math.max(peak, e); if (peak > 0) mdd = Math.min(mdd, e / peak - 1);
            curve.add(Map.of("ts", s.getTs().toString(), "equity", e));
        }
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("label", "PAPER TRADING"); m.put("id", p.getId()); m.put("name", p.getName()); m.put("currency", p.getBaseCurrency());
        m.put("startingBalance", p.getStartingBalance()); m.put("cash", p.getCash()); m.put("equity", equity); m.put("marketValue", mv);
        m.put("unrealizedPnl", unreal); m.put("realizedPnl", realized); m.put("totalPnl", equity.subtract(p.getStartingBalance()));
        m.put("maxDrawdown", mdd); m.put("feeRate", p.getFeeRate()); m.put("slippageBps", p.getSlippageBps());
        m.put("positions", rows); m.put("equityCurve", curve); m.put("priceFallbackUsed", priceFallback);
        return m;
    }

    public List<OrderEntity> orderHistory(Long ownerId) { return orders.findTop200ByPortfolioIdOrderByCreatedAtDesc(defaultPortfolio(ownerId).getId()); }
    public List<Trade> tradeHistory(Long ownerId) { return trades.findTop200ByPortfolioIdOrderByExecutedAtDesc(defaultPortfolio(ownerId).getId()); }
}
