package com.ragate.service;

import com.ragate.domain.*;
import com.ragate.repo.*;
import org.springframework.http.HttpStatus;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.time.Instant;
import java.util.*;

/**
 * Orchestrates: ML experts -> RAGATE reliability/gating (state persisted here) -> risk engine -> decision.
 * Forecast scoring happens only for matured forecasts; each forecast is scored once (scored flag + unique key).
 */
@Service
public class PredictionService {
    private static final List<String> HORIZONS = List.of("1d", "3d", "5d");
    private final MlClient ml; private final ExpertPredictionRepo preds; private final ExpertReliabilityRepo rel; private final RagateDecisionRepo decisions;
    private final ModelRegistryEntryRepo models; private final DatasetService datasets; private final PaperTradingService paper; private final JdbcTemplate jdbc;

    public PredictionService(MlClient ml, ExpertPredictionRepo preds, ExpertReliabilityRepo rel, RagateDecisionRepo decisions,
                             ModelRegistryEntryRepo models, DatasetService datasets, PaperTradingService paper, JdbcTemplate jdbc) {
        this.ml = ml; this.preds = preds; this.rel = rel; this.decisions = decisions; this.models = models; this.datasets = datasets; this.paper = paper; this.jdbc = jdbc;
    }

    @SuppressWarnings("unchecked")
    public RagateDecision predict(AppUser u, Long datasetId, String modelKey, String decisionHorizon, Map<String, Object> riskCfg, Map<String, Object> decCfg) {
        ModelRegistryEntry m = models.findByModelKey(modelKey).orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Model not found"));
        if (!"READY".equals(m.getStatus())) throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Model is not ready (status " + m.getStatus() + ")");
        Dataset ds = datasets.get(datasetId, u);
        if (!"READY".equals(ds.getStatus())) throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Dataset is not ready");
        if (!Objects.equals(m.getSymbol(), ds.getSymbol()) && ds.getSymbol() != null && !"UNKNOWN".equals(ds.getSymbol()))
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Model was trained on " + m.getSymbol() + " but dataset is " + ds.getSymbol());
        String primary = decisionHorizon == null ? "1d" : decisionHorizon;

        Map<String, Object> pr = ml.post("/internal/v1/predict", Map.of("dataset_id", ds.getId().toString(), "model_id", modelKey,
                "historical_mode", "UPLOAD".equals(ds.getSource())));
        String symbol = m.getSymbol();
        Instant asof = Instant.parse((String) pr.get("asof"));
        Map<String, Object> rp = (Map<String, Object>) pr.get("regime_probs");
        Map<String, Object> hz = (Map<String, Object>) pr.get("horizons");
        List<Map<String, Object>> outs = (List<Map<String, Object>>) pr.get("expert_outputs");
        Map<String, Object> fresh = (Map<String, Object>) pr.get("freshness");

        Map<String, Object> perHorizon = new LinkedHashMap<>(); Map<String, Object> primaryRg = null;
        for (String h : HORIZONS) {
            List<Map<String, Object>> hOuts = outs.stream().filter(o -> h.equals(o.get("horizon"))).toList();
            // 1. matured, unscored forecasts + persisted reliability state go to RAGATE
            List<ExpertPrediction> pending = preds.findByModelKeyAndSymbolAndHorizonAndScoredFalseAndTargetEndLessThanEqual(modelKey, symbol, h, asof);
            List<Map<String, Object>> pend = pending.stream().map(p -> Map.<String, Object>of("id", String.valueOf(p.getId()), "expert", p.getExpert(), "horizon", h,
                    "asof", p.getAsof().toString(), "target_end", p.getTargetEnd().toString(), "predicted_return", p.getPredictedReturn())).toList();
            ExpertReliability r = rel.findByModelKeyAndSymbolAndHorizon(modelKey, symbol, h).orElseGet(() -> {
                ExpertReliability n = new ExpertReliability(); n.setModelKey(modelKey); n.setSymbol(symbol); n.setHorizon(h); n.setState(new HashMap<>()); return n; });
            Map<String, Object> req = new HashMap<>();
            req.put("dataset_id", ds.getId().toString()); req.put("model_id", modelKey); req.put("horizon", h); req.put("pending", pend);
            req.put("state", r.getState()); req.put("expert_outputs", hOuts); req.put("regime_probs", rp);
            Map<String, Object> rg = ml.post("/internal/v1/ragate/evaluate", req);

            // 2. persist scores (once) and the new reliability state
            Map<String, ExpertPrediction> byId = new HashMap<>(); pending.forEach(p -> byId.put(String.valueOf(p.getId()), p));
            for (Map<String, Object> s : (List<Map<String, Object>>) rg.get("scored")) {
                ExpertPrediction p = byId.get(String.valueOf(s.get("id")));
                if (p == null || Boolean.TRUE.equals(p.getScored())) continue;
                p.setActualReturn(((Number) s.get("actual_return")).doubleValue()); p.setLoss(((Number) s.get("loss")).doubleValue());
                p.setScored(true); p.setScoredAt(Instant.now()); preds.save(p);
            }
            r.setState((Map<String, Object>) rg.get("state")); r.setUpdatedAt(Instant.now()); rel.save(r);

            // 3. store the new forecasts (idempotent)
            for (Map<String, Object> o : hOuts) {
                if (o.get("pred") == null) continue;
                Instant a = Instant.parse((String) o.get("asof"));
                if (preds.existsByModelKeyAndSymbolAndExpertAndHorizonAndAsof(modelKey, symbol, (String) o.get("expert"), h, a)) continue;
                ExpertPrediction p = new ExpertPrediction();
                p.setModelKey(modelKey); p.setSymbol(symbol); p.setExpert((String) o.get("expert")); p.setHorizon(h); p.setAsof(a);
                p.setTargetEnd(Instant.parse((String) o.get("target_end"))); p.setPredictedReturn(((Number) o.get("pred")).doubleValue());
                p.setProbPositive(o.get("prob_pos") == null ? null : ((Number) o.get("prob_pos")).doubleValue());
                p.setUncertainty(o.get("sigma") == null ? null : ((Number) o.get("sigma")).doubleValue());
                p.setScored(false); p.setCreatedAt(Instant.now()); preds.save(p);
            }
            Map<String, Object> hv = new LinkedHashMap<>(); hv.put("experts", hOuts); hv.put("ragate", rg); perHorizon.put(h, hv);
            if (h.equals(primary)) primaryRg = rg;
        }

        // 4. risk + decision for the decision horizon, using the paper portfolio as context
        Portfolio pf = paper.defaultPortfolio(u.getId());
        Map<String, Object> view = paper.view(u.getId());
        BigDecimal equity = (BigDecimal) view.get("equity"); double curW = 0;
        for (Map<String, Object> row : (List<Map<String, Object>>) view.get("positions"))
            if (symbol.equals(row.get("symbol")) && equity.signum() > 0) curW = ((BigDecimal) row.get("marketValue")).divide(equity, 8, java.math.RoundingMode.HALF_UP).doubleValue();
        Double spread = null;
        if ("BINANCE".equals(ds.getSource())) { try { spread = ((Number) ml.get("/internal/v1/market/" + symbol + "/book").get("spread_bps")).doubleValue(); } catch (RuntimeException ignored) { } }
        Map<String, Object> rq = new HashMap<>();
        rq.put("asset", symbol); rq.put("horizon_candles", hz.get(primary)); rq.put("periods_per_year", pr.get("periods_per_year"));
        rq.put("ragate", primaryRg); rq.put("regime_probs", rp); rq.put("current_weight", curW);
        rq.put("cash_fraction", pf.getCash().divide(equity.signum() == 0 ? BigDecimal.ONE : equity, 8, java.math.RoundingMode.HALF_UP).doubleValue());
        rq.put("spread_bps", spread); rq.put("data_stale", Boolean.TRUE.equals(fresh.get("stale")));
        rq.put("returns", Map.of(symbol, pr.get("recent_returns")));
        rq.put("risk_config", riskCfg == null ? Map.of() : riskCfg); rq.put("decision_config", decCfg == null ? Map.of() : decCfg);
        Map<String, Object> rd = ml.post("/internal/v1/risk/evaluate", rq);
        Map<String, Object> dec = (Map<String, Object>) rd.get("decision");
        Map<String, Object> comb = (Map<String, Object>) primaryRg.get("combined");

        Map<String, Object> payload = new LinkedHashMap<>();
        payload.put("asof", asof.toString()); payload.put("symbol", symbol); payload.put("lastClose", pr.get("last_close"));
        payload.put("regime", Map.of("probs", rp, "summary", pr.get("regime_summary")));
        payload.put("horizons", perHorizon); payload.put("decisionHorizon", primary); payload.put("risk", rd.get("risk"));
        payload.put("decision", dec); payload.put("freshness", fresh); payload.put("unavailableExperts", pr.get("unavailable_experts"));
        payload.put("currentWeight", curW); payload.put("label", "PAPER TRADING signal: no real orders are ever placed");

        RagateDecision d = new RagateDecision();
        d.setUserId(u.getId()); d.setModelKey(modelKey); d.setDatasetId(ds.getId()); d.setSymbol(symbol); d.setHorizon(primary); d.setAsof(asof);
        d.setAction((String) dec.get("action")); d.setTargetWeight(((Number) dec.get("target_weight")).doubleValue());
        d.setCombinedReturn(comb == null ? null : ((Number) comb.get("combined_return")).doubleValue());
        d.setUncertainty(comb == null ? null : ((Number) comb.get("sigma_total")).doubleValue());
        Map<String, Object> w = primaryRg.get("weights") == null ? Map.of() : (Map<String, Object>) primaryRg.get("weights");
        d.setWeights(w); d.setRegime(rp); d.setRisk((Map<String, Object>) rd.get("risk")); d.setReasons((List<Object>) dec.get("reasons"));
        d.setPayload(payload); d.setCreatedAt(Instant.now());
        d = decisions.save(d);
        jdbc.update("INSERT INTO market_regimes(dataset_id, open_time, model_key, bull, range_p, stress, label) VALUES (?,?,?,?,?,?,?) ON CONFLICT DO NOTHING",
                ds.getId(), Timestamp.from(asof), modelKey, ((Number) rp.get("bull")).doubleValue(), ((Number) rp.get("range")).doubleValue(),
                ((Number) rp.get("stress")).doubleValue(), String.valueOf(((Map<String, Object>) pr.get("regime_summary")).get("current_label")));
        return d;
    }

    public RagateDecision get(Long id, AppUser u) {
        return decisions.findByIdAndUserId(id, u.getId()).orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Prediction not found"));
    }

    public List<RagateDecision> recent(AppUser u) { return decisions.findTop50ByUserIdOrderByCreatedAtDesc(u.getId()); }

    public Map<String, Object> reliability(String modelKey) {
        Map<String, Object> m = new LinkedHashMap<>();
        for (ExpertReliability r : rel.findByModelKey(modelKey)) m.put(r.getSymbol() + "|" + r.getHorizon(), r.getState());
        return m;
    }
}
