package com.ragate.service;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;
import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

@Service
public class PriceService {
    private final MlClient ml;
    public PriceService(MlClient ml) { this.ml = ml; }

    /** Dataset-based price = last candle close (historical simulation); otherwise live Binance last price. */
    @SuppressWarnings("unchecked")
    public BigDecimal price(String symbol, Long datasetId) {
        try {
            if (datasetId != null) {
                List<Map<String, Object>> c = (List<Map<String, Object>>) ml.get("/internal/v1/data/" + datasetId + "/candles?tail=1").get("candles");
                return new BigDecimal(String.valueOf(c.get(c.size() - 1).get("close")));
            }
            Map<String, Object> ov = ml.get("/internal/v1/market/overview?symbols=" + symbol.toUpperCase());
            Map<String, Object> t = (Map<String, Object>) ov.get(symbol.toUpperCase());
            return new BigDecimal(String.valueOf(t.get("price")));
        } catch (ResponseStatusException e) { throw e; }
        catch (Exception e) { throw new ResponseStatusException(HttpStatus.SERVICE_UNAVAILABLE, "Price unavailable for " + symbol); }
    }

    public BigDecimal priceOrNull(String symbol, Long datasetId) {
        try { return price(symbol, datasetId); } catch (RuntimeException e) { return null; }
    }
}
