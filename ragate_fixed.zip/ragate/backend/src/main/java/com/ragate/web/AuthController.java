package com.ragate.web;

import com.ragate.service.AuthService;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;
import org.springframework.web.bind.annotation.*;
import java.util.Map;

@RestController
@RequestMapping("/api/auth")
public class AuthController {
    public record RegisterReq(@NotBlank @Size(min = 3, max = 50) @Pattern(regexp = "[A-Za-z0-9_.-]+") String username,
                              @NotBlank @Email String email, @NotBlank @Size(min = 8, max = 100) String password) {}
    public record LoginReq(@NotBlank String username, @NotBlank String password) {}
    private final AuthService auth;
    public AuthController(AuthService auth) { this.auth = auth; }

    @PostMapping("/register") public Map<String, Object> register(@Valid @RequestBody RegisterReq r) { return auth.register(r.username(), r.email(), r.password()); }
    @PostMapping("/login") public Map<String, Object> login(@Valid @RequestBody LoginReq r) { return auth.login(r.username(), r.password()); }
}
