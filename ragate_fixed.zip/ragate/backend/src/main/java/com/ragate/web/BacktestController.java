package com.ragate.web;

import com.ragate.domain.*;
import com.ragate.repo.*;
import com.ragate.service.*;
import org.springframework.http.HttpStatus;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;
import java.time.Instant;
import java.util.*;

@RestController
@RequestMapping("/api/v1")
public class BacktestController {
    private final BacktestRunRepo runs; private final JobRunner jobs; private final CurrentUser cu; private final DatasetService datasets;
    private final ModelRegistryEntryRepo models; private final JdbcTemplate jdbc;

    public BacktestController(BacktestRunRepo runs, JobRunner jobs, CurrentUser cu, DatasetService datasets, ModelRegistryEntryRepo models, JdbcTemplate jdbc) {
        this.runs = runs; this.jobs = jobs; this.cu = cu; this.datasets = datasets; this.models = models; this.jdbc = jdbc;
    }

    /** body: {assets:[{datasetId, modelKey}], start, end, initialCapital, horizon, costs:{fee_rate, slippage_bps}, ...} */
    @SuppressWarnings("unchecked")
    @PostMapping("/backtests")
    public BacktestRun create(@RequestBody Map<String, Object> body, Authentication a) {
        AppUser u = cu.get(a);
        List<Map<String, Object>> assets = (List<Map<String, Object>>) body.get("assets");
        if (assets == null || assets.isEmpty()) throw new IllegalArgumentException("assets is required");
        List<Map<String, Object>> mlAssets = new ArrayList<>();
        for (Map<String, Object> x : assets) {
            Long dsId = ((Number) x.get("datasetId")).longValue(); datasets.get(dsId, u);
            String key = (String) x.get("modelKey");
            if (models.findByModelKey(key).filter(m -> "READY".equals(m.getStatus())).isEmpty()) throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Model not ready: " + key);
            mlAssets.add(Map.of("dataset_id", dsId.toString(), "model_id", key));
        }
        Map<String, Object> cfg = new HashMap<>();
        cfg.put("assets", mlAssets);
        for (String k : List.of("start", "end", "horizon", "costs", "risk", "decision", "ragate", "allow_in_sample"))
            if (body.get(k) != null) cfg.put(k, body.get(k));
        if (body.get("initialCapital") != null) cfg.put("initial_capital", body.get("initialCapital"));
        BacktestRun r = new BacktestRun(); r.setOwnerId(u.getId()); r.setConfig(cfg); r.setStatus("RUNNING"); r.setCreatedAt(Instant.now());
        runs.save(r); jobs.backtest(r.getId());
        return r;
    }

    @GetMapping("/backtests/{id}") public BacktestRun get(@PathVariable Long id, Authentication a) {
        return runs.findByIdAndOwnerId(id, cu.get(a).getId()).orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Backtest not found"));
    }
    @GetMapping("/backtests") public List<Map<String, Object>> list(Authentication a) {
        return runs.findTop20ByOwnerIdOrderByCreatedAtDesc(cu.get(a).getId()).stream()
                .map(r -> Map.<String, Object>of("id", r.getId(), "status", r.getStatus(), "createdAt", r.getCreatedAt().toString())).toList();
    }

    @GetMapping("/research/metrics")
    public Map<String, Object> research(Authentication a) {
        AppUser u = cu.get(a);
        List<Map<String, Object>> ms = new ArrayList<>();
        for (ModelRegistryEntry m : models.findAllByOrderByCreatedAtDesc()) {
            if (!"READY".equals(m.getStatus())) continue;
            Map<String, Object> meta = m.getMeta();
            ms.add(Map.of("modelKey", m.getModelKey(), "symbol", m.getSymbol(), "splits", meta.get("splits"), "metrics", meta.get("metrics"),
                    "fusionComparison", meta.get("fusion_comparison") == null ? Map.of() : meta.get("fusion_comparison"),
                    "walkForward", meta.get("walk_forward") == null ? List.of() : meta.get("walk_forward"),
                    "featureImportance", meta.get("feature_importance"), "mrParams", meta.get("mean_reversion_params")));
        }
        List<Map<String, Object>> dec = jdbc.queryForList("SELECT action, COUNT(*) AS n FROM ragate_decisions WHERE user_id = ? GROUP BY action", u.getId());
        List<Map<String, Object>> bts = runs.findTop20ByOwnerIdOrderByCreatedAtDesc(u.getId()).stream().filter(r -> "DONE".equals(r.getStatus()))
                .map(r -> Map.<String, Object>of("id", r.getId(), "createdAt", r.getCreatedAt().toString(), "aggregate", r.getResult().get("aggregate"))).toList();
        return Map.of("models", ms, "decisionCounts", dec, "backtests", bts);
    }
}
