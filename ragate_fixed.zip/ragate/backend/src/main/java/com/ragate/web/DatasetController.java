package com.ragate.web;

import com.ragate.domain.Dataset;
import com.ragate.service.*;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import java.io.IOException;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/v1/datasets")
public class DatasetController {
    public record CommitReq(Map<String, Object> mapping, Map<String, Object> options, String symbol) {}
    public record BinanceReq(String symbol, String interval, String start, String end) {}
    private final DatasetService svc; private final CurrentUser cu;
    public DatasetController(DatasetService svc, CurrentUser cu) { this.svc = svc; this.cu = cu; }

    @PostMapping("/upload") public Dataset upload(@RequestParam("file") MultipartFile f, Authentication a) throws IOException { return svc.upload(f, cu.get(a)); }
    @GetMapping public List<Dataset> list(Authentication a) { return svc.list(cu.get(a)); }
    @GetMapping("/{id}") public Dataset get(@PathVariable Long id, Authentication a) { return svc.get(id, cu.get(a)); }
    @PostMapping("/{id}/commit") public Dataset commit(@PathVariable Long id, @RequestBody CommitReq r, Authentication a) { return svc.commit(id, r.mapping(), r.options(), r.symbol(), cu.get(a)); }
    @PostMapping("/binance")
    public Dataset binance(@RequestBody BinanceReq r, Authentication a) {
        if (r.symbol() == null || !r.symbol().matches("[A-Za-z0-9/-]{3,20}")) throw new IllegalArgumentException("Invalid symbol");
        return svc.fetchBinance(r.symbol().replace("/", ""), r.interval() == null ? "4h" : r.interval(), r.start() == null ? "2021-01-01" : r.start(), r.end(), cu.get(a));
    }
    @GetMapping("/{id}/candles") public Map<String, Object> candles(@PathVariable Long id, @RequestParam(defaultValue = "1000") int tail, Authentication a) { return svc.candles(id, Math.min(tail, 20000), cu.get(a)); }
    @GetMapping("/{id}/features") public Map<String, Object> features(@PathVariable Long id, @RequestParam(defaultValue = "500") int tail, Authentication a) { return svc.features(id, Math.min(tail, 5000), cu.get(a)); }
}
