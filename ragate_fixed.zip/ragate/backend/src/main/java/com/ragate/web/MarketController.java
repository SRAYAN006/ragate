package com.ragate.web;

import com.ragate.service.MlClient;
import org.springframework.web.bind.annotation.*;
import java.util.Map;

@RestController
@RequestMapping("/api/v1/market")
public class MarketController {
    private final MlClient ml;
    public MarketController(MlClient ml) { this.ml = ml; }

    @GetMapping("/overview")
    public Map<String, Object> overview(@RequestParam(defaultValue = "BTCUSDT,ETHUSDT,SOLUSDT") String symbols) {
        if (!symbols.matches("[A-Za-z0-9,]{3,100}")) throw new IllegalArgumentException("Invalid symbols");
        return ml.get("/internal/v1/market/overview?symbols=" + symbols);
    }

    @GetMapping("/{symbol}/candles")
    public Map<String, Object> candles(@PathVariable String symbol, @RequestParam(defaultValue = "4h") String interval, @RequestParam(defaultValue = "500") int limit) {
        if (!symbol.matches("[A-Za-z0-9/-]{3,20}") || !interval.matches("[0-9]{1,2}[mhd]")) throw new IllegalArgumentException("Invalid symbol or interval");
        return ml.get("/internal/v1/market/" + symbol.replace("/", "") + "/candles?interval=" + interval + "&limit=" + Math.min(limit, 1000));
    }
}
