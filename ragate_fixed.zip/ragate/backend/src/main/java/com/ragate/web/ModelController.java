package com.ragate.web;

import com.ragate.domain.*;
import com.ragate.repo.ModelRegistryEntryRepo;
import com.ragate.service.*;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;
import java.time.Instant;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/v1/models")
public class ModelController {
    public record TrainReq(Long datasetId, Map<String, Object> config) {}
    private final ModelRegistryEntryRepo repo; private final DatasetService datasets; private final JobRunner jobs; private final CurrentUser cu; private final MlClient ml;
    public ModelController(ModelRegistryEntryRepo repo, DatasetService datasets, JobRunner jobs, CurrentUser cu, MlClient ml) {
        this.repo = repo; this.datasets = datasets; this.jobs = jobs; this.cu = cu; this.ml = ml;
    }

    @GetMapping public List<ModelRegistryEntry> list() { return repo.findAllByOrderByCreatedAtDesc(); }

    @GetMapping("/{id}") public ModelRegistryEntry get(@PathVariable Long id) { return repo.findById(id).orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Model not found")); }

    /** Training is long-running and CPU heavy: administrators only. Returns immediately; poll GET /api/v1/models. */
    @PostMapping("/train") @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<ModelRegistryEntry> train(@RequestBody TrainReq r, Authentication a) {
        Dataset d = datasets.get(r.datasetId(), cu.get(a));
        if (!"READY".equals(d.getStatus())) throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Dataset must be READY (validated and committed)");
        ModelRegistryEntry e = new ModelRegistryEntry();
        e.setDatasetId(d.getId()); e.setSymbol(d.getSymbol() == null ? "UNKNOWN" : d.getSymbol()); e.setStatus("TRAINING"); e.setCreatedBy(cu.get(a).getId()); e.setCreatedAt(Instant.now());
        repo.save(e);
        jobs.train(e.getId(), d.getId(), e.getSymbol(), r.config());
        return ResponseEntity.accepted().body(e);
    }

    @GetMapping("/{key}/regime")
    public Map<String, Object> regime(@PathVariable String key, @RequestParam Long datasetId, @RequestParam(defaultValue = "300") int tail, Authentication a) {
        datasets.get(datasetId, cu.get(a));
        return ml.post("/internal/v1/regime/predict", Map.of("dataset_id", datasetId.toString(), "model_id", key, "tail", Math.min(tail, 3000)));
    }
}
