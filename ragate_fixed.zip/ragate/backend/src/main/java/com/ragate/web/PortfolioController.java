package com.ragate.web;

import com.ragate.domain.*;
import com.ragate.service.*;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;
import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/v1")
public class PortfolioController {
    public record ManualOrder(String symbol, String side, BigDecimal quantity, Long datasetId) {}
    public record ExecuteReq(Long decisionId) {}
    public record ResetReq(BigDecimal startingBalance, BigDecimal feeRate, BigDecimal slippageBps) {}
    private final PaperTradingService paper; private final CurrentUser cu;
    public PortfolioController(PaperTradingService paper, CurrentUser cu) { this.paper = paper; this.cu = cu; }

    @GetMapping("/portfolio") public Map<String, Object> portfolio(Authentication a) { return paper.view(cu.get(a).getId()); }

    @PostMapping("/portfolio/reset")
    public Map<String, Object> reset(@RequestBody ResetReq r, Authentication a) { Long id = cu.get(a).getId(); paper.reset(id, r.startingBalance(), r.feeRate(), r.slippageBps()); return paper.view(id); }

    /** Body {decisionId} executes an approved RAGATE decision; body {symbol, side, quantity} is a manual simulation. PAPER ONLY. */
    @PostMapping("/paper/orders")
    public OrderEntity order(@RequestBody Map<String, Object> body, Authentication a) {
        Long uid = cu.get(a).getId();
        if (body.get("decisionId") != null) return paper.executeDecision(uid, ((Number) body.get("decisionId")).longValue());
        Long ds = body.get("datasetId") == null ? null : ((Number) body.get("datasetId")).longValue();
        return paper.placeOrder(uid, new PaperTradingService.OrderRequest((String) body.get("symbol"), (String) body.get("side"),
                new BigDecimal(String.valueOf(body.get("quantity"))), ds, null), "MANUAL", null);
    }
    @GetMapping("/orders") public List<OrderEntity> orders(Authentication a) { return paper.orderHistory(cu.get(a).getId()); }
    @GetMapping("/trades") public List<Trade> trades(Authentication a) { return paper.tradeHistory(cu.get(a).getId()); }
}
