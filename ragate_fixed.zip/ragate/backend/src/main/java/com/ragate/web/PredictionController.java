package com.ragate.web;

import com.ragate.domain.RagateDecision;
import com.ragate.service.*;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/v1/predictions")
public class PredictionController {
    public record PredictReq(Long datasetId, String modelKey, String decisionHorizon, Map<String, Object> risk, Map<String, Object> decision) {}
    private final PredictionService svc; private final CurrentUser cu;
    public PredictionController(PredictionService svc, CurrentUser cu) { this.svc = svc; this.cu = cu; }

    @PostMapping public Map<String, Object> create(@RequestBody PredictReq r, Authentication a) {
        RagateDecision d = svc.predict(cu.get(a), r.datasetId(), r.modelKey(), r.decisionHorizon(), r.risk(), r.decision());
        return view(d);
    }
    @GetMapping("/{id}") public Map<String, Object> get(@PathVariable Long id, Authentication a) { return view(svc.get(id, cu.get(a))); }
    @GetMapping public List<Map<String, Object>> recent(Authentication a) {
        return svc.recent(cu.get(a)).stream().map(d -> Map.<String, Object>of("id", d.getId(), "symbol", d.getSymbol(), "asof", d.getAsof().toString(),
                "action", d.getAction(), "combinedReturn", d.getCombinedReturn() == null ? 0.0 : d.getCombinedReturn(), "createdAt", d.getCreatedAt().toString())).toList();
    }
    @GetMapping("/reliability/{modelKey}") public Map<String, Object> reliability(@PathVariable String modelKey) { return svc.reliability(modelKey); }

    private Map<String, Object> view(RagateDecision d) {
        Map<String, Object> m = new java.util.LinkedHashMap<>(d.getPayload()); m.put("id", d.getId()); m.put("modelKey", d.getModelKey()); m.put("datasetId", d.getDatasetId()); return m;
    }
}
