CREATE TABLE users (
  id BIGSERIAL PRIMARY KEY, username VARCHAR(50) NOT NULL UNIQUE, email VARCHAR(255) NOT NULL UNIQUE,
  password_hash VARCHAR(100) NOT NULL, role VARCHAR(20) NOT NULL DEFAULT 'USER', created_at TIMESTAMPTZ NOT NULL DEFAULT now());

CREATE TABLE assets (
  symbol VARCHAR(20) PRIMARY KEY, base_asset VARCHAR(20), quote_asset VARCHAR(20),
  tick_size NUMERIC(24,12) NOT NULL, step_size NUMERIC(24,12) NOT NULL, min_notional NUMERIC(24,8) NOT NULL,
  source VARCHAR(20) NOT NULL DEFAULT 'BINANCE', updated_at TIMESTAMPTZ NOT NULL DEFAULT now());

CREATE TABLE datasets (
  id BIGSERIAL PRIMARY KEY, owner_id BIGINT NOT NULL REFERENCES users(id), name VARCHAR(255) NOT NULL,
  source VARCHAR(20) NOT NULL, symbol VARCHAR(30), interval_seconds DOUBLE PRECISION, row_count INT, column_count INT,
  start_ts TIMESTAMPTZ, end_ts TIMESTAMPTZ, missing_pct DOUBLE PRECISION, quality_status VARCHAR(20), status VARCHAR(20) NOT NULL,
  upload_path VARCHAR(300), error_message TEXT, mapping JSONB, report JSONB, cleaning_log JSONB,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now());
CREATE INDEX idx_datasets_owner ON datasets(owner_id, created_at DESC);

CREATE TABLE market_candles (
  dataset_id BIGINT NOT NULL REFERENCES datasets(id) ON DELETE CASCADE, open_time TIMESTAMPTZ NOT NULL,
  symbol VARCHAR(30), interval_seconds DOUBLE PRECISION,
  open DOUBLE PRECISION NOT NULL, high DOUBLE PRECISION NOT NULL, low DOUBLE PRECISION NOT NULL, close DOUBLE PRECISION NOT NULL,
  volume DOUBLE PRECISION, PRIMARY KEY (dataset_id, open_time));
CREATE INDEX idx_candles_symbol_time ON market_candles(symbol, interval_seconds, open_time);

-- computed on demand by the ML service; reserved for caching (not populated in v1)
CREATE TABLE market_features (
  dataset_id BIGINT NOT NULL REFERENCES datasets(id) ON DELETE CASCADE, open_time TIMESTAMPTZ NOT NULL,
  features JSONB NOT NULL, PRIMARY KEY (dataset_id, open_time));

CREATE TABLE market_regimes (
  dataset_id BIGINT NOT NULL REFERENCES datasets(id) ON DELETE CASCADE, open_time TIMESTAMPTZ NOT NULL, model_key VARCHAR(120) NOT NULL,
  bull DOUBLE PRECISION, range_p DOUBLE PRECISION, stress DOUBLE PRECISION, label VARCHAR(10),
  PRIMARY KEY (dataset_id, open_time, model_key));

CREATE TABLE model_registry (
  id BIGSERIAL PRIMARY KEY, model_key VARCHAR(120) UNIQUE, dataset_id BIGINT REFERENCES datasets(id) ON DELETE SET NULL,
  symbol VARCHAR(30), interval_seconds DOUBLE PRECISION, status VARCHAR(20) NOT NULL, error TEXT,
  metrics JSONB, meta JSONB, created_by BIGINT REFERENCES users(id), created_at TIMESTAMPTZ NOT NULL DEFAULT now());

CREATE TABLE model_metrics (
  id BIGSERIAL PRIMARY KEY, model_key VARCHAR(120) NOT NULL, scope VARCHAR(20) NOT NULL, expert VARCHAR(30) NOT NULL,
  horizon VARCHAR(10) NOT NULL, metric VARCHAR(40) NOT NULL, value DOUBLE PRECISION, created_at TIMESTAMPTZ NOT NULL DEFAULT now());
CREATE INDEX idx_model_metrics ON model_metrics(model_key, scope);

CREATE TABLE expert_predictions (
  id BIGSERIAL PRIMARY KEY, model_key VARCHAR(120) NOT NULL, symbol VARCHAR(30) NOT NULL, expert VARCHAR(30) NOT NULL,
  horizon VARCHAR(10) NOT NULL, asof TIMESTAMPTZ NOT NULL, target_end TIMESTAMPTZ NOT NULL,
  predicted_return DOUBLE PRECISION, prob_positive DOUBLE PRECISION, uncertainty DOUBLE PRECISION,
  actual_return DOUBLE PRECISION, loss DOUBLE PRECISION, scored BOOLEAN NOT NULL DEFAULT FALSE, scored_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  CONSTRAINT uq_prediction UNIQUE (model_key, symbol, expert, horizon, asof));
CREATE INDEX idx_pred_pending ON expert_predictions(model_key, symbol, horizon, scored, target_end);

CREATE TABLE expert_reliability (
  id BIGSERIAL PRIMARY KEY, model_key VARCHAR(120) NOT NULL, symbol VARCHAR(30) NOT NULL, horizon VARCHAR(10) NOT NULL,
  state JSONB NOT NULL, updated_at TIMESTAMPTZ NOT NULL DEFAULT now(), CONSTRAINT uq_reliability UNIQUE (model_key, symbol, horizon));

CREATE TABLE ragate_decisions (
  id BIGSERIAL PRIMARY KEY, user_id BIGINT NOT NULL REFERENCES users(id), model_key VARCHAR(120) NOT NULL, dataset_id BIGINT,
  symbol VARCHAR(30) NOT NULL, horizon VARCHAR(10) NOT NULL, asof TIMESTAMPTZ NOT NULL, action VARCHAR(10) NOT NULL,
  target_weight DOUBLE PRECISION, combined_return DOUBLE PRECISION, uncertainty DOUBLE PRECISION,
  weights JSONB, regime JSONB, risk JSONB, reasons JSONB, payload JSONB, created_at TIMESTAMPTZ NOT NULL DEFAULT now());
CREATE INDEX idx_decisions_user ON ragate_decisions(user_id, created_at DESC);

CREATE TABLE portfolios (
  id BIGSERIAL PRIMARY KEY, owner_id BIGINT NOT NULL REFERENCES users(id), name VARCHAR(100) NOT NULL,
  base_currency VARCHAR(10) NOT NULL DEFAULT 'USDT', starting_balance NUMERIC(24,8) NOT NULL, cash NUMERIC(24,8) NOT NULL,
  paper_trading BOOLEAN NOT NULL DEFAULT TRUE CHECK (paper_trading = TRUE),   -- real-money trading is impossible by construction
  fee_rate NUMERIC(10,6) NOT NULL DEFAULT 0.001, slippage_bps NUMERIC(10,4) NOT NULL DEFAULT 5, created_at TIMESTAMPTZ NOT NULL DEFAULT now());

CREATE TABLE positions (
  id BIGSERIAL PRIMARY KEY, portfolio_id BIGINT NOT NULL REFERENCES portfolios(id) ON DELETE CASCADE, symbol VARCHAR(30) NOT NULL,
  quantity NUMERIC(28,10) NOT NULL DEFAULT 0 CHECK (quantity >= 0), avg_cost NUMERIC(24,8) NOT NULL DEFAULT 0,
  realized_pnl NUMERIC(24,8) NOT NULL DEFAULT 0, CONSTRAINT uq_position UNIQUE (portfolio_id, symbol));

CREATE TABLE orders (
  id BIGSERIAL PRIMARY KEY, portfolio_id BIGINT NOT NULL REFERENCES portfolios(id) ON DELETE CASCADE, symbol VARCHAR(30) NOT NULL,
  side VARCHAR(4) NOT NULL, quantity NUMERIC(28,10) NOT NULL, filled_quantity NUMERIC(28,10), ref_price NUMERIC(24,8),
  exec_price NUMERIC(24,8), fee NUMERIC(24,8), slippage_cost NUMERIC(24,8), status VARCHAR(10) NOT NULL, reject_reason TEXT,
  source VARCHAR(10) NOT NULL, decision_id BIGINT, dataset_id BIGINT, paper BOOLEAN NOT NULL DEFAULT TRUE CHECK (paper = TRUE),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now());
CREATE INDEX idx_orders_portfolio ON orders(portfolio_id, created_at DESC);

CREATE TABLE trades (
  id BIGSERIAL PRIMARY KEY, portfolio_id BIGINT NOT NULL REFERENCES portfolios(id) ON DELETE CASCADE, order_id BIGINT REFERENCES orders(id),
  symbol VARCHAR(30) NOT NULL, side VARCHAR(4) NOT NULL, quantity NUMERIC(28,10) NOT NULL, price NUMERIC(24,8) NOT NULL,
  fee NUMERIC(24,8) NOT NULL, realized_pnl NUMERIC(24,8) NOT NULL DEFAULT 0, executed_at TIMESTAMPTZ NOT NULL DEFAULT now());
CREATE INDEX idx_trades_portfolio ON trades(portfolio_id, executed_at DESC);

CREATE TABLE portfolio_snapshots (
  id BIGSERIAL PRIMARY KEY, portfolio_id BIGINT NOT NULL REFERENCES portfolios(id) ON DELETE CASCADE, ts TIMESTAMPTZ NOT NULL DEFAULT now(),
  equity NUMERIC(24,8) NOT NULL, cash NUMERIC(24,8) NOT NULL, unrealized_pnl NUMERIC(24,8) NOT NULL DEFAULT 0);
CREATE INDEX idx_snapshots ON portfolio_snapshots(portfolio_id, ts);

CREATE TABLE backtest_runs (
  id BIGSERIAL PRIMARY KEY, owner_id BIGINT NOT NULL REFERENCES users(id), config JSONB NOT NULL, status VARCHAR(10) NOT NULL,
  result JSONB, error TEXT, created_at TIMESTAMPTZ NOT NULL DEFAULT now(), finished_at TIMESTAMPTZ);
