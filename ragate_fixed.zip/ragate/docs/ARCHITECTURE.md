# Architecture and diagrams (Mermaid; render in VS Code with a Mermaid extension or on GitHub)

## System architecture
```mermaid
flowchart LR
  U[Browser: React] -->|JWT REST| B[Spring Boot :8080]
  B -->|JPA / Flyway| DB[(PostgreSQL :5432)]
  B -->|X-Internal-Key| M[FastAPI ML :8000]
  M -->|REST + WebSocket public data| BN[Binance Spot]
  B <-->|shared folder| S[(storage: uploads, datasets, models)]
  M <--> S
```

## Data flow (prediction)
```mermaid
sequenceDiagram
  participant UI
  participant SB as Spring Boot
  participant ML as ML service
  participant DB as PostgreSQL
  UI->>SB: POST /predictions {dataset, model}
  SB->>ML: /predict (features, HMM, 3 experts)
  ML-->>SB: expert outputs + regime probs
  SB->>DB: load unscored matured forecasts + reliability state
  SB->>ML: /ragate/evaluate (score matured, EWMA, CUSUM, weights, combine)
  ML-->>SB: weights, combined, uncertainty, new state
  SB->>DB: save scores, state, new forecasts
  SB->>ML: /risk/evaluate (costs, caps, veto, decision)
  ML-->>SB: risk + decision + reasons
  SB->>DB: save ragate_decision
  SB-->>UI: full explanation
```

## Use cases
```mermaid
flowchart TB
  A((Researcher)) --> U1[Register / log in]
  A --> U2[Upload or fetch dataset]
  A --> U3[Review quality, map columns, clean]
  A --> U4[Train models - admin]
  A --> U5[Run prediction and read explanation]
  A --> U6[Execute decision in paper portfolio]
  A --> U7[Run backtest and compare strategies]
  A --> U8[Inspect research results]
```

## Database ER diagram
```mermaid
erDiagram
  users ||--o{ datasets : owns
  users ||--o{ portfolios : owns
  users ||--o{ ragate_decisions : requests
  users ||--o{ backtest_runs : runs
  datasets ||--o{ market_candles : contains
  datasets ||--o{ market_regimes : has
  datasets ||--o{ market_features : caches
  datasets ||--o{ model_registry : trains
  model_registry ||--o{ model_metrics : reports
  model_registry ||--o{ expert_predictions : emits
  model_registry ||--o{ expert_reliability : tracks
  model_registry ||--o{ ragate_decisions : produces
  portfolios ||--o{ positions : holds
  portfolios ||--o{ orders : places
  orders ||--o{ trades : fills
  portfolios ||--o{ portfolio_snapshots : records
  assets ||--o{ positions : "symbol filters"
```
(Relations to `model_key` are logical; `model_key` is a stable string identifier, see `V1__init.sql`.)

## Algorithm notes
* Forecast target: `ln(close[t+h] / close[t])`, h = 6/18/30 candles at 4h.
* Loss: `min(((pred − actual)/s)², 10)` with `s = max(σ₅₀·√h, 0.25·σ_train,h)`, volatility known at forecast time.
* EWMA: `L ← λL + (1−λ)ℓ`, λ=0.9; shrinkage `(nL + n₀·1)/(n + n₀)`, n₀=10.
* CUSUM: `S ← max(0, S + (ℓ − ref) − k)`, k=0.5, alarm at 5; `ref = max(validation loss, 0.8)`.
* Weights: `softmax((3·compat − 1·L − 2·min(S/5, 2)) / T)`.
* Combined: `μ = Σ wᵢμᵢ`; disagreement `√Σ wᵢ(μᵢ−μ)²`; `σ = scale · √(Σ wᵢσᵢ² + disagreement²) · (1 + 0.5·H_regime)`.
* Exposure cap: `max_exposure · (1 − P_stress) · clip(SNR/2) · (1 − 0.5·clip(disagreement/σ))`.
