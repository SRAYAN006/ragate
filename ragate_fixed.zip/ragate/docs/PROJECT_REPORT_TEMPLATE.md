# RAGATE project report (skeleton: write your own findings)

Sections 1-12 below are factual descriptions of this implementation. Sections 13-14 are for **your** experimental results; they are empty on purpose.

1. **Abstract**: A local research platform that forecasts crypto returns with three experts (R-CTE, XGBoost, mean reversion), conditions on HMM market regimes, weights experts by reliability (EWMA, CUSUM, regime compatibility), scales exposure with a risk engine, and evaluates everything through paper trading and cost-aware backtests.
2. **Problem statement**: Single forecasting models degrade when market regimes change, and positive forecasts are often untradeable after costs and uncertainty. Can reliability-aware weighting and adaptive exposure improve outcomes over simpler baselines?
3. **Objectives**: see the project brief (data ingestion, validation, features, HMM, experts, RAGATE, risk, decisions, paper trading, backtesting, dashboard).
4. **Existing systems**: single-model signals, static ensembles, fixed-size rule strategies (the baselines implemented here).
5. **Proposed system**: RAGATE gating plus adaptive exposure (`ARCHITECTURE.md`).
6. **Literature review outline**: regime switching (Hamilton), HMMs for markets, attention/Transformers for time series, gradient boosting for tabular finance, ensemble weighting and online model selection, CUSUM change detection (Page 1954), EWMA control charts, mean-variance and volatility targeting, backtest overfitting and purged/walk-forward validation (López de Prado).
7. **Architecture / data flow / use case / ER diagrams**: `ARCHITECTURE.md`.
8. **Modules**: see `README.md` (architecture and "How RAGATE works").
9. **Algorithms**: `ARCHITECTURE.md` notes and source code docstrings.
10. **Technology stack**: React, TypeScript, Tailwind, Lightweight Charts, Recharts, Axios; Java 21, Spring Boot, Spring Security, JPA, Flyway; Python, FastAPI, PyTorch, XGBoost, hmmlearn, scikit-learn; PostgreSQL, Docker Compose.
11. **Implementation details and testing**: `README.md`, `TESTING.md`.
12. **Limitations**: single-exchange spot data, no order-book or funding data, no short selling/leverage, per-asset backtests, R-CTE not walk-forward re-trained, results depend on the chosen period, transaction-cost model is simplified, uncertainty calibration is approximate, no live-trading validation.

13. **Results and performance analysis**: *(fill from the Backtesting and Research pages: dataset, period, split dates, forecast metrics, strategy table, fusion comparison, walk-forward folds. Report negative results too. Do not extrapolate to future profits.)*
14. **Screenshots**: *(capture from your running instance.)*
15. **Future enhancements**: R-CTE walk-forward retraining, order-book features, shared-cash multi-asset backtester, probability calibration (isotonic), cost-sensitive thresholds, Testcontainers integration tests, Docker images for every service.
16. **Conclusion**: *(write after your results.)*
17. **Installation manual**: `README.md`.
