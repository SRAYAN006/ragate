# RAGATE repair notes

This archive contains the source project with the following repair changes:

- Pinned Lombok to 1.18.42 and explicitly configured Maven annotation processing. The Maven compiler targets Java 21. This addresses missing generated entity accessors and stale/inconsistent compiled classes when the backend is rebuilt cleanly.
- Updated the Windows setup script to run `mvn -U -DskipTests clean package`, so the backend is compiled during setup rather than merely resolving dependencies.
- Made Spring Security use its explicit CORS configuration source. The configured frontend origin, `http://localhost:5173`, and `http://127.0.0.1:5173` are allowed; preflight methods and headers are permitted.
- Excluded CORS `OPTIONS` preflight requests from the rate limiter.
- Set the backend JVM default timezone to UTC for consistent timestamp handling.
- Added a bounded PostgreSQL readiness wait to the startup script and checks for required setup artifacts.
- Updated the README with Windows PowerShell startup commands and troubleshooting notes.

## Validation performed while preparing this archive

- Python ML unit-test subset: **18 passed** (`tests/test_data.py` and `tests/test_ragate_risk.py`).
- Full ML test collection was blocked because `hmmlearn` was not installed in the repair environment and package-network access was unavailable.
- Frontend production build could not be completed because npm dependency installation was incomplete and the npm registry was unreachable.
- Maven backend build could not be executed because Maven was not installed in the repair environment and Maven Central was unreachable.

Therefore, this archive includes the source/configuration repairs, but the full three-service Windows runtime still needs the first successful local `setup.bat` run. Do not treat the application as integration-tested until setup completes and all services start successfully.
