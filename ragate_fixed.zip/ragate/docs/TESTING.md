# Testing

## What was actually run (generation environment, Linux, Python 3.12)

`python -m pytest tests -q` in `ml-service`: **32 passed** (~70 s on CPU).

| File | Covers |
|---|---|
| `test_data.py` | column-name detection variants, unsupported (non-financial) file rejected with message, duplicates / missing candles / OHLC violations / non-positive / non-numeric detection, explicit-choice cleaning with log, flat-candle fill logging, epoch-ms timestamps, stale-data detection |
| `test_features_regime.py` | 4h → 6/18/30-candle horizons, **no look-ahead in features** (truncating or altering the future leaves earlier rows unchanged), indicator sanity, target alignment, HMM probabilities sum to 1, **filtered probabilities are causal**, state labelling |
| `test_ragate_risk.py` | softmax weights non-negative / sum to 1 / single or no expert, matured-only scoring, **each forecast scored once**, EWMA recursion, CUSUM flags persistent (not isolated) deterioration, deteriorating expert loses weight, disagreement and uncertainty, risk costs / veto / exposure shrinkage, all five decision outcomes |
| `test_pipeline_api.py` | chronological split without overlap, three experts train and predict, predictions at a past candle are identical when the future is removed, full API flow (auth 401, predict → ragate → risk/decision, forecast maturation, regime endpoint, models list, 404, path traversal rejected, upload → validate → commit), execution timing (no look-ahead in backtest returns), metric maths, **backtest runs all 10 strategies and is reproducible**, in-sample start clamped, short dataset error |

Test data is a synthetic regime-switching series generated inside `tests/conftest.py`. It exists only to exercise the code and is never used for results.

## Validation status and limits

The results above describe the original generation environment; they are not a claim that every service has been integration-tested on every Windows machine. During the current repair pass, the ML unit-test subset that does not require `hmmlearn` ran **18 passed**. The remaining ML test modules could not be collected in this isolated environment because `hmmlearn` was not installed and package-network access was unavailable.

* Spring Boot: no Maven executable or Maven Central network access was available in the repair environment, so the updated Maven build could not be executed here. The project now pins Lombok 1.18.42 and explicitly configures annotation processing; run `mvn -U clean package` on the target Windows machine to verify the full backend build.
* Frontend: the frontend build could not be completed in this environment because the npm dependency installation was incomplete and the npm registry was unreachable. Run `npm ci` followed by `npm run build` on the target machine.
* Binance REST/WebSocket against the live API.
* GPU training.

No Java tests or browser tests are included. Recommended additions: `PaperTradingService` (fees, tick/step rounding, insufficient cash/position, decision execution idempotency), JWT auth flow, and a PostgreSQL integration test with Testcontainers.

## Observed caveat (honest)

On the synthetic series the experts showed little skill and the gated strategies mostly stayed in cash, which is the intended conservative behaviour when forecasts do not exceed trading costs. That says nothing about real crypto data. Run the backtester on your own datasets and report what you find, including negative results.
