import { NavLink, Navigate, Route, Routes } from 'react-router-dom'
import { useAuth } from './auth'
import { PaperBadge } from './components/ui'
import Login from './pages/Login'
import Dashboard from './pages/Dashboard'
import Datasets from './pages/Datasets'
import Analysis from './pages/Analysis'
import Models from './pages/Models'
import Predictions from './pages/Predictions'
import Portfolio from './pages/Portfolio'
import Backtest from './pages/Backtest'
import Research from './pages/Research'
import Settings from './pages/Settings'

const NAV = [
  ['/', 'Dashboard'], ['/datasets', 'Datasets & data quality'], ['/analysis', 'Features & regimes'], ['/models', 'Model registry'],
  ['/predictions', 'Predictions & RAGATE'], ['/portfolio', 'Paper portfolio'], ['/backtest', 'Backtesting'], ['/research', 'Research results'], ['/settings', 'Settings']
]

export default function App() {
  const { user, logout } = useAuth()
  if (!user) return <Routes><Route path="/login" element={<Login />} /><Route path="*" element={<Navigate to="/login" replace />} /></Routes>
  return (
    <div className="flex h-full">
      <aside className="flex w-56 shrink-0 flex-col border-r border-line bg-panel">
        <div className="px-5 py-5"><div className="text-lg font-semibold tracking-tight">RAGATE</div><div className="text-xs text-mute">Reliability-aware gating</div></div>
        <nav className="flex-1 space-y-0.5 px-2">
          {NAV.map(([to, label]) => (
            <NavLink key={to} to={to} end={to === '/'} className={({ isActive }) => `block rounded px-3 py-2 text-sm ${isActive ? 'bg-raised text-ink border-l-2 border-accent' : 'text-mute hover:text-ink'}`}>{label}</NavLink>
          ))}
        </nav>
        <div className="border-t border-line p-4 text-xs text-mute"><div className="text-ink">{user.username} <span className="text-mute">({user.role})</span></div>
          <button className="mt-2 underline hover:text-ink" onClick={logout}>Sign out</button></div>
      </aside>
      <main className="flex-1 overflow-y-auto">
        <div className="sticky top-0 z-10 flex items-center justify-between border-b border-line bg-bg/95 px-8 py-2 backdrop-blur">
          <span className="text-xs text-mute">Research platform. No real-money orders are ever sent.</span><PaperBadge />
        </div>
        <div className="mx-auto max-w-[1400px] p-8">
          <Routes>
            <Route path="/" element={<Dashboard />} /><Route path="/datasets" element={<Datasets />} /><Route path="/analysis" element={<Analysis />} />
            <Route path="/models" element={<Models />} /><Route path="/predictions" element={<Predictions />} /><Route path="/portfolio" element={<Portfolio />} />
            <Route path="/backtest" element={<Backtest />} /><Route path="/research" element={<Research />} /><Route path="/settings" element={<Settings />} />
            <Route path="/login" element={<Navigate to="/" replace />} /><Route path="*" element={<Navigate to="/" replace />} />
          </Routes>
        </div>
      </main>
    </div>
  )
}
