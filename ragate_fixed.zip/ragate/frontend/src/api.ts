import axios from 'axios'

export const api = axios.create({ baseURL: import.meta.env.VITE_API_URL || 'http://localhost:8080' })

api.interceptors.request.use((cfg) => {
  const t = localStorage.getItem('ragate_token')
  if (t) cfg.headers.Authorization = `Bearer ${t}`
  return cfg
})
api.interceptors.response.use(
  (r) => r,
  (e) => {
    if (e.response?.status === 401 && !location.pathname.startsWith('/login')) {
      localStorage.removeItem('ragate_token'); localStorage.removeItem('ragate_user'); location.href = '/login'
    }
    return Promise.reject(e)
  }
)

export function errMsg(e: any): string {
  const d = e?.response?.data
  if (typeof d === 'string') { try { const j = JSON.parse(d); return j.message || d } catch { return d } }
  if (d?.message) { try { const j = JSON.parse(d.message); return j.message || d.message } catch { return d.message } }
  if (e?.code === 'ERR_NETWORK') return 'Cannot reach the backend on port 8080. Is it running?'
  return e?.message || 'Request failed'
}

export const pct = (x: any, d = 2) => (x == null || !isFinite(x) ? '–' : (x * 100).toFixed(d) + '%')
export const num = (x: any, d = 2) => (x == null || !isFinite(x) ? '–' : Number(x).toLocaleString(undefined, { maximumFractionDigits: d, minimumFractionDigits: d }))
