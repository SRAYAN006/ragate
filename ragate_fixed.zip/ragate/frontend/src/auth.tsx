import { createContext, useContext, useState, ReactNode } from 'react'

type User = { id: number; username: string; email: string; role: string }
type Ctx = { user: User | null; login: (token: string, u: User) => void; logout: () => void }
const C = createContext<Ctx>({ user: null, login: () => {}, logout: () => {} })

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(() => {
    try { return JSON.parse(localStorage.getItem('ragate_user') || 'null') } catch { return null }
  })
  const login = (token: string, u: User) => { localStorage.setItem('ragate_token', token); localStorage.setItem('ragate_user', JSON.stringify(u)); setUser(u) }
  const logout = () => { localStorage.removeItem('ragate_token'); localStorage.removeItem('ragate_user'); setUser(null) }
  return <C.Provider value={{ user, login, logout }}>{children}</C.Provider>
}
export const useAuth = () => useContext(C)
