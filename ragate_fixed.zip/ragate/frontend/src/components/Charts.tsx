import { useEffect, useRef } from 'react'
import { createChart, ColorType, IChartApi, UTCTimestamp } from 'lightweight-charts'
import { Area, AreaChart, CartesianGrid, Legend, Line, LineChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts'

const toTime = (s: string) => (Date.parse(s) / 1000) as UTCTimestamp

export function CandleChart({ candles, height = 360 }: { candles: any[]; height?: number }) {
  const ref = useRef<HTMLDivElement>(null)
  useEffect(() => {
    if (!ref.current) return
    const chart: IChartApi = createChart(ref.current, {
      height, layout: { background: { type: ColorType.Solid, color: '#141416' }, textColor: '#8b8b92' },
      grid: { vertLines: { color: '#1f1f22' }, horzLines: { color: '#1f1f22' } }, rightPriceScale: { borderColor: '#2a2a2e' },
      timeScale: { borderColor: '#2a2a2e', timeVisible: true }, autoSize: true
    })
    const s = chart.addCandlestickSeries({ upColor: '#4fb286', downColor: '#d9484a', borderVisible: false, wickUpColor: '#4fb286', wickDownColor: '#d9484a' })
    s.setData(candles.map((c) => ({ time: toTime(c.timestamp), open: c.open, high: c.high, low: c.low, close: c.close })))
    if (candles.some((c) => c.volume != null)) {
      const v = chart.addHistogramSeries({ priceFormat: { type: 'volume' }, priceScaleId: '' })
      v.priceScale().applyOptions({ scaleMargins: { top: 0.82, bottom: 0 } })
      v.setData(candles.map((c) => ({ time: toTime(c.timestamp), value: c.volume ?? 0, color: c.close >= c.open ? '#4fb28655' : '#d9484a55' })))
    }
    chart.timeScale().fitContent()
    return () => chart.remove()
  }, [candles, height])
  return <div ref={ref} style={{ height }} />
}

const axis = { stroke: '#8b8b92', fontSize: 11 }
const tip = { contentStyle: { background: '#1b1b1e', border: '1px solid #2a2a2e', fontSize: 12 }, labelStyle: { color: '#8b8b92' } }
const PALETTE = ['#d9484a', '#4fb286', '#d9a441', '#6b8fd6', '#a98bd6', '#d68bb6', '#8b8b92', '#e8e6e3', '#58b9c4', '#c4a258']

export function Lines({ data, keys, x = 't', height = 240, pctAxis = false, domain }: { data: any[]; keys: string[]; x?: string; height?: number; pctAxis?: boolean; domain?: any }) {
  return (
    <ResponsiveContainer width="100%" height={height}>
      <LineChart data={data} margin={{ left: 0, right: 8, top: 4 }}>
        <CartesianGrid stroke="#1f1f22" /><XAxis dataKey={x} {...axis} tickFormatter={(v) => String(v).slice(5, 10)} minTickGap={40} />
        <YAxis {...axis} width={56} domain={domain} tickFormatter={(v) => (pctAxis ? (v * 100).toFixed(0) + '%' : Number(v).toLocaleString(undefined, { maximumFractionDigits: 2 }))} />
        <Tooltip {...tip} /><Legend wrapperStyle={{ fontSize: 11 }} />
        {keys.map((k, i) => <Line key={k} type="monotone" dataKey={k} stroke={PALETTE[i % PALETTE.length]} dot={false} strokeWidth={1.5} isAnimationActive={false} />)}
      </LineChart>
    </ResponsiveContainer>
  )
}

export function Stacked({ data, keys, x = 't', height = 220 }: { data: any[]; keys: string[]; x?: string; height?: number }) {
  const colors: any = { bull: '#4fb286', range: '#8b8b92', stress: '#d9484a' }
  return (
    <ResponsiveContainer width="100%" height={height}>
      <AreaChart data={data} margin={{ left: 0, right: 8, top: 4 }}>
        <CartesianGrid stroke="#1f1f22" /><XAxis dataKey={x} {...axis} tickFormatter={(v) => String(v).slice(5, 10)} minTickGap={40} />
        <YAxis {...axis} width={40} domain={[0, 1]} tickFormatter={(v) => (v * 100).toFixed(0) + '%'} /><Tooltip {...tip} /><Legend wrapperStyle={{ fontSize: 11 }} />
        {keys.map((k, i) => <Area key={k} type="monotone" dataKey={k} stackId="1" stroke={colors[k] || PALETTE[i]} fill={colors[k] || PALETTE[i]} fillOpacity={0.55} isAnimationActive={false} />)}
      </AreaChart>
    </ResponsiveContainer>
  )
}
