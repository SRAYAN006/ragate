import { ReactNode, useEffect, useState } from 'react'
import { errMsg } from '../api'
import { useSelection } from '../selection'

export const Card = ({ title, right, children, className = '' }: { title?: string; right?: ReactNode; children: ReactNode; className?: string }) => (
  <section className={`rounded-md border border-line bg-panel ${className}`}>
    {(title || right) && (
      <header className="flex items-center justify-between border-b border-line px-4 py-2.5">
        <h3 className="text-sm font-medium text-ink">{title}</h3><div>{right}</div>
      </header>
    )}
    <div className="p-4">{children}</div>
  </section>
)

export const Stat = ({ label, value, sub, tone }: { label: string; value: ReactNode; sub?: ReactNode; tone?: 'good' | 'bad' }) => (
  <div className="rounded-md border border-line bg-panel px-4 py-3">
    <div className="text-xs text-mute">{label}</div>
    <div className={`mt-1 text-xl font-semibold tabular-nums ${tone === 'good' ? 'text-good' : tone === 'bad' ? 'text-accent' : ''}`}>{value}</div>
    {sub && <div className="mt-0.5 text-xs text-mute">{sub}</div>}
  </div>
)

export const Btn = ({ children, onClick, disabled, kind = 'primary', type = 'button' }: any) => (
  <button type={type} onClick={onClick} disabled={disabled}
    className={`rounded px-3.5 py-1.5 text-sm font-medium transition-colors disabled:opacity-40 ${kind === 'primary' ? 'bg-accent text-white hover:bg-[#e25a5c]' : 'border border-line bg-raised text-ink hover:border-mute'}`}>
    {children}
  </button>
)

export const Notice = ({ kind = 'error', children }: { kind?: 'error' | 'info' | 'warn'; children: ReactNode }) => (
  <div className={`rounded border px-3 py-2 text-sm ${kind === 'error' ? 'border-accentDim bg-[#2a1517] text-[#f0a3a4]' : kind === 'warn' ? 'border-[#5c4a1e] bg-[#241f12] text-warn' : 'border-line bg-raised text-mute'}`}>{children}</div>
)

export const Badge = ({ children, tone = 'neutral' }: { children: ReactNode; tone?: 'good' | 'bad' | 'warn' | 'neutral' }) => (
  <span className={`rounded px-2 py-0.5 text-xs font-medium ${tone === 'good' ? 'bg-[#16301f] text-good' : tone === 'bad' ? 'bg-[#3a1b1d] text-accent' : tone === 'warn' ? 'bg-[#3a2f14] text-warn' : 'bg-raised text-mute'}`}>{children}</span>
)

export const PaperBadge = () => <span className="rounded border border-accentDim px-2 py-0.5 text-xs font-semibold text-accent">PAPER TRADING</span>

export const actionTone = (a: string) => (a === 'BUY' ? 'good' : a === 'EXIT' || a === 'REDUCE' ? 'bad' : a === 'ABSTAIN' ? 'warn' : 'neutral')

export function PageHead({ title, desc, right }: { title: string; desc?: string; right?: ReactNode }) {
  return (
    <div className="mb-5 flex flex-wrap items-end justify-between gap-3">
      <div><h1 className="text-xl font-semibold">{title}</h1>{desc && <p className="mt-1 max-w-3xl text-sm text-mute">{desc}</p>}</div>{right}
    </div>
  )
}

export function Bar({ value, color = '#d9484a' }: { value: number; color?: string }) {
  return <div className="h-1.5 w-full rounded bg-raised"><div className="h-1.5 rounded" style={{ width: `${Math.max(0, Math.min(1, value)) * 100}%`, background: color }} /></div>
}

export function Pickers({ needModel = true }: { needModel?: boolean }) {
  const { datasets, models, datasetId, modelKey, setDatasetId, setModelKey } = useSelection()
  const ready = datasets.filter((d) => d.status === 'READY')
  const mods = models.filter((m) => m.status === 'READY' && (!datasetId || true))
  return (
    <div className="flex flex-wrap gap-2">
      <select value={datasetId ?? ''} onChange={(e) => setDatasetId(e.target.value ? Number(e.target.value) : undefined)} aria-label="Dataset">
        <option value="">Select dataset…</option>
        {ready.map((d) => <option key={d.id} value={d.id}>{d.name} · {d.symbol}</option>)}
      </select>
      {needModel && (
        <select value={modelKey ?? ''} onChange={(e) => setModelKey(e.target.value || undefined)} aria-label="Model">
          <option value="">Select model…</option>
          {mods.map((m) => <option key={m.modelKey} value={m.modelKey}>{m.modelKey}</option>)}
        </select>
      )}
    </div>
  )
}

export function useLoad<T>(fn: () => Promise<T>, deps: any[], refreshMs?: number) {
  const [data, setData] = useState<T | null>(null)
  const [error, setError] = useState<string | null>(null)
  const [loading, setLoading] = useState(false)
  useEffect(() => {
    let alive = true
    const run = () => { setLoading(true); fn().then((d) => { if (alive) { setData(d); setError(null) } }).catch((e) => { if (alive) setError(errMsg(e)) }).finally(() => alive && setLoading(false)) }
    run()
    const t = refreshMs ? setInterval(run, refreshMs) : undefined
    return () => { alive = false; if (t) clearInterval(t) }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, deps)
  return { data, error, loading }
}
