import { useState } from 'react'
import { api, pct } from '../api'
import { Badge, Card, Notice, PageHead, Pickers, useLoad } from '../components/ui'
import { Lines, Stacked } from '../components/Charts'
import { useSelection } from '../selection'

export default function Analysis() {
  const { datasetId, modelKey } = useSelection()
  const feats = useLoad(() => (datasetId ? api.get(`/api/v1/datasets/${datasetId}/features?tail=600`).then((r) => r.data) : Promise.resolve(null)), [datasetId])
  const reg = useLoad(() => (datasetId && modelKey ? api.get(`/api/v1/models/${modelKey}/regime?datasetId=${datasetId}&tail=600`).then((r) => r.data) : Promise.resolve(null)), [datasetId, modelKey])
  const [sel, setSel] = useState<string[]>(['rsi_14'])
  const all: string[] = feats.data ? [...feats.data.available_model_features, ...feats.data.chart_columns.filter((c: string) => !feats.data.available_model_features.includes(c))] : []
  const toggle = (k: string) => setSel(sel.includes(k) ? sel.filter((x) => x !== k) : [...sel, k].slice(-4))
  const labels = ['bull', 'range', 'stress']
  return (
    <>
      <PageHead title="Features and market regimes" desc="Feature values are causal: each row uses only data up to that candle. Regime probabilities are filtered (no look-ahead) from the HMM trained on the training period only." right={<Pickers />} />
      {!datasetId && <Notice kind="info">Select a dataset first.</Notice>}
      {feats.error && <Notice>{feats.error}</Notice>}
      {feats.data && (
        <Card title="Feature explorer (pick up to 4)">
          <div className="mb-3 flex max-h-28 flex-wrap gap-1.5 overflow-y-auto">
            {all.map((k) => <button key={k} onClick={() => toggle(k)} className={`rounded border px-2 py-0.5 text-xs ${sel.includes(k) ? 'border-accent text-ink' : 'border-line text-mute'}`}>{k}</button>)}
          </div>
          <Lines data={feats.data.rows} keys={sel} x="timestamp" height={280} />
          <p className="mt-2 text-xs text-mute">Models use the scale-free subset ({feats.data.available_model_features.length} features); raw EMA/SMA/MACD/Bollinger levels are shown for charting only.</p>
        </Card>
      )}
      <div className="mt-4" />
      {datasetId && !modelKey && <Notice kind="info">Select a trained model to see its regime monitor.</Notice>}
      {reg.error && <Notice>{reg.error}</Notice>}
      {reg.data && (
        <div className="grid grid-cols-3 gap-4">
          <Card title="Filtered regime probabilities" className="col-span-2"><Stacked data={reg.data.rows} keys={labels} x="timestamp" /></Card>
          <Card title="Current state">
            <div className="mb-2 text-sm">Dominant: <Badge tone={reg.data.summary.current_label === 'stress' ? 'bad' : reg.data.summary.current_label === 'bull' ? 'good' : 'neutral'}>{reg.data.summary.current_label}</Badge></div>
            <table><tbody>{labels.map((l) => <tr key={l}><td className="capitalize">{l}</td><td className="num">{pct(reg.data.summary.current[l], 1)}</td></tr>)}
              <tr><td>Run length</td><td className="num">{reg.data.summary.run_length} candles</td></tr><tr><td>Stability (recent)</td><td className="num">{pct(reg.data.summary.stability, 0)}</td></tr></tbody></table>
            <h4 className="mb-1 mt-4 text-sm font-medium">Transition matrix</h4>
            <table><thead><tr><th>from \ to</th>{labels.map((l) => <th key={l} className="num">{l}</th>)}</tr></thead><tbody>
              {reg.data.transition_matrix.map((row: number[], i: number) => <tr key={i}><td>{labels[i]}</td>{row.map((v, j) => <td key={j} className="num">{pct(v, 1)}</td>)}</tr>)}</tbody></table>
          </Card>
          <Card title="Recent transitions" className="col-span-3"><table><thead><tr><th>Time</th><th>From</th><th>To</th></tr></thead><tbody>
            {(reg.data.summary.recent_transitions || []).slice().reverse().map((t: any, i: number) => <tr key={i}><td>{t.timestamp.slice(0, 16)}</td><td>{t.from}</td><td>{t.to}</td></tr>)}</tbody></table></Card>
        </div>
      )}
    </>
  )
}
