import { useEffect, useState } from 'react'
import { api, errMsg, num, pct } from '../api'
import { Badge, Btn, Card, Notice, PageHead } from '../components/ui'
import { Lines } from '../components/Charts'
import { useSelection } from '../selection'

const ORDER = ['Buy and Hold', 'Equal-Weight Portfolio', 'MA Crossover', 'RSI Strategy', 'Standalone XGBoost', 'Standalone R-CTE', 'Standalone Mean Reversion', 'Static Equal-Weight Ensemble', 'Regime-Aware Static Ensemble', 'Full RAGATE']

export default function Backtest() {
  const { datasets, models, datasetId, modelKey } = useSelection()
  const [rows, setRows] = useState<{ datasetId?: number; modelKey?: string }[]>([{}])
  const [f, setF] = useState({ start: '', end: '', initialCapital: 10000, fee: 0.1, slip: 5, horizon: '1d' })
  const [run, setRun] = useState<any>(null); const [err, setErr] = useState<string | null>(null)
  useEffect(() => { if (datasetId && modelKey && !rows[0].datasetId) setRows([{ datasetId, modelKey }]) }, [datasetId, modelKey])
  useEffect(() => {
    if (run?.status !== 'RUNNING') return
    const t = setInterval(async () => { try { setRun((await api.get(`/api/v1/backtests/${run.id}`)).data) } catch { /* retry */ } }, 3000)
    return () => clearInterval(t)
  }, [run?.id, run?.status])
  const go = async () => {
    setErr(null)
    try {
      const body: any = { assets: rows.filter((r) => r.datasetId && r.modelKey), initialCapital: f.initialCapital, horizon: f.horizon, costs: { fee_rate: f.fee / 100, slippage_bps: f.slip } }
      if (f.start) body.start = f.start; if (f.end) body.end = f.end
      setRun((await api.post('/api/v1/backtests', body)).data)
    } catch (e) { setErr(errMsg(e)) }
  }
  const res = run?.result
  const curve = res ? res.curves['Full RAGATE'].map((p: any, i: number) => ({ t: p.t, ...Object.fromEntries(ORDER.map((s) => [s, res.curves[s]?.[i]?.equity])) })) : []
  const ready = datasets.filter((d) => d.status === 'READY'); const mods = models.filter((m) => m.status === 'READY')
  return (
    <>
      <PageHead title="Backtesting workspace" desc="Runs on the untouched test period. Signals use data up to a candle's close and fill at the next open, after fees and slippage. Earlier start dates are clamped unless you explicitly allow in-sample." />
      {err && <div className="mb-4"><Notice>{err}</Notice></div>}
      <Card title="Configuration">
        {rows.map((r, i) => (
          <div key={i} className="mb-2 flex gap-2 text-sm">
            <select value={r.datasetId ?? ''} onChange={(e) => setRows(rows.map((x, j) => (j === i ? { ...x, datasetId: Number(e.target.value) } : x)))}><option value="">Dataset…</option>{ready.map((d) => <option key={d.id} value={d.id}>{d.name} · {d.symbol}</option>)}</select>
            <select value={r.modelKey ?? ''} onChange={(e) => setRows(rows.map((x, j) => (j === i ? { ...x, modelKey: e.target.value } : x)))}><option value="">Model…</option>{mods.map((m) => <option key={m.modelKey} value={m.modelKey}>{m.modelKey}</option>)}</select>
            {rows.length > 1 && <Btn kind="ghost" onClick={() => setRows(rows.filter((_, j) => j !== i))}>Remove</Btn>}
          </div>))}
        <Btn kind="ghost" onClick={() => setRows([...rows, {}])}>Add asset</Btn>
        <div className="mt-4 flex flex-wrap items-end gap-3 text-sm">
          <label>Start<input type="date" className="block" value={f.start} onChange={(e) => setF({ ...f, start: e.target.value })} /></label>
          <label>End<input type="date" className="block" value={f.end} onChange={(e) => setF({ ...f, end: e.target.value })} /></label>
          <label>Capital<input type="number" className="block w-28" value={f.initialCapital} onChange={(e) => setF({ ...f, initialCapital: +e.target.value })} /></label>
          <label>Fee % / side<input type="number" step="0.01" className="block w-24" value={f.fee} onChange={(e) => setF({ ...f, fee: +e.target.value })} /></label>
          <label>Slippage bps<input type="number" className="block w-24" value={f.slip} onChange={(e) => setF({ ...f, slip: +e.target.value })} /></label>
          <label>Decision horizon<select className="block" value={f.horizon} onChange={(e) => setF({ ...f, horizon: e.target.value })}><option>1d</option><option>3d</option><option>5d</option></select></label>
          <Btn onClick={go} disabled={run?.status === 'RUNNING'}>{run?.status === 'RUNNING' ? 'Running…' : 'Run backtest'}</Btn>
        </div>
      </Card>
      {run?.status === 'FAILED' && <div className="mt-4"><Notice>{run.error}</Notice></div>}
      {res && (<>
        {res.warnings.map((w: string, i: number) => <div key={i} className="mt-4"><Notice kind="warn">{w}</Notice></div>)}
        <Card title="Strategy comparison (simulated portfolio performance after costs)" className="mt-4">
          <table><thead><tr><th>Strategy</th><th className="num">Cumulative</th><th className="num">Annualised</th><th className="num">Sharpe</th><th className="num">Sortino</th><th className="num">Max DD</th><th className="num">CVaR 95%</th><th className="num">Win rate</th><th className="num">Profit factor</th><th className="num">Turnover</th><th className="num">Trades</th></tr></thead><tbody>
            {ORDER.map((s) => { const m = res.aggregate[s]; return <tr key={s} className={s === 'Full RAGATE' ? 'bg-raised' : ''}><td>{s}</td><td className="num">{pct(m.cumulative_return)}</td><td className="num">{pct(m.annualized_return)}</td><td className="num">{num(m.sharpe)}</td><td className="num">{num(m.sortino)}</td><td className="num">{pct(m.max_drawdown)}</td><td className="num">{pct(m.cvar_95, 3)}</td><td className="num">{pct(m.win_rate, 0)}</td><td className="num">{m.profit_factor == null ? '∞' : num(m.profit_factor)}</td><td className="num">{num(m.turnover_total)}</td><td className="num">{m.n_trades}</td></tr> })}</tbody></table>
        </Card>
        <Card title="Equity curves" className="mt-4"><Lines data={curve} keys={ORDER} height={320} /></Card>
        {Object.entries(res.per_asset).map(([id, a]: any) => (
          <Card key={id} title={`Dataset ${id}: forecast quality (test period ${a.period.start.slice(0, 10)} → ${a.period.end.slice(0, 10)})`} className="mt-4">
            <table><thead><tr><th>Forecaster</th><th>Horizon</th><th className="num">MAE</th><th className="num">RMSE</th><th className="num">Dir. acc.</th><th className="num">Precision</th><th className="num">Recall</th><th className="num">F1</th></tr></thead><tbody>
              {Object.entries(a.forecast_metrics).flatMap(([e, hs]: any) => Object.entries(hs).map(([h, m]: any) => <tr key={e + h}><td>{e}</td><td>{h}</td><td className="num">{num(m.mae, 5)}</td><td className="num">{num(m.rmse, 5)}</td><td className="num">{pct(m.directional_accuracy)}</td><td className="num">{pct(m.precision)}</td><td className="num">{pct(m.recall)}</td><td className="num">{num(m.f1, 3)}</td></tr>))}</tbody></table>
            <div className="mt-3 flex gap-2 text-sm text-mute">Decisions: {Object.entries(a.decisions).map(([k, v]: any) => <Badge key={k}>{k} {v}</Badge>)}{a.reliability_flags.length > 0 && <Badge tone="bad">CUSUM flags: {a.reliability_flags.join(', ')}</Badge>}</div>
          </Card>))}
        <div className="mt-4 space-y-1 text-xs text-mute">{res.notes.map((n: string, i: number) => <p key={i}>{n}</p>)}<p>Config hash {res.config_hash}</p></div>
      </>)}
    </>
  )
}
