import { useState } from 'react'
import { api, errMsg, num, pct } from '../api'
import { Badge, Bar, Btn, Card, Notice, PageHead, Pickers, Stat, actionTone, useLoad } from '../components/ui'
import { CandleChart, Lines } from '../components/Charts'
import { useSelection } from '../selection'

export default function Dashboard() {
  const { datasetId, modelKey } = useSelection()
  const mkt = useLoad(() => api.get('/api/v1/market/overview').then((r) => r.data), [], 10000)
  const candles = useLoad(() => (datasetId ? api.get(`/api/v1/datasets/${datasetId}/candles?tail=400`).then((r) => r.data.candles) : Promise.resolve(null)), [datasetId])
  const feats = useLoad(() => (datasetId ? api.get(`/api/v1/datasets/${datasetId}/features?tail=400`).then((r) => r.data.rows) : Promise.resolve(null)), [datasetId])
  const pf = useLoad(() => api.get('/api/v1/portfolio').then((r) => r.data), [], 30000)
  const [pred, setPred] = useState<any>(null); const [err, setErr] = useState<string | null>(null); const [busy, setBusy] = useState(false)
  const last = useLoad(async () => { const l = (await api.get('/api/v1/predictions')).data; return l[0] ? (await api.get(`/api/v1/predictions/${l[0].id}`)).data : null }, [pred])
  const p = pred || last.data
  const run = async () => { setBusy(true); setErr(null); try { setPred((await api.post('/api/v1/predictions', { datasetId, modelKey })).data) } catch (e) { setErr(errMsg(e)) } finally { setBusy(false) } }
  const h1 = p?.horizons?.['1d']?.ragate

  return (
    <>
      <PageHead title="Dashboard" desc="Live prices come from Binance public market data. Charts, indicators and predictions use the dataset and model you select." right={<Pickers />} />
      {mkt.error && <div className="mb-4"><Notice kind="warn">Live prices unavailable: {mkt.error}</Notice></div>}
      <div className="mb-5 grid grid-cols-3 gap-4">
        {['BTCUSDT', 'ETHUSDT', 'SOLUSDT'].map((s) => { const t = mkt.data?.[s]; return (
          <Stat key={s} label={`${s.replace('USDT', '/USDT')} · ${t?.source ?? ''}`} value={t ? num(t.price, t.price < 10 ? 4 : 2) : '–'}
            sub={t ? `${t.change_pct >= 0 ? '+' : ''}${num(t.change_pct)}% 24h` : undefined} tone={t ? (t.change_pct >= 0 ? 'good' : 'bad') : undefined} />) })}
      </div>
      <div className="mb-5 grid grid-cols-4 gap-4">
        <Stat label="Paper equity" value={pf.data ? num(Number(pf.data.equity)) : '–'} sub={pf.data?.currency} />
        <Stat label="Simulated P&L" value={pf.data ? num(Number(pf.data.totalPnl)) : '–'} tone={pf.data && Number(pf.data.totalPnl) >= 0 ? 'good' : 'bad'} />
        <Stat label="Max drawdown" value={pf.data ? pct(pf.data.maxDrawdown) : '–'} />
        <Stat label="Current decision" value={p ? <Badge tone={actionTone(p.decision.action)}>{p.decision.action}</Badge> : '–'} sub={p ? `as of ${p.asof?.slice(0, 16)}` : 'run a prediction'} />
      </div>
      <div className="grid grid-cols-3 gap-4">
        <Card title="Price and volume" className="col-span-2">
          {!datasetId ? <Notice kind="info">Select a dataset above (upload one or fetch from Binance on the Datasets page).</Notice>
            : candles.data ? <CandleChart candles={candles.data} /> : <Notice kind="info">{candles.error ?? 'Loading…'}</Notice>}
        </Card>
        <Card title="Market regime (HMM)">
          {p ? (['bull', 'range', 'stress'] as const).map((r) => (
            <div key={r} className="mb-3"><div className="mb-1 flex justify-between text-sm"><span className="capitalize">{r}</span><span className="tabular-nums">{pct(p.regime.probs[r], 1)}</span></div>
              <Bar value={p.regime.probs[r]} color={r === 'bull' ? '#4fb286' : r === 'stress' ? '#d9484a' : '#8b8b92'} /></div>)) : <Notice kind="info">No prediction yet.</Notice>}
          {p && <p className="text-xs text-mute">Dominant {p.regime.summary.current_label} for {p.regime.summary.run_length} candles</p>}
        </Card>
        <Card title="RSI (14)">{feats.data ? <Lines data={feats.data} keys={['rsi_14']} x="timestamp" height={170} domain={[0, 100]} /> : <span className="text-sm text-mute">–</span>}</Card>
        <Card title="MACD">{feats.data ? <Lines data={feats.data} keys={['macd', 'macd_signal']} x="timestamp" height={170} /> : <span className="text-sm text-mute">–</span>}</Card>
        <Card title="Prediction" right={<Btn onClick={run} disabled={!datasetId || !modelKey || busy}>{busy ? 'Running…' : 'Run prediction'}</Btn>}>
          {err && <Notice>{err}</Notice>}
          {p ? (<table><thead><tr><th>Horizon</th><th className="num">Combined</th><th className="num">Uncertainty</th></tr></thead><tbody>
            {['1d', '3d', '5d'].map((h) => { const c = p.horizons[h]?.ragate?.combined; return <tr key={h}><td>{h}</td><td className="num">{c ? pct(c.combined_return, 3) : '–'}</td><td className="num">{c ? pct(c.sigma_total, 3) : '–'}</td></tr> })}
          </tbody></table>) : <Notice kind="info">Pick a dataset and model, then run a prediction.</Notice>}
          {h1?.weights && <div className="mt-3 text-xs text-mute">Expert weights (1d): {Object.entries(h1.weights).map(([k, v]: any) => `${k} ${pct(v, 0)}`).join(' · ')}</div>}
        </Card>
      </div>
    </>
  )
}
