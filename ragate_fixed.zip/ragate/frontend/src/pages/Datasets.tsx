import { useState } from 'react'
import { api, errMsg, num } from '../api'
import { Badge, Btn, Card, Notice, PageHead, useLoad } from '../components/ui'
import { CandleChart } from '../components/Charts'
import { useSelection } from '../selection'

const CANON = ['timestamp', 'open', 'high', 'low', 'close', 'volume', 'symbol', 'quote_volume', 'trade_count']
const tone = (s: string) => (s === 'PASS' || s === 'READY' ? 'good' : s === 'WARN' || s === 'NEEDS_REVIEW' ? 'warn' : s === 'FAIL' || s === 'UNSUPPORTED' || s === 'FAILED' || s === 'REJECTED' ? 'bad' : 'neutral')

export default function Datasets() {
  const { datasets, reload, setDatasetId, datasetId } = useSelection()
  const [cur, setCur] = useState<any>(null)
  const [mapping, setMapping] = useState<any>({})
  const [opts, setOpts] = useState<any>({ duplicates: 'error', invalid_rows: 'error', missing_values: 'error', fill_missing_candles: false })
  const [symbol, setSymbol] = useState('')
  const [err, setErr] = useState<string | null>(null); const [busy, setBusy] = useState(false); const [done, setDone] = useState<any>(null)
  const [bn, setBn] = useState({ symbol: 'BTCUSDT', interval: '4h', start: '2021-01-01', end: '' })
  const preview = useLoad(() => (datasetId ? api.get(`/api/v1/datasets/${datasetId}/candles?tail=600`).then((r) => r.data.candles) : Promise.resolve(null)), [datasetId])

  const guard = async (fn: () => Promise<any>) => { setBusy(true); setErr(null); try { await fn() } catch (e) { setErr(errMsg(e)) } finally { setBusy(false) } }
  const upload = (f: File) => guard(async () => {
    const fd = new FormData(); fd.append('file', f)
    const r = (await api.post('/api/v1/datasets/upload', fd)).data; setCur(r); setMapping(r.mapping || {}); setDone(null); reload()
  })
  const commit = () => guard(async () => {
    const r = (await api.post(`/api/v1/datasets/${cur.id}/commit`, { mapping, options: opts, symbol })).data
    setDone(r); setCur(null); reload(); setDatasetId(r.id)
  })
  const binance = () => guard(async () => { const r = (await api.post('/api/v1/datasets/binance', bn)).data; reload(); setDatasetId(r.id); setDone(r) })
  const rep = cur?.report

  return (
    <>
      <PageHead title="Datasets and data quality" desc="Upload OHLCV files (CSV/XLSX) or fetch Binance history. Nothing is silently changed: you choose how duplicates, invalid rows and missing values are handled, and every modification is logged." />
      {err && <div className="mb-4"><Notice>{err}</Notice></div>}
      <div className="grid grid-cols-2 gap-4">
        <Card title="Upload a dataset">
          <input type="file" accept=".csv,.xlsx,.xls" disabled={busy} onChange={(e) => e.target.files?.[0] && upload(e.target.files[0])} />
          <p className="mt-2 text-xs text-mute">Required: timestamp, open, high, low, close. Optional: volume, symbol, quote volume, trade count. Max 50 MB.</p>
        </Card>
        <Card title="Fetch from Binance (public API)">
          <div className="grid grid-cols-4 gap-2 text-sm">
            <label>Pair<input className="w-full" value={bn.symbol} onChange={(e) => setBn({ ...bn, symbol: e.target.value })} /></label>
            <label>Interval<select className="w-full" value={bn.interval} onChange={(e) => setBn({ ...bn, interval: e.target.value })}>{['15m', '1h', '4h', '1d'].map((i) => <option key={i}>{i}</option>)}</select></label>
            <label>From<input type="date" className="w-full" value={bn.start} onChange={(e) => setBn({ ...bn, start: e.target.value })} /></label>
            <label>To (optional)<input type="date" className="w-full" value={bn.end} onChange={(e) => setBn({ ...bn, end: e.target.value })} /></label>
          </div>
          <div className="mt-3"><Btn onClick={binance} disabled={busy}>{busy ? 'Working…' : 'Fetch candles'}</Btn></div>
          <p className="mt-2 text-xs text-mute">Only completed candles are stored. Training needs roughly 1,500+ candles (about 250 days of 4h data).</p>
        </Card>
      </div>

      {cur && cur.status === 'UNSUPPORTED' && <div className="mt-4"><Notice>{cur.errorMessage}</Notice></div>}
      {cur && cur.status === 'REJECTED' && <div className="mt-4"><Notice>{cur.errorMessage}</Notice></div>}
      {cur && rep?.supported && (
        <Card title={`Quality report: ${cur.name}`} className="mt-4" right={<Badge tone={tone(rep.status)}>{rep.status}</Badge>}>
          <div className="grid grid-cols-4 gap-4 text-sm">
            <div>Rows<div className="text-lg">{rep.n_rows}</div></div><div>Columns<div className="text-lg">{rep.n_columns}</div></div>
            <div>Interval<div className="text-lg">{rep.interval_seconds ? `${rep.interval_seconds / 3600}h` : '–'}</div></div><div>Missing values<div className="text-lg">{rep.overall_missing_pct}%</div></div>
            <div className="col-span-2">Range<div>{rep.start?.slice(0, 16)} → {rep.end?.slice(0, 16)}</div></div><div>Missing candles<div className="text-lg">{rep.missing_candles}</div></div><div>Duplicates<div className="text-lg">{rep.duplicate_timestamps}</div></div>
          </div>
          {rep.issues.length > 0 && <table className="mt-4"><thead><tr><th>Severity</th><th>Issue</th><th className="num">Count</th></tr></thead><tbody>
            {rep.issues.map((i: any, k: number) => <tr key={k}><td><Badge tone={i.severity === 'error' ? 'bad' : 'warn'}>{i.severity}</Badge></td><td className="!whitespace-normal">{i.message}</td><td className="num">{i.count ?? ''}</td></tr>)}</tbody></table>}
          <h4 className="mb-2 mt-5 text-sm font-medium">Column mapping</h4>
          <div className="grid grid-cols-5 gap-2 text-sm">
            {CANON.map((c) => <label key={c}>{c}<select className="w-full" value={mapping[c] ?? ''} onChange={(e) => setMapping({ ...mapping, [c]: e.target.value || null })}><option value="">(none)</option>{rep.columns.map((x: string) => <option key={x}>{x}</option>)}</select></label>)}
          </div>
          <h4 className="mb-2 mt-5 text-sm font-medium">Handling</h4>
          <div className="grid grid-cols-5 gap-2 text-sm">
            <label>Duplicates<select className="w-full" value={opts.duplicates} onChange={(e) => setOpts({ ...opts, duplicates: e.target.value })}><option value="error">Stop (decide)</option><option value="keep_first">Keep first</option><option value="keep_last">Keep last</option></select></label>
            <label>Invalid rows<select className="w-full" value={opts.invalid_rows} onChange={(e) => setOpts({ ...opts, invalid_rows: e.target.value })}><option value="error">Stop (decide)</option><option value="drop">Drop (logged)</option></select></label>
            <label>Missing values<select className="w-full" value={opts.missing_values} onChange={(e) => setOpts({ ...opts, missing_values: e.target.value })}><option value="error">Stop (decide)</option><option value="drop_rows">Drop rows</option><option value="ffill">Forward fill</option><option value="interpolate">Interpolate</option></select></label>
            <label>Missing candles<select className="w-full" value={String(opts.fill_missing_candles)} onChange={(e) => setOpts({ ...opts, fill_missing_candles: e.target.value === 'true' })}><option value="false">Leave gaps</option><option value="true">Insert flat candles</option></select></label>
            <label>Symbol (if not in file)<input className="w-full" value={symbol} placeholder="BTCUSDT" onChange={(e) => setSymbol(e.target.value)} /></label>
          </div>
          <div className="mt-4"><Btn onClick={commit} disabled={busy}>Validate, clean and save</Btn></div>
        </Card>
      )}
      {done?.cleaningLog && <div className="mt-4"><Card title="Cleaning log"><pre className="text-xs text-mute">{JSON.stringify(done.cleaningLog, null, 2)}</pre></Card></div>}

      <Card title="Your datasets" className="mt-4">
        <table><thead><tr><th>Name</th><th>Symbol</th><th>Source</th><th className="num">Rows</th><th>Range</th><th className="num">Missing</th><th>Quality</th><th>Status</th><th /></tr></thead><tbody>
          {datasets.map((d) => <tr key={d.id} className={d.id === datasetId ? 'bg-raised' : ''}><td>{d.name}</td><td>{d.symbol}</td><td>{d.source}</td><td className="num">{d.rowCount}</td>
            <td>{d.startTs?.slice(0, 10)} → {d.endTs?.slice(0, 10)}</td><td className="num">{d.missingPct != null ? num(d.missingPct) + '%' : '–'}</td>
            <td><Badge tone={tone(d.qualityStatus)}>{d.qualityStatus ?? '–'}</Badge></td><td><Badge tone={tone(d.status)}>{d.status}</Badge></td>
            <td>{d.status === 'READY' && <Btn kind="ghost" onClick={() => setDatasetId(d.id)}>Select</Btn>}{d.status === 'NEEDS_REVIEW' && <Btn kind="ghost" onClick={() => { setCur(d); setMapping(d.mapping || {}) }}>Review</Btn>}</td></tr>)}
          {datasets.length === 0 && <tr><td colSpan={9} className="text-mute">No datasets yet. Upload a file or fetch Binance candles above.</td></tr>}
        </tbody></table>
      </Card>
      {datasetId && <Card title="Selected dataset: price chart" className="mt-4">{preview.data ? <CandleChart candles={preview.data} /> : <Notice kind="info">{preview.error ?? 'Loading…'}</Notice>}</Card>}
    </>
  )
}
