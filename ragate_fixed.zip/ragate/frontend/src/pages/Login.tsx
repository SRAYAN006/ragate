import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { api, errMsg } from '../api'
import { useAuth } from '../auth'
import { Btn, Notice } from '../components/ui'

export default function Login() {
  const [mode, setMode] = useState<'login' | 'register'>('login')
  const [f, setF] = useState({ username: '', email: '', password: '' })
  const [err, setErr] = useState<string | null>(null)
  const { login } = useAuth(); const nav = useNavigate()
  const submit = async (e: React.FormEvent) => {
    e.preventDefault(); setErr(null)
    try {
      const r = await api.post(mode === 'login' ? '/api/auth/login' : '/api/auth/register', mode === 'login' ? { username: f.username, password: f.password } : f)
      login(r.data.token, r.data.user); nav('/')
    } catch (x) { setErr(errMsg(x)) }
  }
  const set = (k: string) => (e: any) => setF({ ...f, [k]: e.target.value })
  return (
    <div className="flex h-full items-center justify-center">
      <form onSubmit={submit} className="w-96 space-y-4 rounded-md border border-line bg-panel p-8">
        <div><div className="text-2xl font-semibold">RAGATE</div><p className="mt-1 text-sm text-mute">Reliability-aware gating and adaptive trading exposure. A research platform with paper trading only.</p></div>
        {err && <Notice>{err}</Notice>}
        <label className="block text-sm">Username<input className="mt-1 w-full" value={f.username} onChange={set('username')} required autoFocus /></label>
        {mode === 'register' && <label className="block text-sm">Email<input type="email" className="mt-1 w-full" value={f.email} onChange={set('email')} required /></label>}
        <label className="block text-sm">Password<input type="password" className="mt-1 w-full" value={f.password} onChange={set('password')} required minLength={8} /></label>
        <Btn type="submit">{mode === 'login' ? 'Sign in' : 'Create account'}</Btn>
        <p className="text-xs text-mute">{mode === 'login' ? 'No account?' : 'Have an account?'}{' '}
          <button type="button" className="underline" onClick={() => setMode(mode === 'login' ? 'register' : 'login')}>{mode === 'login' ? 'Register' : 'Sign in'}</button>
          {mode === 'register' && <span className="block mt-1">The first account created becomes the administrator (can train models).</span>}</p>
      </form>
    </div>
  )
}
