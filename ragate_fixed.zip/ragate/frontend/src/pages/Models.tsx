import { useEffect, useState } from 'react'
import { api, errMsg, pct, num } from '../api'
import { useAuth } from '../auth'
import { Badge, Btn, Card, Notice, PageHead, Pickers } from '../components/ui'
import { useSelection } from '../selection'

export default function Models() {
  const { models, reload, datasetId } = useSelection(); const { user } = useAuth()
  const [err, setErr] = useState<string | null>(null)
  const [cfg, setCfg] = useState({ epochs: 40, compare_fusion: false, walk_forward_folds: 0, seq_len: 48 })
  const [open, setOpen] = useState<string | null>(null)
  useEffect(() => { if (models.some((m) => m.status === 'TRAINING')) { const t = setInterval(reload, 5000); return () => clearInterval(t) } }, [models, reload])
  const train = async () => {
    setErr(null)
    try { await api.post('/api/v1/models/train', { datasetId, config: { seq_len: cfg.seq_len, compare_fusion: cfg.compare_fusion, walk_forward_folds: cfg.walk_forward_folds, rcte: { epochs: cfg.epochs } } }); reload() }
    catch (e) { setErr(errMsg(e)) }
  }
  return (
    <>
      <PageHead title="Model registry" desc="Each training run fits the HMM, XGBoost, Mean-Reversion and R-CTE experts on the chronological training split only, tunes on validation, and leaves the final test period untouched." right={<Pickers needModel={false} />} />
      {err && <div className="mb-4"><Notice>{err}</Notice></div>}
      <Card title="Train a new model set" className="mb-4">
        {user?.role !== 'ADMIN' ? <Notice kind="info">Only administrators can start training.</Notice> : (
          <div className="flex flex-wrap items-end gap-4 text-sm">
            <label>R-CTE epochs (max)<input type="number" min={1} max={200} className="block w-24" value={cfg.epochs} onChange={(e) => setCfg({ ...cfg, epochs: +e.target.value })} /></label>
            <label>Sequence length<input type="number" min={8} max={256} className="block w-24" value={cfg.seq_len} onChange={(e) => setCfg({ ...cfg, seq_len: +e.target.value })} /></label>
            <label>Walk-forward folds (XGBoost)<input type="number" min={0} max={8} className="block w-24" value={cfg.walk_forward_folds} onChange={(e) => setCfg({ ...cfg, walk_forward_folds: +e.target.value })} /></label>
            <label className="flex items-center gap-2"><input type="checkbox" checked={cfg.compare_fusion} onChange={(e) => setCfg({ ...cfg, compare_fusion: e.target.checked })} />Compare fusion variants (slower)</label>
            <Btn onClick={train} disabled={!datasetId}>Train on selected dataset</Btn>
          </div>)}
        <p className="mt-2 text-xs text-mute">Training runs in the background (minutes on CPU). Status refreshes automatically.</p>
      </Card>
      <Card title="Models">
        <table><thead><tr><th>Model</th><th>Symbol</th><th>Status</th><th>Trained</th><th>Test period</th><th /></tr></thead><tbody>
          {models.map((m) => <tr key={m.id}><td>{m.modelKey ?? `#${m.id}`}</td><td>{m.symbol}</td><td><Badge tone={m.status === 'READY' ? 'good' : m.status === 'FAILED' ? 'bad' : 'warn'}>{m.status}</Badge></td>
            <td>{m.createdAt?.slice(0, 16)}</td><td>{m.meta?.splits?.test ? `${m.meta.splits.test[0].slice(0, 10)} → ${m.meta.splits.test[1].slice(0, 10)}` : '–'}</td>
            <td>{m.status === 'READY' && <Btn kind="ghost" onClick={() => setOpen(open === m.modelKey ? null : m.modelKey)}>Details</Btn>}</td></tr>)}
          {models.length === 0 && <tr><td colSpan={6} className="text-mute">No models yet.</td></tr>}</tbody></table>
        {models.filter((m) => m.status === 'FAILED').map((m) => <div key={m.id} className="mt-3"><Notice>Training #{m.id} failed: {m.error}</Notice></div>)}
      </Card>
      {models.filter((m) => m.modelKey === open).map((m) => (
        <div key={m.id} className="mt-4 grid grid-cols-2 gap-4">
          <Card title="Held-out test forecast metrics (1d horizon)" className="col-span-2">
            <table><thead><tr><th>Expert</th><th className="num">MAE</th><th className="num">RMSE</th><th className="num">Dir. acc.</th><th className="num">Precision</th><th className="num">Recall</th><th className="num">F1</th><th className="num">n</th></tr></thead><tbody>
              {Object.entries(m.metrics.test).map(([e, v]: any) => <tr key={e}><td>{e}</td><td className="num">{num(v['1d'].mae, 5)}</td><td className="num">{num(v['1d'].rmse, 5)}</td><td className="num">{pct(v['1d'].directional_accuracy)}</td><td className="num">{pct(v['1d'].precision)}</td><td className="num">{pct(v['1d'].recall)}</td><td className="num">{num(v['1d'].f1, 3)}</td><td className="num">{v['1d'].n}</td></tr>)}</tbody></table>
            <p className="mt-2 text-xs text-mute">Directional accuracy near 50% means no usable skill. These are forecast metrics, not trading profit.</p>
          </Card>
          <Card title="XGBoost feature importance (1d)"><table><tbody>{Object.entries(m.meta.feature_importance['1d']).slice(0, 10).map(([k, v]: any) => <tr key={k}><td>{k}</td><td className="num">{num(v, 4)}</td></tr>)}</tbody></table></Card>
          <Card title="Mean reversion (fitted, not assumed)"><table><thead><tr><th>Horizon</th><th className="num">beta (z-score)</th><th>Mean-reverting?</th></tr></thead><tbody>
            {Object.entries(m.meta.mean_reversion_params).map(([h, p]: any) => <tr key={h}><td>{h}</td><td className="num">{num(p.beta, 5)}</td><td>{p.mean_reverting ? 'yes' : 'no'}</td></tr>)}</tbody></table></Card>
        </div>))}
    </>
  )
}
