import { useState } from 'react'
import { api, errMsg, num, pct } from '../api'
import { Badge, Btn, Card, Notice, PageHead, PaperBadge, Stat, useLoad } from '../components/ui'
import { Lines } from '../components/Charts'
import { useSelection } from '../selection'

export default function Portfolio() {
  const [tick, setTick] = useState(0)
  const pf = useLoad(() => api.get('/api/v1/portfolio').then((r) => r.data), [tick], 20000)
  const orders = useLoad(() => api.get('/api/v1/orders').then((r) => r.data), [tick])
  const trades = useLoad(() => api.get('/api/v1/trades').then((r) => r.data), [tick])
  const { datasetId } = useSelection()
  const [o, setO] = useState({ symbol: 'BTCUSDT', side: 'BUY', quantity: '0.01', useDataset: false })
  const [msg, setMsg] = useState<string | null>(null); const [reset, setReset] = useState('10000')
  const place = async () => {
    setMsg(null)
    try { const r = (await api.post('/api/v1/paper/orders', { symbol: o.symbol, side: o.side, quantity: o.quantity, datasetId: o.useDataset ? datasetId : undefined })).data
      setMsg(`${r.status}${r.rejectReason ? ': ' + r.rejectReason : ` at ${num(r.execPrice)}, fee ${num(r.fee, 4)}`}`); setTick(tick + 1) } catch (e) { setMsg(errMsg(e)) }
  }
  const doReset = async () => { if (!confirm('Reset the paper portfolio? Orders, trades and positions are deleted.')) return; try { await api.post('/api/v1/portfolio/reset', { startingBalance: reset }); setTick(tick + 1) } catch (e) { setMsg(errMsg(e)) } }
  const p = pf.data
  return (
    <>
      <PageHead title="Paper portfolio" desc="Virtual money only. Orders execute at the latest price plus slippage and fees, rounded to exchange tick and lot sizes." right={<PaperBadge />} />
      {pf.error && <Notice>{pf.error}</Notice>}
      {p && (<>
        <div className="mb-4 grid grid-cols-5 gap-4">
          <Stat label="Equity" value={num(Number(p.equity))} sub={p.currency} /><Stat label="Cash" value={num(Number(p.cash))} />
          <Stat label="Realised P&L" value={num(Number(p.realizedPnl))} tone={Number(p.realizedPnl) >= 0 ? 'good' : 'bad'} />
          <Stat label="Unrealised P&L" value={num(Number(p.unrealizedPnl))} tone={Number(p.unrealizedPnl) >= 0 ? 'good' : 'bad'} />
          <Stat label="Max drawdown" value={pct(p.maxDrawdown)} sub={`fees ${pct(Number(p.feeRate), 2)} · slippage ${p.slippageBps} bps`} />
        </div>
        {p.priceFallbackUsed && <div className="mb-4"><Notice kind="warn">Live price unavailable for some positions; those are valued at cost.</Notice></div>}
        <div className="grid grid-cols-3 gap-4">
          <Card title="Equity curve (snapshots taken at each trade)" className="col-span-2">{p.equityCurve.length > 1 ? <Lines data={p.equityCurve} keys={['equity']} x="ts" /> : <Notice kind="info">No trades yet.</Notice>}</Card>
          <Card title="Manual simulation order">
            <div className="space-y-2 text-sm">
              <label className="block">Pair<input className="w-full" value={o.symbol} onChange={(e) => setO({ ...o, symbol: e.target.value.toUpperCase() })} /></label>
              <label className="block">Side<select className="w-full" value={o.side} onChange={(e) => setO({ ...o, side: e.target.value })}><option>BUY</option><option>SELL</option></select></label>
              <label className="block">Quantity<input className="w-full" value={o.quantity} onChange={(e) => setO({ ...o, quantity: e.target.value })} /></label>
              <label className="flex items-center gap-2"><input type="checkbox" checked={o.useDataset} onChange={(e) => setO({ ...o, useDataset: e.target.checked })} />Price from selected dataset (historical)</label>
              <Btn onClick={place}>Place simulated order</Btn>{msg && <Notice kind="info">{msg}</Notice>}
            </div>
          </Card>
          <Card title="Positions" className="col-span-3"><table><thead><tr><th>Symbol</th><th className="num">Quantity</th><th className="num">Avg cost</th><th className="num">Price</th><th className="num">Value</th><th className="num">Unrealised</th><th className="num">Realised</th></tr></thead><tbody>
            {p.positions.map((x: any) => <tr key={x.symbol}><td>{x.symbol}</td><td className="num">{num(x.quantity, 6)}</td><td className="num">{num(x.avgCost)}</td><td className="num">{num(x.price)}</td><td className="num">{num(x.marketValue)}</td><td className="num">{num(x.unrealizedPnl)}</td><td className="num">{num(x.realizedPnl)}</td></tr>)}
            {p.positions.length === 0 && <tr><td colSpan={7} className="text-mute">No open positions.</td></tr>}</tbody></table></Card>
        </div></>)}
      <Card title="Order history (PAPER)" className="mt-4"><table><thead><tr><th>Time</th><th>Symbol</th><th>Side</th><th className="num">Qty</th><th className="num">Exec price</th><th className="num">Fee</th><th>Status</th><th>Source</th><th>Note</th></tr></thead><tbody>
        {(orders.data || []).map((x: any) => <tr key={x.id}><td>{x.createdAt?.slice(0, 19).replace('T', ' ')}</td><td>{x.symbol}</td><td>{x.side}</td><td className="num">{num(x.filledQuantity ?? x.quantity, 6)}</td><td className="num">{x.execPrice ? num(x.execPrice) : '–'}</td><td className="num">{x.fee ? num(x.fee, 4) : '–'}</td><td><Badge tone={x.status === 'FILLED' ? 'good' : 'bad'}>{x.status}</Badge></td><td>{x.source}</td><td className="!whitespace-normal text-mute">{x.rejectReason}</td></tr>)}</tbody></table></Card>
      <Card title="Trade history" className="mt-4"><table><thead><tr><th>Time</th><th>Symbol</th><th>Side</th><th className="num">Qty</th><th className="num">Price</th><th className="num">Fee</th><th className="num">Realised P&L</th></tr></thead><tbody>
        {(trades.data || []).map((x: any) => <tr key={x.id}><td>{x.executedAt?.slice(0, 19).replace('T', ' ')}</td><td>{x.symbol}</td><td>{x.side}</td><td className="num">{num(x.quantity, 6)}</td><td className="num">{num(x.price)}</td><td className="num">{num(x.fee, 4)}</td><td className="num">{num(x.realizedPnl)}</td></tr>)}</tbody></table></Card>
      <div className="mt-4 flex items-center gap-2 text-sm"><span className="text-mute">Reset portfolio with starting balance</span><input className="w-28" value={reset} onChange={(e) => setReset(e.target.value)} /><Btn kind="ghost" onClick={doReset}>Reset</Btn></div>
    </>
  )
}
