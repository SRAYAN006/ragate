import { useState } from 'react'
import { api, errMsg, num, pct } from '../api'
import { Badge, Bar, Btn, Card, Notice, PageHead, Pickers, Stat, actionTone } from '../components/ui'
import { useSelection } from '../selection'

export default function Predictions() {
  const { datasetId, modelKey } = useSelection()
  const [p, setP] = useState<any>(null); const [err, setErr] = useState<string | null>(null); const [busy, setBusy] = useState(false); const [msg, setMsg] = useState<string | null>(null)
  const [hz, setHz] = useState('1d')
  const run = async () => { setBusy(true); setErr(null); setMsg(null); try { setP((await api.post('/api/v1/predictions', { datasetId, modelKey })).data) } catch (e) { setErr(errMsg(e)) } finally { setBusy(false) } }
  const execute = async () => { try { const o = (await api.post('/api/v1/paper/orders', { decisionId: p.id })).data; setMsg(`${o.status}: ${o.side} ${num(o.filledQuantity ?? o.quantity, 6)} ${o.symbol} @ ${num(o.execPrice ?? 0)} (PAPER) ${o.rejectReason ?? ''}`) } catch (e) { setMsg(errMsg(e)) } }
  const H = p?.horizons?.[hz]; const rg = H?.ragate; const dec = p?.decision; const risk = p?.risk
  return (
    <>
      <PageHead title="Predictions and RAGATE" desc="Experts forecast, RAGATE weights them by regime fit, recent accuracy and deterioration, the risk engine can veto, and the decision engine explains the outcome." right={<div className="flex gap-2"><Pickers /><Btn onClick={run} disabled={!datasetId || !modelKey || busy}>{busy ? 'Running…' : 'Run prediction'}</Btn></div>} />
      {err && <div className="mb-4"><Notice>{err}</Notice></div>}
      {!p && !err && <Notice kind="info">Choose a dataset and a trained model, then run a prediction. Reliability state accumulates across runs as forecasts mature.</Notice>}
      {p && (<>
        <div className="mb-4 grid grid-cols-5 gap-4">
          <Stat label="Decision" value={<Badge tone={actionTone(dec.action)}>{dec.action}</Badge>} sub={`target exposure ${pct(dec.target_weight, 1)}`} />
          <Stat label={`Combined return (${hz})`} value={rg?.combined ? pct(rg.combined.combined_return, 3) : '–'} sub={rg?.combined ? `P(up) ${pct(rg.combined.prob_positive, 0)}` : undefined} />
          <Stat label="Uncertainty (σ)" value={rg?.combined ? pct(rg.combined.sigma_total, 3) : '–'} sub={rg?.combined ? `disagreement ${pct(rg.combined.disagreement, 3)}` : undefined} />
          <Stat label="Regime" value={p.regime.summary.current_label} sub={`stress ${pct(p.regime.probs.stress, 0)}`} />
          <Stat label="Data freshness" value={p.freshness.stale ? 'STALE' : 'OK'} sub={p.freshness.historical_mode ? 'historical dataset: live check off' : `${Math.round(p.freshness.age_seconds / 60)} min old`} tone={p.freshness.stale ? 'bad' : undefined} />
        </div>
        <div className="mb-3 flex gap-2">{['1d', '3d', '5d'].map((h) => <Btn key={h} kind={h === hz ? 'primary' : 'ghost'} onClick={() => setHz(h)}>{h}</Btn>)}</div>
        <div className="grid grid-cols-2 gap-4">
          <Card title="Individual expert forecasts">
            <table><thead><tr><th>Expert</th><th className="num">Return</th><th className="num">P(up)</th><th className="num">σ</th></tr></thead><tbody>
              {H.experts.map((o: any) => <tr key={o.expert}><td>{o.expert}</td><td className="num">{o.pred == null ? 'n/a' : pct(o.pred, 3)}</td><td className="num">{pct(o.prob_pos, 0)}</td><td className="num">{pct(o.sigma, 3)}</td></tr>)}</tbody></table>
            {p.unavailableExperts?.length > 0 && <div className="mt-2"><Notice kind="warn">Unavailable experts: {p.unavailableExperts.join(', ')}. Weights renormalise over the rest.</Notice></div>}
          </Card>
          <Card title="RAGATE weights and why">
            {rg?.status !== 'ok' ? <Notice kind="warn">No usable expert outputs at this horizon.</Notice> : Object.entries(rg.details).map(([e, d]: any) => (
              <div key={e} className="mb-3"><div className="mb-1 flex justify-between text-sm"><span>{e} {d.flagged && <Badge tone="bad">CUSUM flag</Badge>}</span><span className="tabular-nums">{pct(d.weight, 1)}</span></div>
                <Bar value={d.weight} /><div className="mt-1 text-xs text-mute">{d.why}</div></div>))}
          </Card>
          <Card title="Reliability (EWMA / CUSUM)" className="col-span-2">
            {rg?.details && <table><thead><tr><th>Expert</th><th className="num">Regime compat.</th><th className="num">EWMA loss (shrunk)</th><th className="num">Matured forecasts</th><th className="num">CUSUM</th><th className="num">Logit</th></tr></thead><tbody>
              {Object.entries(rg.details).map(([e, d]: any) => <tr key={e}><td>{e}</td><td className="num">{num(d.compat, 3)}</td><td className="num">{num(d.loss_eff, 3)}</td><td className="num">{d.n_matured}</td><td className="num">{num(d.cusum, 2)}</td><td className="num">{num(d.logit, 3)}</td></tr>)}</tbody></table>}
            <p className="mt-2 text-xs text-mute">With few matured forecasts the EWMA is shrunk toward a neutral value, so weights are driven mostly by regime compatibility until evidence accumulates. Run predictions on successive candles to build reliability history.</p>
          </Card>
          <Card title="Risk engine">
            {risk ? (<><table><thead><tr><th>Check</th><th className="num">Value</th><th className="num">Limit</th><th /></tr></thead><tbody>
              {risk.checks.map((c: any) => <tr key={c.name}><td>{c.name}</td><td className="num">{num(c.value, 4)}</td><td className="num">{num(c.limit, 4)}</td><td><Badge tone={c.passed ? 'good' : 'bad'}>{c.passed ? 'pass' : 'fail'}</Badge></td></tr>)}</tbody></table>
              <div className="mt-3 text-sm text-mute">Net after costs: {pct(risk.net_return_entry, 3)} · exposure cap {pct(risk.exposure_cap, 1)} · portfolio vol {pct(risk.portfolio_vol_annual, 1)} ann.</div></>) : <Notice kind="warn">No risk evaluation (no expert output).</Notice>}
          </Card>
          <Card title="Decision reasons" right={['BUY', 'REDUCE', 'EXIT'].includes(dec.action) ? <Btn onClick={execute}>Execute in paper portfolio</Btn> : undefined}>
            <ul className="list-disc space-y-1 pl-5 text-sm">{dec.reasons.map((r: string, i: number) => <li key={i}>{r}</li>)}</ul>
            {msg && <div className="mt-3"><Notice kind="info">{msg}</Notice></div>}
          </Card>
        </div></>)}
    </>
  )
}
