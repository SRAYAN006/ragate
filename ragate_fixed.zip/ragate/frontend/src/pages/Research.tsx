import { api, num, pct } from '../api'
import { Badge, Card, Notice, PageHead, useLoad } from '../components/ui'

export default function Research() {
  const r = useLoad(() => api.get('/api/v1/research/metrics').then((x) => x.data), [])
  const d = r.data
  return (
    <>
      <PageHead title="Research and experiment results" desc="Everything here is read from stored experiments. Nothing is pre-filled: empty sections mean the experiment has not been run." />
      {r.error && <Notice>{r.error}</Notice>}
      {d && (<div className="space-y-4">
        <Card title="Decisions issued">{d.decisionCounts.length ? <div className="flex gap-2">{d.decisionCounts.map((x: any) => <Badge key={x.action}>{x.action}: {x.n}</Badge>)}</div> : <span className="text-sm text-mute">No predictions have been run yet.</span>}</Card>
        {d.models.map((m: any) => (
          <Card key={m.modelKey} title={m.modelKey}>
            <p className="mb-2 text-xs text-mute">Train {m.splits.train[0].slice(0, 10)} → {m.splits.train[1].slice(0, 10)} · validation {m.splits.validation[0].slice(0, 10)} → {m.splits.validation[1].slice(0, 10)} · test {m.splits.test[0].slice(0, 10)} → {m.splits.test[1].slice(0, 10)} · purge {m.splits.purge_candles} candles</p>
            <h4 className="mb-1 text-sm font-medium">R-CTE fusion variants (validation, 1d)</h4>
            {Object.keys(m.fusionComparison).length ? <table><thead><tr><th>Fusion</th><th className="num">MAE</th><th className="num">RMSE</th><th className="num">Dir. acc.</th></tr></thead><tbody>
              {Object.entries(m.fusionComparison).map(([k, v]: any) => <tr key={k}><td>{k}{k === 'film' && ' (proposed)'}</td><td className="num">{num(v['1d'].mae, 5)}</td><td className="num">{num(v['1d'].rmse, 5)}</td><td className="num">{pct(v['1d'].directional_accuracy)}</td></tr>)}</tbody></table>
              : <p className="text-sm text-mute">Not run. Enable "Compare fusion variants" when training.</p>}
            <h4 className="mb-1 mt-4 text-sm font-medium">Walk-forward folds (XGBoost, 1d)</h4>
            {m.walkForward.length ? <table><thead><tr><th>Fold</th><th>Test ends</th><th className="num">MAE</th><th className="num">Dir. acc.</th><th className="num">n</th></tr></thead><tbody>
              {m.walkForward.map((f: any) => <tr key={f.fold}><td>{f.fold}</td><td>{f.test_end.slice(0, 10)}</td><td className="num">{num(f.metrics['1d'].mae, 5)}</td><td className="num">{pct(f.metrics['1d'].directional_accuracy)}</td><td className="num">{f.metrics['1d'].n}</td></tr>)}</tbody></table>
              : <p className="text-sm text-mute">Not run. Set walk-forward folds when training.</p>}
          </Card>))}
        {d.models.length === 0 && <Notice kind="info">No trained models yet.</Notice>}
        <Card title="Completed backtests">{d.backtests.length ? d.backtests.map((b: any) => (
          <div key={b.id} className="mb-3"><div className="mb-1 text-sm">Backtest #{b.id} · {b.createdAt.slice(0, 16)}</div>
            <table><thead><tr><th>Strategy</th><th className="num">Cumulative</th><th className="num">Sharpe</th><th className="num">Max DD</th></tr></thead><tbody>
              {Object.entries(b.aggregate).map(([s, v]: any) => <tr key={s}><td>{s}</td><td className="num">{pct(v.cumulative_return)}</td><td className="num">{num(v.sharpe)}</td><td className="num">{pct(v.max_drawdown)}</td></tr>)}</tbody></table></div>)) : <span className="text-sm text-mute">No completed backtests.</span>}</Card>
      </div>)}
    </>
  )
}
