import { api } from '../api'
import { useAuth } from '../auth'
import { Card, PageHead, PaperBadge, useLoad } from '../components/ui'

export default function Settings() {
  const { user } = useAuth()
  const pf = useLoad(() => api.get('/api/v1/portfolio').then((r) => r.data), [])
  return (
    <>
      <PageHead title="Settings" />
      <div className="grid grid-cols-2 gap-4">
        <Card title="Account"><table><tbody><tr><td>Username</td><td>{user?.username}</td></tr><tr><td>Email</td><td>{user?.email}</td></tr><tr><td>Role</td><td>{user?.role}</td></tr></tbody></table></Card>
        <Card title="Trading mode" right={<PaperBadge />}><p className="text-sm text-mute">This platform cannot place real orders: no exchange trading endpoint is called and the database rejects non-paper portfolios.</p>
          {pf.data && <p className="mt-2 text-sm">Fee {Number(pf.data.feeRate) * 100}% per side · slippage {pf.data.slippageBps} bps. Change these via the reset control on the portfolio page.</p>}</Card>
        <Card title="Service endpoints"><table><tbody><tr><td>Backend API</td><td>{import.meta.env.VITE_API_URL || 'http://localhost:8080'}</td></tr><tr><td>ML service docs</td><td>http://localhost:8000/docs</td></tr></tbody></table></Card>
      </div>
    </>
  )
}
