import { createContext, useContext, useEffect, useState, ReactNode, useCallback } from 'react'
import { api } from './api'

type Sel = {
  datasets: any[]; models: any[]; datasetId?: number; modelKey?: string
  setDatasetId: (n?: number) => void; setModelKey: (k?: string) => void; reload: () => void
}
const C = createContext<Sel>({ datasets: [], models: [], setDatasetId: () => {}, setModelKey: () => {}, reload: () => {} })

/** Shared dataset/model selection used by every analysis page. */
export function SelectionProvider({ children }: { children: ReactNode }) {
  const [datasets, setDatasets] = useState<any[]>([])
  const [models, setModels] = useState<any[]>([])
  const [datasetId, setDatasetId] = useState<number | undefined>(() => Number(localStorage.getItem('sel_ds')) || undefined)
  const [modelKey, setModelKey] = useState<string | undefined>(() => localStorage.getItem('sel_model') || undefined)
  const reload = useCallback(() => {
    api.get('/api/v1/datasets').then((r) => setDatasets(r.data)).catch(() => {})
    api.get('/api/v1/models').then((r) => setModels(r.data)).catch(() => {})
  }, [])
  useEffect(reload, [reload])
  useEffect(() => { datasetId ? localStorage.setItem('sel_ds', String(datasetId)) : localStorage.removeItem('sel_ds') }, [datasetId])
  useEffect(() => { modelKey ? localStorage.setItem('sel_model', modelKey) : localStorage.removeItem('sel_model') }, [modelKey])
  return <C.Provider value={{ datasets, models, datasetId, modelKey, setDatasetId, setModelKey, reload }}>{children}</C.Provider>
}
export const useSelection = () => useContext(C)
