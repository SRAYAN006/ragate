/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        bg: '#0b0b0c', panel: '#141416', raised: '#1b1b1e', line: '#2a2a2e',
        ink: '#e8e6e3', mute: '#8b8b92', accent: '#d9484a', accentDim: '#7a2a2c', good: '#4fb286', warn: '#d9a441'
      },
      fontFamily: { sans: ['"Segoe UI"', 'Inter', 'system-ui', 'sans-serif'], mono: ['"Cascadia Mono"', 'Consolas', 'monospace'] }
    }
  },
  plugins: []
}
