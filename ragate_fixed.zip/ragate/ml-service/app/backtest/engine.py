"""Backtesting on the UNTOUCHED test period. Decisions use data up to candle close t and fill at the open of t+1."""
from __future__ import annotations
import hashlib, json
import numpy as np
import pandas as pd
from ..data.columns import load_dataset
from .. import config
from ..features.engineering import compute_features
from ..ragate import engine as rg
from ..risk.engine import evaluate_risk, RiskConfig
from ..decision.engine import decide, DecisionConfig
from ..experts.common import classification_metrics
from ..training.bundle import get_bundle, EXPERTS

STRATEGIES = ["Buy and Hold", "Equal-Weight Portfolio", "MA Crossover", "RSI Strategy", "Standalone XGBoost",
              "Standalone R-CTE", "Standalone Mean Reversion", "Static Equal-Weight Ensemble",
              "Regime-Aware Static Ensemble", "Full RAGATE"]


def portfolio_metrics(ret: pd.Series, w: pd.Series, ppy: float) -> dict:
    r = ret.fillna(0.0).values; n = len(r)
    if n < 2: return {}
    eq = np.cumprod(1 + r)
    mdd = float((eq / np.maximum.accumulate(eq) - 1).min())
    dn = r[r < 0]
    sd, dsd = r.std(ddof=1), (np.sqrt((dn ** 2).mean()) if len(dn) else np.nan)
    q = np.quantile(r, 0.05); tail = r[r <= q]
    # trade-level stats: contiguous segments with exposure
    # r[i] is earned by the weight decided at i
    pos = (w.fillna(0).values > 1e-9); trades, cur = [], None
    for i in range(n):
        if pos[i]: cur = (1 + r[i]) * (cur if cur is not None else 1.0)
        elif cur is not None: trades.append(cur - 1); cur = None
    if cur is not None: trades.append(cur - 1)
    gains, losses = sum(t for t in trades if t > 0), -sum(t for t in trades if t < 0)
    return {"cumulative_return": float(eq[-1] - 1), "annualized_return": float(eq[-1] ** (ppy / n) - 1) if eq[-1] > 0 else -1.0,
            "sharpe": float(r.mean() / sd * np.sqrt(ppy)) if sd > 0 else 0.0,
            "sortino": float(r.mean() / dsd * np.sqrt(ppy)) if dsd and dsd > 0 else 0.0,
            "max_drawdown": mdd, "cvar_95": float(tail.mean()) if len(tail) else 0.0,
            "win_rate": float(np.mean([t > 0 for t in trades])) if trades else 0.0,
            "profit_factor": float(gains / losses) if losses > 0 else (float("inf") if gains > 0 else 0.0),
            "n_trades": len(trades), "turnover_total": float(w.diff().abs().sum()), "exposure_avg": float(w.mean())}


def _strategy_returns(w: pd.Series, open_: pd.Series, cost: float) -> pd.Series:
    """Weight w_t is decided at the CLOSE of candle t and filled at the OPEN of t+1 (= close of t, +1 bar of latency).
    It then earns the open(t+1) -> open(t+2) return. Costs are charged on every change of weight."""
    r_fwd = open_.shift(-2) / open_.shift(-1) - 1      # return earned by a position entered at open t+1
    turn = (w - w.shift(1).fillna(0.0)).abs()
    return w * r_fwd - cost * turn


def run_asset(dataset_id: str, model_id: str, start=None, end=None, horizon="1d", costs=None, allow_in_sample=False,
              risk_cfg=None, dec_cfg=None, ragate_cfg=None) -> dict:
    costs = {"fee_rate": 0.001, "slippage_bps": 5.0, **(costs or {})}
    cost = costs["fee_rate"] + costs["slippage_bps"] / 1e4
    df = load_dataset(config.DATASET_DIR / f"{dataset_id}.csv")
    b = get_bundle(model_id); meta = b.meta
    interval = meta["interval_seconds"]; ppy = 365 * 86400 / interval
    hz = meta["horizons"]; h = hz[horizon]
    feat, proba, preds = b.run(df)
    pos = meta["splits"]["positions"]; a, bpos = pos["train_end"], pos["val_end"]
    warnings = []
    ts = df["timestamp"]
    t0 = bpos
    if start is not None:
        s = int(ts.searchsorted(pd.Timestamp(start, tz="UTC") if pd.Timestamp(start).tzinfo is None else pd.Timestamp(start)))
        if s < bpos and not allow_in_sample:
            warnings.append(f"Requested start precedes the untouched test period; clamped to {ts.iloc[bpos]}.")
        else: t0 = s
    t1 = len(df) - 2
    if end is not None: t1 = min(t1, int(ts.searchsorted(pd.Timestamp(end, tz="UTC") if pd.Timestamp(end).tzinfo is None else pd.Timestamp(end))) - 1)
    if t1 - t0 < 30: raise ValueError("Backtest window too short (<30 candles) after clamping to the test period")
    warm0 = max(a, 0) if t0 >= bpos else t0     # RAGATE reliability warm-up on validation data (no trading)
    close, open_ = df["close"], df["open"]
    close_idx = pd.Series(close.values, index=ts)

    rcfg = rg.RagateConfig(**(ragate_cfg or {}))
    risk_c = RiskConfig(**{"fee_rate": costs["fee_rate"], "slippage_bps": costs["slippage_bps"], **(risk_cfg or {})})
    dec_c = DecisionConfig(**(dec_cfg or {}))
    experts = [e for e in EXPERTS if e in preds]
    state: dict = {}; pending: list = []; wr = np.zeros(len(df)); cur_w = 0.0
    wt_hist, dec_counts, comb_series = [], {}, pd.Series(np.nan, index=df.index)
    comp = meta["compat"]
    for t in range(warm0, t1 + 1):
        p = proba.iloc[t]
        if p.isna().any(): continue
        outs = []
        for e in experts:
            row = preds[e][horizon].iloc[t]
            if np.isfinite(row["pred"]):
                pending.append({"id": f"{e}|{horizon}|{t}", "expert": e, "horizon": horizon, "asof": str(ts.iloc[t]),
                                "target_end": str(ts.iloc[t + h]) if t + h < len(df) else "9999-01-01T00:00:00+00:00",
                                "predicted_return": float(row["pred"]), "_t": t,
                                "scale": rg.vol_scale(feat["roll_std_50"].iloc[t], h, meta["scale"][horizon])})
                outs.append({"expert": e, "pred": float(row["pred"]), "sigma": float(row["sigma"])})
        known = close_idx.iloc[: t + 1]                              # ONLY information available at time t
        res = rg.evaluate({"horizon": horizon, "pending": [{k: v for k, v in f.items() if k != "_t"} for f in pending if f["_t"] + h <= t],
                           "state": state, "expert_outputs": outs, "regime_probs": p.to_dict(), "config": ragate_cfg or {}},
                          known, meta)
        state = res["state"]
        done = {s["id"] for s in res["scored"]}
        pending = [f for f in pending if f["id"] not in done]
        if t < t0 or res["status"] != "ok": continue
        c = res["combined"]; comb_series.iloc[t] = c["combined_return"]
        rk = evaluate_risk({"asset": meta["symbol"], "combined_return": c["combined_return"], "sigma_total": c["sigma_total"],
                            "disagreement": c["disagreement"], "regime_probs": p.to_dict(), "horizon_candles": h,
                            "periods_per_year": ppy, "current_weight": cur_w, "cash_fraction": 1 - cur_w}, risk_c)
        d = decide(res, rk, cur_w, p.to_dict(), False, dec_c)
        dec_counts[d["action"]] = dec_counts.get(d["action"], 0) + 1
        if d["action"] in ("BUY", "REDUCE", "EXIT"): cur_w = float(d["target_weight"])
        wr[t] = cur_w
        if t % max(1, (t1 - t0) // 150) == 0:
            wt_hist.append({"timestamp": str(ts.iloc[t]), **{e: res["weights"].get(e, 0.0) for e in experts}})

    idx = np.arange(t0, t1 + 1)
    sl = lambda s: s.iloc[idx] if hasattr(s, "iloc") else s[idx]
    P = lambda arr: pd.Series(arr, index=df.index)
    ema20, ema50, rsi = feat["ema_20"], feat["ema_50"], feat["rsi_14"]
    W = {}
    W["Buy and Hold"] = P(np.ones(len(df)))
    W["Equal-Weight Portfolio"] = W["Buy and Hold"]   # single-asset: identical; differs at aggregation level
    W["MA Crossover"] = P((ema20 > ema50).astype(float).values)
    r_state, rs = 0.0, np.zeros(len(df))
    for i in range(len(df)):
        v = rsi.iloc[i]
        if np.isfinite(v):
            if r_state == 0 and v < 30: r_state = 1.0
            elif r_state == 1 and v > 55: r_state = 0.0
        rs[i] = r_state
    W["RSI Strategy"] = P(rs)
    thr = 2 * cost + risk_c.default_spread_bps / 1e4
    sig = lambda s: P((s > thr).astype(float).values)
    for name, e in (("Standalone XGBoost", "xgboost"), ("Standalone R-CTE", "rcte"), ("Standalone Mean Reversion", "mean_reversion")):
        W[name] = sig(preds[e][horizon]["pred"]) if e in preds else P(np.zeros(len(df)))
    P3 = pd.concat([preds[e][horizon]["pred"] for e in experts], axis=1)
    W["Static Equal-Weight Ensemble"] = sig(P3.mean(axis=1))
    cw = np.zeros((len(df), len(experts)))
    pr = proba.values
    for j, e in enumerate(experts):
        cmp_ = comp[e][horizon]; cw[:, j] = pr[:, 0] * cmp_["bull"] + pr[:, 1] * cmp_["range"] + pr[:, 2] * cmp_["stress"]
    cw = cw / cw.sum(axis=1, keepdims=True)
    W["Regime-Aware Static Ensemble"] = sig(pd.Series((P3.values * cw).sum(axis=1), index=df.index))
    W["Full RAGATE"] = P(wr)

    out = {"strategies": {}, "curves": {}, "returns": {}, "weights": {}}
    for name in STRATEGIES:
        w = W[name].where(P(np.arange(len(df))).between(t0, t1), 0.0).fillna(0.0)
        # decision at close t is executed at open t+1; shift handled inside _strategy_returns
        r = _strategy_returns(w, open_, cost).iloc[idx]
        out["returns"][name] = r; out["weights"][name] = w.iloc[idx]
        out["strategies"][name] = portfolio_metrics(r, w.iloc[idx], ppy)
    fm = {}
    for e in experts:
        fm[e] = {}
        for hk in hz:
            y = np.log(close.shift(-hz[hk]) / close)
            fm[e][hk] = classification_metrics(y.iloc[idx].values, preds[e][hk]["pred"].iloc[idx].values)
    y = np.log(close.shift(-h) / close)
    fm["ragate_combined"] = {horizon: classification_metrics(y.iloc[idx].values, comb_series.iloc[idx].values)}
    out.update(forecast_metrics=fm, decisions=dec_counts, ragate_weights=wt_hist, warnings=warnings,
               period={"start": str(ts.iloc[t0]), "end": str(ts.iloc[t1]), "candles": int(len(idx))},
               ragate_final_state=state, reliability_flags=[k for k, v in state.items() if v.get("flagged")])
    return out


def run_backtest(req: dict) -> dict:
    assets = req["assets"]; cap = float(req.get("initial_capital", 10000)); horizon = req.get("horizon", "1d")
    per, rets, warnings = {}, {}, []
    for a in assets:
        r = run_asset(a["dataset_id"], a["model_id"], req.get("start"), req.get("end"), horizon, req.get("costs"),
                      req.get("allow_in_sample", False), req.get("risk"), req.get("decision"), req.get("ragate"))
        per[a["dataset_id"]] = r; warnings += r["warnings"]
    first = next(iter(per.values()))
    ppy = 365 * 86400 / get_bundle(assets[0]["model_id"]).meta["interval_seconds"]
    agg, curves = {}, {}
    for name in STRATEGIES:
        rs = pd.concat([p["returns"][name] for p in per.values()], axis=1, join="inner")
        ws = pd.concat([p["weights"][name] for p in per.values()], axis=1, join="inner")
        r = rs.mean(axis=1); w = ws.mean(axis=1)          # equal capital split, rebalanced each bar
        agg[name] = portfolio_metrics(r, w, ppy)
        eq = cap * (1 + r.fillna(0)).cumprod()
        step = max(1, len(eq) // 500)
        curves[name] = [{"t": str(i), "equity": float(v)} for i, v in eq.iloc[::step].items()]
    res = {"aggregate": agg, "curves": curves, "per_asset": {k: {"strategies": v["strategies"], "forecast_metrics": v["forecast_metrics"],
           "decisions": v["decisions"], "ragate_weights": v["ragate_weights"], "period": v["period"],
           "reliability_flags": v["reliability_flags"]} for k, v in per.items()}, "warnings": warnings,
           "notes": ["Forecast metrics measure prediction quality; strategy metrics measure simulated portfolio P&L after costs. They are different things.",
                     "Equal-Weight Portfolio equals Buy and Hold for a single asset.",
                     "Results are historical simulations, not predictions of future performance."],
           "config_hash": hashlib.sha256(json.dumps(req, sort_keys=True, default=str).encode()).hexdigest()[:16]}
    return res
