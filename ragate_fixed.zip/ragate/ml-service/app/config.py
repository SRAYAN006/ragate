"""Central configuration (environment driven)."""
import os
from pathlib import Path

ROOT = Path(os.getenv("RAGATE_STORAGE", Path(__file__).resolve().parents[2] / "storage")).resolve()
UPLOAD_DIR = ROOT / "uploads"
DATASET_DIR = ROOT / "datasets"
MODEL_DIR = ROOT / "models"
for _d in (UPLOAD_DIR, DATASET_DIR, MODEL_DIR):
    _d.mkdir(parents=True, exist_ok=True)

INTERNAL_API_KEY = os.getenv("INTERNAL_API_KEY", "dev-internal-key-change-me")
BINANCE_BASES = [b.strip() for b in os.getenv(
    "BINANCE_BASES", "https://api.binance.com,https://data-api.binance.vision").split(",") if b.strip()]
BINANCE_WS = os.getenv("BINANCE_WS", "wss://stream.binance.com:9443/stream")
ENABLE_LIVE_WS = os.getenv("ENABLE_LIVE_WS", "true").lower() == "true"
DEFAULT_SYMBOLS = ["BTCUSDT", "ETHUSDT", "SOLUSDT"]
SEED = int(os.getenv("RAGATE_SEED", "42"))


def safe_path(rel: str, base: Path = ROOT) -> Path:
    """Resolve a storage-relative path and refuse traversal outside storage."""
    p = (base / rel).resolve()
    if base.resolve() not in p.parents and p != base.resolve():
        raise ValueError("Path escapes storage directory")
    return p
