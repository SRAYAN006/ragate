"""Binance Spot public market data (no credentials). REST with retry / rate-limit handling + WebSocket feed."""
from __future__ import annotations
import asyncio, json, logging, time
import httpx
import pandas as pd
from .. import config

log = logging.getLogger("ragate.binance")
INTERVAL_SECONDS = {"1m": 60, "3m": 180, "5m": 300, "15m": 900, "30m": 1800, "1h": 3600, "2h": 7200, "4h": 14400,
                    "6h": 21600, "8h": 28800, "12h": 43200, "1d": 86400}


def normalize_symbol(s: str) -> str:
    return s.replace("/", "").replace("-", "").upper().strip()


class BinanceError(RuntimeError):
    pass


class BinanceClient:
    def __init__(self, bases=None, client: httpx.Client | None = None, max_retries: int = 5):
        self.bases = bases or config.BINANCE_BASES
        self.client = client or httpx.Client(timeout=15.0)
        self.max_retries = max_retries

    def _get(self, path: str, params: dict | None = None):
        last = None
        for attempt in range(self.max_retries):
            for base in self.bases:
                try:
                    r = self.client.get(base + path, params=params)
                    if r.status_code in (418, 429):  # rate limited / banned: obey Retry-After
                        wait = float(r.headers.get("Retry-After", 2 ** attempt))
                        log.warning("Binance rate limit (%s), sleeping %.1fs", r.status_code, wait)
                        time.sleep(min(wait, 60)); last = BinanceError(f"rate limited {r.status_code}"); continue
                    if r.status_code == 400:
                        raise BinanceError(f"Binance rejected request: {r.text}")
                    if r.status_code >= 500:
                        last = BinanceError(f"server error {r.status_code}"); continue
                    r.raise_for_status()
                    return r.json()
                except BinanceError as e:
                    if "rejected" in str(e): raise
                    last = e
                except Exception as e:  # network errors: try next base / back off
                    last = e
            time.sleep(min(2 ** attempt * 0.5, 10))
        raise BinanceError(f"Binance request failed after retries: {last}")

    def klines(self, symbol, interval, start_ms=None, end_ms=None, limit=1000):
        p = {"symbol": normalize_symbol(symbol), "interval": interval, "limit": limit}
        if start_ms is not None: p["startTime"] = int(start_ms)
        if end_ms is not None: p["endTime"] = int(end_ms)
        return self._get("/api/v3/klines", p)

    @staticmethod
    def _to_df(rows, now_ms) -> pd.DataFrame:
        cols = ["open_time", "open", "high", "low", "close", "volume", "close_time", "quote_volume", "trade_count"]
        df = pd.DataFrame([r[:9] for r in rows], columns=cols)
        df = df[df["close_time"] < now_ms].copy()  # completed candles only
        for c in ["open", "high", "low", "close", "volume", "quote_volume"]: df[c] = df[c].astype(float)
        df["trade_count"] = df["trade_count"].astype(int)
        df["timestamp"] = pd.to_datetime(df["open_time"], unit="ms", utc=True)
        return df[["timestamp", "open", "high", "low", "close", "volume", "quote_volume", "trade_count"]]

    def fetch_history(self, symbol, interval, start: pd.Timestamp, end: pd.Timestamp | None = None,
                      max_candles: int = 60000, recover_gaps: bool = True) -> pd.DataFrame:
        if interval not in INTERVAL_SECONDS: raise BinanceError(f"Unsupported interval {interval}")
        step_ms = INTERVAL_SECONDS[interval] * 1000
        cur = int(start.timestamp() * 1000)
        end_ms = int(end.timestamp() * 1000) if end is not None else None
        parts, now_ms = [], int(time.time() * 1000)
        while len(parts) * 1000 < max_candles:
            rows = self.klines(symbol, interval, cur, end_ms, 1000)
            if not rows: break
            parts.append(self._to_df(rows, now_ms))
            nxt = rows[-1][0] + step_ms
            if nxt <= cur or len(rows) < 1000: break
            cur = nxt
        parts = [p for p in parts if len(p)]
        if not parts: raise BinanceError("Binance returned no completed candles")
        df = pd.concat(parts).drop_duplicates("timestamp").sort_values("timestamp").reset_index(drop=True)
        if recover_gaps: df = self._recover_gaps(df, symbol, interval, step_ms, now_ms)
        return df

    def _recover_gaps(self, df, symbol, interval, step_ms, now_ms):
        d = df["timestamp"].diff().dt.total_seconds().fillna(step_ms / 1000)
        gaps = df.loc[d > 1.5 * step_ms / 1000]
        if gaps.empty: return df
        extra = []
        for i in gaps.index:
            s = int(df["timestamp"].iloc[i - 1].timestamp() * 1000) + step_ms
            e = int(df["timestamp"].iloc[i].timestamp() * 1000) - 1
            try:
                rows = self.klines(symbol, interval, s, e, 1000)
                if rows: extra.append(self._to_df(rows, now_ms))
            except BinanceError as ex:
                log.warning("gap recovery failed: %s", ex)
        if extra:
            df = pd.concat([df] + extra).drop_duplicates("timestamp").sort_values("timestamp").reset_index(drop=True)
        return df

    def symbol_info(self, symbol) -> dict:
        data = self._get("/api/v3/exchangeInfo", {"symbol": normalize_symbol(symbol)})
        s = data["symbols"][0]
        if s["status"] != "TRADING": raise BinanceError(f"{symbol} is not TRADING")
        f = {x["filterType"]: x for x in s["filters"]}
        return {"symbol": s["symbol"], "base": s["baseAsset"], "quote": s["quoteAsset"],
                "tick_size": float(f["PRICE_FILTER"]["tickSize"]), "step_size": float(f["LOT_SIZE"]["stepSize"]),
                "min_notional": float((f.get("NOTIONAL") or f.get("MIN_NOTIONAL") or {}).get("minNotional", 5.0))}

    def ticker_24h(self, symbols):
        rows = self._get("/api/v3/ticker/24hr", {"symbols": json.dumps([normalize_symbol(s) for s in symbols], separators=(",", ":"))})
        return {r["symbol"]: {"price": float(r["lastPrice"]), "change_pct": float(r["priceChangePercent"]),
                              "high": float(r["highPrice"]), "low": float(r["lowPrice"]), "volume": float(r["volume"])} for r in rows}

    def book_ticker(self, symbol):
        r = self._get("/api/v3/ticker/bookTicker", {"symbol": normalize_symbol(symbol)})
        bid, ask = float(r["bidPrice"]), float(r["askPrice"])
        return {"bid": bid, "ask": ask, "spread_bps": (ask - bid) / ((ask + bid) / 2) * 1e4}


def freshness(last_open: pd.Timestamp, interval_s: float, now: pd.Timestamp | None = None, grace_s: float = 90) -> dict:
    """The newest completed candle should have closed less than one interval (+grace) ago."""
    now = now or pd.Timestamp.now(tz="UTC")
    age = (now - (last_open + pd.Timedelta(seconds=interval_s))).total_seconds()
    return {"age_seconds": age, "stale": age > interval_s + grace_s, "last_candle_open": last_open.isoformat()}


class LiveFeed:
    """Background WebSocket consumer for miniTicker streams, with reconnect + freshness tracking."""
    def __init__(self, symbols):
        self.symbols = [normalize_symbol(s) for s in symbols]
        self.last: dict[str, dict] = {}
        self._task: asyncio.Task | None = None

    def start(self):
        if self._task is None: self._task = asyncio.create_task(self._run())

    async def stop(self):
        if self._task: self._task.cancel()

    async def _run(self):
        import websockets
        backoff = 1
        streams = "/".join(f"{s.lower()}@miniTicker" for s in self.symbols)
        while True:
            try:
                async with websockets.connect(f"{config.BINANCE_WS}?streams={streams}", ping_interval=20) as ws:
                    backoff = 1
                    async for msg in ws:
                        d = json.loads(msg).get("data", {})
                        if d.get("e") == "24hrMiniTicker":
                            o, c = float(d["o"]), float(d["c"])
                            self.last[d["s"]] = {"price": c, "change_pct": (c / o - 1) * 100 if o else 0.0,
                                                 "high": float(d["h"]), "low": float(d["l"]), "volume": float(d["v"]),
                                                 "event_time": d["E"], "received": time.time()}
            except asyncio.CancelledError:
                raise
            except Exception as e:
                log.warning("WS disconnected: %s (retry in %ss)", e, backoff)
                await asyncio.sleep(backoff); backoff = min(backoff * 2, 60)

    def get(self, symbol, max_age=15):
        d = self.last.get(normalize_symbol(symbol))
        return d if d and time.time() - d["received"] <= max_age else None
