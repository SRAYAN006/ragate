"""Column auto-detection, dataset validation and explicit (logged) cleaning."""
from __future__ import annotations
import re
from pathlib import Path
import pandas as pd

ALIASES = {
    "timestamp": ["timestamp", "date", "datetime", "open_time", "opentime", "time", "date_time", "unix",
                  "start_time", "candle_begin_time", "open_date", "timestamp_utc"],
    "open": ["open", "opening_price", "open_price", "first"],
    "high": ["high", "highest_price", "high_price", "max"],
    "low": ["low", "lowest_price", "low_price", "min"],
    "close": ["close", "closing_price", "close_price", "adj_close", "last"],
    "volume": ["volume", "traded_volume", "vol", "volume_btc", "base_volume", "volume_base", "base_asset_volume"],
    "symbol": ["symbol", "pair", "ticker", "asset", "market"],
    "quote_volume": ["quote_volume", "quote_asset_volume", "volume_usdt", "volume_usd", "quote_vol"],
    "trade_count": ["trade_count", "trades", "number_of_trades", "num_trades", "count"],
}
REQUIRED = ["timestamp", "open", "high", "low", "close"]
NUMERIC = ["open", "high", "low", "close", "volume", "quote_volume", "trade_count"]


class DataValidationError(ValueError):
    pass


def _norm(s) -> str:
    return re.sub(r"[^a-z0-9]+", "_", str(s).strip().lower()).strip("_")


def detect_columns(columns) -> dict:
    """Return canonical -> original column name (or None)."""
    normed = {c: _norm(c) for c in columns}
    out, used = {}, set()
    for canon, aliases in ALIASES.items():
        found = None
        for alias in aliases:  # alias priority order
            for orig, n in normed.items():
                if n == alias and orig not in used:
                    found = orig
                    break
            if found is not None:
                break
        out[canon] = found
        if found is not None:
            used.add(found)
    return out


def load_table(path: Path) -> pd.DataFrame:
    suffix = path.suffix.lower()
    if suffix in (".xlsx", ".xls"):
        return pd.read_excel(path)
    if suffix in (".csv", ".txt"):
        return pd.read_csv(path, sep=None, engine="python")
    raise DataValidationError(f"Unsupported file type '{suffix}'. Upload CSV or XLSX.")


def parse_timestamps(s: pd.Series) -> pd.Series:
    num = pd.to_numeric(s, errors="coerce")
    if num.notna().mean() > 0.9:
        med = num.dropna().abs().median()
        unit = "ns" if med > 1e17 else "us" if med > 1e14 else "ms" if med > 1e11 else "s"
        return pd.to_datetime(num, unit=unit, utc=True, errors="coerce")
    return pd.to_datetime(s, utc=True, errors="coerce")


def build_frame(raw: pd.DataFrame, mapping: dict) -> pd.DataFrame:
    cols = {}
    for canon, orig in mapping.items():
        if orig and orig in raw.columns:
            cols[canon] = raw[orig]
    return pd.DataFrame(cols)


def infer_interval_seconds(ts: pd.Series) -> float | None:
    d = ts.sort_values().diff().dropna().dt.total_seconds()
    d = d[d > 0]
    return float(d.median()) if len(d) else None


def validate(raw: pd.DataFrame, mapping: dict | None = None) -> dict:
    """Pure reporting: nothing is modified."""
    mapping = mapping or detect_columns(raw.columns)
    missing_req = [c for c in REQUIRED if not mapping.get(c)]
    rep: dict = {"n_rows": int(len(raw)), "n_columns": int(raw.shape[1]), "mapping": mapping,
                 "columns": [str(c) for c in raw.columns], "issues": [], "supported": True}
    if missing_req:
        rep.update(supported=False, status="UNSUPPORTED", message=(
            "This file does not look like an OHLCV financial time series. Missing required columns: "
            f"{', '.join(missing_req)}. RAGATE's models need timestamp, open, high, low and close "
            "(volume recommended). Map the columns manually if they use different names."))
        return rep
    df = build_frame(raw, mapping)
    ts = parse_timestamps(df["timestamp"])
    invalid_ts = int(ts.isna().sum())
    num = {c: pd.to_numeric(df[c], errors="coerce") for c in NUMERIC if c in df}
    non_numeric = {c: int((num[c].isna() & df[c].notna()).sum()) for c in num}
    missing_cnt = {c: int(num[c].isna().sum()) for c in num}
    missing_pct = {c: round(100 * v / max(len(df), 1), 3) for c, v in missing_cnt.items()}
    overall_missing = round(100 * sum(missing_cnt.values()) / max(len(df) * max(len(num), 1), 1), 3)
    valid = ts.notna()
    dup = int(ts[valid].duplicated().sum())
    o, h, l, c = (num[k] for k in ("open", "high", "low", "close"))
    nonpos = int(((o <= 0) | (h <= 0) | (l <= 0) | (c <= 0)).sum())
    ohlc_bad = int(((h < pd.concat([o, c, l], axis=1).max(axis=1)) |
                    (l > pd.concat([o, c, h], axis=1).min(axis=1))).sum())
    t = ts[valid].drop_duplicates().sort_values()
    interval = infer_interval_seconds(t) if len(t) > 2 else None
    missing_candles = irregular = 0
    if interval:
        d = t.diff().dropna().dt.total_seconds()
        gaps = d[d > 1.5 * interval]
        missing_candles = int(sum(round(g / interval) - 1 for g in gaps))
        irregular = int(((d - interval).abs() > 0.01 * interval).sum())
    unsorted = bool((ts[valid].diff().dt.total_seconds().dropna() < 0).any())
    sym = None
    if mapping.get("symbol"):
        vals = df["symbol"].dropna().unique()
        sym = str(vals[0]) if len(vals) == 1 else f"{len(vals)} symbols"

    def issue(sev, code, msg, count=None):
        rep["issues"].append({"severity": sev, "code": code, "message": msg, "count": count})

    if invalid_ts: issue("error", "INVALID_TIMESTAMP", "Rows with unparseable timestamps", invalid_ts)
    if dup: issue("error", "DUPLICATE_TIMESTAMP", "Duplicate timestamps", dup)
    if any(non_numeric.values()): issue("error", "NON_NUMERIC", f"Non-numeric values: {non_numeric}")
    if nonpos: issue("error", "NON_POSITIVE_PRICE", "Rows with non-positive prices", nonpos)
    if ohlc_bad: issue("error", "OHLC_INCONSISTENT", "Rows where high/low contradict open/close", ohlc_bad)
    if sum(missing_cnt.values()): issue("warning", "MISSING_VALUES", f"Missing values by column: {missing_cnt}")
    if missing_candles: issue("warning", "MISSING_CANDLES", "Missing candles inside the date range", missing_candles)
    if irregular and not missing_candles: issue("warning", "IRREGULAR_INTERVAL", "Irregular time deltas", irregular)
    if unsorted: issue("warning", "UNSORTED", "Rows are not in chronological order (will be sorted and logged)")
    if "volume" not in df: issue("warning", "NO_VOLUME", "No volume column: volume features are disabled")
    if len(t) < 300: issue("warning", "SHORT_HISTORY", f"Only {len(t)} candles; training needs >= 1000 for reliable results")
    errs = any(i["severity"] == "error" for i in rep["issues"])
    rep.update(
        status="FAIL" if errs else ("WARN" if rep["issues"] else "PASS"),
        missing_pct=missing_pct, overall_missing_pct=overall_missing, invalid_timestamps=invalid_ts,
        duplicate_timestamps=dup, non_numeric=non_numeric, non_positive_prices=nonpos,
        ohlc_violations=ohlc_bad, missing_candles=missing_candles, irregular_intervals=irregular,
        interval_seconds=interval, symbol=sym,
        start=t.iloc[0].isoformat() if len(t) else None, end=t.iloc[-1].isoformat() if len(t) else None,
        indicators_available=["returns", "EMA/SMA", "MACD", "RSI", "ROC", "ATR", "Bollinger", "candle ratios"] +
                             (["volume features"] if "volume" in df else []))
    return rep


def clean(raw: pd.DataFrame, mapping: dict, options: dict | None = None) -> tuple[pd.DataFrame, list]:
    """Apply user-chosen handling. Every modification is logged; nothing is silent.

    options: duplicates: error|keep_first|keep_last; invalid_rows: error|drop;
             missing_values: error|drop_rows|ffill|interpolate; fill_missing_candles: bool
    """
    opts = {"duplicates": "error", "invalid_rows": "error", "missing_values": "error",
            "fill_missing_candles": False, **(options or {})}
    log: list = []
    rep = validate(raw, mapping)
    if not rep["supported"]:
        raise DataValidationError(rep["message"])
    df = build_frame(raw, mapping)
    df["timestamp"] = parse_timestamps(df["timestamp"])
    for c in NUMERIC:
        if c in df: df[c] = pd.to_numeric(df[c], errors="coerce")
    n0 = len(df)
    bad_ts = df["timestamp"].isna()
    if bad_ts.any():
        if opts["invalid_rows"] == "error": raise DataValidationError(f"{int(bad_ts.sum())} rows have invalid timestamps (set invalid_rows=drop to remove them)")
        df = df[~bad_ts]; log.append({"action": "dropped_invalid_timestamp_rows", "count": int(bad_ts.sum())})
    if "symbol" in df and df["symbol"].nunique() > 1:
        raise DataValidationError("File contains multiple symbols; upload one symbol per file")
    if not df["timestamp"].is_monotonic_increasing:
        df = df.sort_values("timestamp"); log.append({"action": "sorted_chronologically"})
    if df["timestamp"].duplicated().any():
        if opts["duplicates"] == "error": raise DataValidationError(f"{int(df['timestamp'].duplicated().sum())} duplicate timestamps; choose keep_first or keep_last")
        keep = "first" if opts["duplicates"] == "keep_first" else "last"
        before = len(df); df = df.drop_duplicates("timestamp", keep=keep)
        log.append({"action": f"dropped_duplicates_{keep}", "count": before - len(df)})
    px = ["open", "high", "low", "close"]
    nums = [c for c in NUMERIC if c in df]
    na = df[nums].isna().any(axis=1)
    if na.any():
        mv = opts["missing_values"]
        if mv == "error": raise DataValidationError(f"{int(na.sum())} rows contain missing values; choose drop_rows, ffill or interpolate")
        if mv == "drop_rows": df = df[~na]
        elif mv == "ffill": df[nums] = df[nums].ffill()
        elif mv == "interpolate": df[nums] = df[nums].interpolate(limit_direction="forward")
        df = df.dropna(subset=px)
        log.append({"action": f"missing_values_{mv}", "rows_affected": int(na.sum())})
    nonpos = (df[px] <= 0).any(axis=1)
    if nonpos.any():
        if opts["invalid_rows"] == "error": raise DataValidationError(f"{int(nonpos.sum())} rows have non-positive prices")
        df = df[~nonpos]; log.append({"action": "dropped_non_positive_price_rows", "count": int(nonpos.sum())})
    bad = (df["high"] < df[["open", "close", "low"]].max(axis=1)) | (df["low"] > df[["open", "close", "high"]].min(axis=1))
    if bad.any():
        if opts["invalid_rows"] == "error": raise DataValidationError(f"{int(bad.sum())} rows violate OHLC relationships")
        df = df[~bad]; log.append({"action": "dropped_ohlc_inconsistent_rows", "count": int(bad.sum())})
    df = df.reset_index(drop=True)
    if opts["fill_missing_candles"] and len(df) > 2:
        iv = infer_interval_seconds(df["timestamp"])
        full = pd.date_range(df["timestamp"].iloc[0], df["timestamp"].iloc[-1], freq=pd.Timedelta(seconds=iv))
        added = len(full) - len(df)
        if added > 0:
            df = df.set_index("timestamp").reindex(full)
            df[px] = df[px].ffill()
            for c in ("volume", "quote_volume", "trade_count"):
                if c in df: df[c] = df[c].fillna(0.0)
            df.index.name = "timestamp"; df = df.reset_index()
            log.append({"action": "filled_missing_candles_flat", "count": int(added),
                        "note": "synthetic flat candles with zero volume; treat results with caution"})
    log.insert(0, {"action": "summary", "rows_in": n0, "rows_out": int(len(df))})
    if len(df) < 50: raise DataValidationError("Fewer than 50 usable candles after cleaning")
    return df, log


def save_dataset(df: pd.DataFrame, path: Path):
    out = df.copy()
    out["timestamp"] = out["timestamp"].dt.strftime("%Y-%m-%dT%H:%M:%S%z")
    out.to_csv(path, index=False)


def load_dataset(path: Path) -> pd.DataFrame:
    df = pd.read_csv(path)
    df["timestamp"] = pd.to_datetime(df["timestamp"], utc=True)
    return df.sort_values("timestamp").reset_index(drop=True)
