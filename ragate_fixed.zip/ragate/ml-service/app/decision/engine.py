"""Decision engine: BUY / HOLD / REDUCE / EXIT / ABSTAIN with explicit reasons. Never sends orders."""
from __future__ import annotations
from dataclasses import dataclass


@dataclass
class DecisionConfig:
    buy_threshold: float = 0.0       # min net entry return
    exit_threshold: float = 0.004    # exit when net hold return < -exit_threshold
    exit_stress: float = 0.75
    rebalance_band: float = 0.03     # ignore weight changes smaller than this
    min_prob_positive: float = 0.0   # optional probability gate


def decide(ragate: dict, risk: dict | None, current_weight: float, regime_probs: dict, data_stale: bool = False,
           cfg: DecisionConfig | None = None) -> dict:
    cfg = cfg or DecisionConfig()
    R = []
    def out(a, tw=None): return {"action": a, "target_weight": tw if tw is not None else current_weight, "reasons": R}
    if data_stale: R.append("Market data is stale: refusing to act."); return out("ABSTAIN")
    if ragate.get("status") != "ok" or not ragate.get("combined"): R.append("No expert outputs available."); return out("ABSTAIN")
    if ragate.get("all_flagged"): R.append("CUSUM flagged every available expert as deteriorating: forecast unreliable."); return out("ABSTAIN")
    if risk is None: R.append("Risk evaluation unavailable."); return out("ABSTAIN")
    comb = ragate["combined"]
    R.append(f"Combined forecast {comb['combined_return']*100:.3f}%, uncertainty {comb['sigma_total']*100:.3f}%, P(up) {comb['prob_positive']:.2f}.")
    R.append(f"Net return after costs: entry {risk['net_return_entry']*100:.3f}%, hold {risk['net_return_hold']*100:.3f}%.")
    holding = current_weight > 1e-6
    stress = regime_probs.get("stress", 0)
    if holding:
        if risk["net_return_hold"] < -cfg.exit_threshold or stress > cfg.exit_stress:
            R.append("Negative net expected return or stress regime dominant: exit."); return out("EXIT", 0.0)
        tw = risk["target_weight"]
        if tw < current_weight - cfg.rebalance_band:
            R.append(f"Risk-adjusted target {tw:.2%} is below current {current_weight:.2%}: reduce."); return out("REDUCE", tw)
        if tw > current_weight + cfg.rebalance_band and risk["allowed_entry"] and risk["net_return_entry"] > cfg.buy_threshold:
            R.append(f"Target {tw:.2%} above current {current_weight:.2%} and risk checks pass: increase."); return out("BUY", tw)
        R.append("Position is within tolerance of the risk-adjusted target."); return out("HOLD")
    attractive = risk["net_return_entry"] > cfg.buy_threshold and comb["prob_positive"] >= cfg.min_prob_positive and comb["combined_return"] > 0
    if risk["allowed_entry"] and attractive:
        R.append(f"All risk checks passed; target exposure {risk['target_weight']:.2%}."); return out("BUY", risk["target_weight"])
    if comb["combined_return"] > 0:   # positive forecast vetoed by risk engine
        R.append("Positive forecast rejected by risk engine: " + ", ".join(risk["failed_checks"]) + "."); return out("ABSTAIN", 0.0)
    R.append("Forecast not attractive after costs; staying in cash."); return out("HOLD", 0.0)
