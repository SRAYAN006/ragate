import numpy as np
from scipy.stats import norm


def prob_positive(mu, sigma):
    sigma = np.maximum(np.asarray(sigma, dtype=float), 1e-9)
    return norm.cdf(np.asarray(mu, dtype=float) / sigma)


def classification_metrics(y_true_ret, y_pred_ret) -> dict:
    m = np.isfinite(y_true_ret) & np.isfinite(y_pred_ret)
    if m.sum() == 0: return {"n": 0}
    y, p = np.asarray(y_true_ret)[m], np.asarray(y_pred_ret)[m]
    yt, yp = y > 0, p > 0
    tp, fp, fn = (yt & yp).sum(), (~yt & yp).sum(), (yt & ~yp).sum()
    prec = tp / (tp + fp) if tp + fp else 0.0
    rec = tp / (tp + fn) if tp + fn else 0.0
    return {"n": int(m.sum()), "mae": float(np.abs(y - p).mean()), "rmse": float(np.sqrt(((y - p) ** 2).mean())),
            "directional_accuracy": float((yt == yp).mean()), "precision": float(prec), "recall": float(rec),
            "f1": float(2 * prec * rec / (prec + rec)) if prec + rec else 0.0}
