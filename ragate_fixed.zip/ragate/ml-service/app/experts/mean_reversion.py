"""Statistical mean-reversion expert. Sign of the relationship is *estimated*, never assumed."""
from __future__ import annotations
import joblib
import numpy as np
import pandas as pd
from .common import prob_positive


class MeanReversionExpert:
    name = "mean_reversion"

    def __init__(self, horizons: dict[str, int], window: int = 50):
        self.horizons, self.window = horizons, window
        self.params: dict = {}

    def _signals(self, df: pd.DataFrame, feat: pd.DataFrame):
        c = df["close"]
        z = (c - c.rolling(self.window).mean()) / c.rolling(self.window).std().replace(0, np.nan)
        trend = feat["ema_slope_50"] / feat["roll_std_50"].replace(0, np.nan)   # drift in vol units
        return z, trend, feat["roll_std_20"]

    def fit(self, df_train, feat_train, Y_train: pd.DataFrame):
        z, trend, vol = self._signals(df_train, feat_train)
        tau = float(np.nanpercentile(np.abs(trend), 75))
        vcut = float(np.nanpercentile(vol, 90))
        allowed = (np.abs(trend) < tau) & (vol < vcut)
        for h in self.horizons:
            m = z.notna() & Y_train[h].notna() & allowed
            x, y = z[m].values, Y_train[h][m].values
            if len(x) < 50:
                self.params[h] = {"beta": 0.0, "alpha": 0.0, "resid_std": float(np.nanstd(Y_train[h])), "n": int(len(x))}
                continue
            beta = float(np.cov(x, y)[0, 1] / np.var(x, ddof=1)); alpha = float(y.mean() - beta * x.mean())
            res = y - (alpha + beta * x)
            self.params[h] = {"beta": beta, "alpha": alpha, "resid_std": float(res.std()), "n": int(len(x)),
                              "mean_reverting": beta < 0}   # honest flag: False means no reversion found in-sample
        self.tau, self.vcut = tau, vcut
        return self

    def predict(self, df: pd.DataFrame, feat: pd.DataFrame) -> dict[str, pd.DataFrame]:
        z, trend, vol = self._signals(df, feat)
        allowed = (np.abs(trend) < self.tau) & (vol < self.vcut)
        out = {}
        for h, p in self.params.items():
            mu = (p["alpha"] + p["beta"] * z).where(allowed, 0.0)   # trending/high-vol regime: no reversion forecast
            sig = pd.Series(p["resid_std"], index=df.index).where(allowed, p["resid_std"] * 1.5)
            d = pd.DataFrame({"pred": mu, "prob_pos": prob_positive(mu.values, sig.values), "sigma": sig})
            d.loc[z.isna().values | trend.isna().values | vol.isna().values, :] = np.nan
            out[h] = d
        return out

    def save(self, d): joblib.dump(self, d / "mean_reversion.joblib")

    @staticmethod
    def load(d): return joblib.load(d / "mean_reversion.joblib")
