"""R-CTE: Regime-Conditioned Temporal Expert (PyTorch).

feature sequence -> projection -> positional encoding -> N x [MHSA + residual + LayerNorm + FFN + residual + LayerNorm]
-> attention pooling -> regime fusion (FiLM | concat | add | none) -> heads: (mu, direction logit, log-variance) per horizon.
"""
from __future__ import annotations
import math
import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import torch.nn.functional as F
from .common import prob_positive

FUSIONS = ("film", "concat", "add", "none")


class PositionalEncoding(nn.Module):
    def __init__(self, d, max_len=512):
        super().__init__()
        pe = torch.zeros(max_len, d)
        pos = torch.arange(max_len).unsqueeze(1)
        div = torch.exp(torch.arange(0, d, 2) * (-math.log(10000.0) / d))
        pe[:, 0::2], pe[:, 1::2] = torch.sin(pos * div), torch.cos(pos * div[: d // 2])
        self.register_buffer("pe", pe.unsqueeze(0))

    def forward(self, x): return x + self.pe[:, : x.size(1)]


class TemporalBlock(nn.Module):
    def __init__(self, d, heads, ff, dropout):
        super().__init__()
        self.attn = nn.MultiheadAttention(d, heads, dropout=dropout, batch_first=True)
        self.n1, self.n2 = nn.LayerNorm(d), nn.LayerNorm(d)
        self.ff = nn.Sequential(nn.Linear(d, ff), nn.GELU(), nn.Dropout(dropout), nn.Linear(ff, d))
        self.drop = nn.Dropout(dropout)

    def forward(self, x):
        a, _ = self.attn(x, x, x, need_weights=False)
        x = self.n1(x + self.drop(a))
        return self.n2(x + self.drop(self.ff(x)))


class RCTE(nn.Module):
    def __init__(self, n_features, n_horizons=3, d_model=48, heads=4, layers=2, ff=96, dropout=0.15,
                 fusion="film", n_regimes=3, max_len=512):
        super().__init__()
        assert fusion in FUSIONS
        self.fusion, self.H = fusion, n_horizons
        self.proj = nn.Linear(n_features, d_model)
        self.pos = PositionalEncoding(d_model, max_len)
        self.blocks = nn.ModuleList([TemporalBlock(d_model, heads, ff, dropout) for _ in range(layers)])
        self.pool = nn.Linear(d_model, 1)
        if fusion == "film":
            self.film = nn.Linear(n_regimes, 2 * d_model)
            nn.init.zeros_(self.film.weight); nn.init.zeros_(self.film.bias)   # starts as identity
        elif fusion == "add":
            self.reg_emb = nn.Linear(n_regimes, d_model)
        head_in = d_model + (n_regimes if fusion == "concat" else 0)
        self.head = nn.Sequential(nn.Linear(head_in, d_model), nn.GELU(), nn.Dropout(dropout), nn.Linear(d_model, 3 * n_horizons))

    def forward(self, x, regime):
        h = self.pos(self.proj(x))
        for b in self.blocks: h = b(h)
        w = torch.softmax(self.pool(h), dim=1)
        z = (w * h).sum(1)
        if self.fusion == "film":
            g, b = self.film(regime).chunk(2, dim=-1); z = z * (1 + g) + b
        elif self.fusion == "add": z = z + self.reg_emb(regime)
        elif self.fusion == "concat": z = torch.cat([z, regime], dim=-1)
        o = self.head(z)
        return o[:, : self.H], o[:, self.H: 2 * self.H], o[:, 2 * self.H:]  # mu, logit, logvar


def _windows(X: np.ndarray, idx: np.ndarray, L: int) -> np.ndarray:
    return np.stack([X[i - L + 1: i + 1] for i in idx]).astype(np.float32)


def valid_end_positions(X: np.ndarray, L: int) -> np.ndarray:
    """Positions i whose full window X[i-L+1..i] is finite (no NaN warm-up rows)."""
    ok = np.isfinite(X).all(axis=1).astype(int)
    cs = np.concatenate([[0], np.cumsum(ok)])
    pos = np.arange(len(X))
    return pos[(pos >= L - 1) & (cs[pos + 1] - cs[np.maximum(pos - L + 1, 0)] == L)]


class RCTEExpert:
    name = "rcte"

    def __init__(self, features, horizons: dict[str, int], seq_len=48, fusion="film", d_model=48, layers=2,
                 epochs=40, patience=6, lr=1e-3, batch=128, seed=42):
        self.features, self.horizons, self.seq_len, self.fusion = features, horizons, seq_len, fusion
        self.cfg = dict(d_model=d_model, layers=layers, epochs=epochs, patience=patience, lr=lr, batch=batch, seed=seed)
        self.model: RCTE | None = None
        self.mean = self.std = self.ystd = None
        self.history: list = []

    def _dev(self): return torch.device("cuda" if torch.cuda.is_available() else "cpu")

    def fit(self, X_df: pd.DataFrame, R_df: pd.DataFrame, Y_df: pd.DataFrame, tr_idx, va_idx):
        """tr_idx / va_idx are integer row positions. Scalers use TRAIN rows only."""
        c = self.cfg; torch.manual_seed(c["seed"]); np.random.seed(c["seed"])
        X = X_df[self.features].values.astype(float)
        R = R_df.values.astype(np.float32)
        hk = list(self.horizons)
        Y = Y_df[hk].values.astype(float)
        self.mean = np.nanmean(X[tr_idx], axis=0); self.std = np.nanstd(X[tr_idx], axis=0) + 1e-9
        self.ystd = np.nanstd(Y[tr_idx], axis=0) + 1e-9
        Xs = np.clip((X - self.mean) / self.std, -6, 6)
        ok_end = set(valid_end_positions(Xs, self.seq_len)); okR = np.isfinite(R).all(axis=1)
        sel = lambda idx: np.array([i for i in idx if i in ok_end and okR[i] and np.isfinite(Y[i]).all()])
        tr, va = sel(tr_idx), sel(va_idx)
        if len(tr) < 200: raise ValueError(f"R-CTE needs >= 200 usable training windows, got {len(tr)}")
        dev = self._dev()
        self.model = RCTE(len(self.features), len(hk), c["d_model"], 4, c["layers"], c["d_model"] * 2, 0.15,
                          self.fusion, 3, max(512, self.seq_len + 1)).to(dev)
        def tens(idx):
            return (torch.tensor(_windows(Xs, idx, self.seq_len)), torch.tensor(R[idx]),
                    torch.tensor((Y[idx] / self.ystd).astype(np.float32)))
        Xt, Rt, Yt = tens(tr)
        Xv, Rv, Yv = tens(va) if len(va) else (None, None, None)
        opt = torch.optim.AdamW(self.model.parameters(), lr=c["lr"], weight_decay=1e-4)
        best, best_state, bad = np.inf, None, 0
        self.history = []

        def loss_fn(mu, lg, lv, y):
            lv = lv.clamp(-6, 3)
            nll = 0.5 * (lv + (y - mu) ** 2 / lv.exp()).mean()
            return nll + 0.5 * F.binary_cross_entropy_with_logits(lg, (y > 0).float()) + 0.5 * F.smooth_l1_loss(mu, y)

        for ep in range(c["epochs"]):
            self.model.train()
            perm = torch.randperm(len(Xt)); tl = 0.0
            for i in range(0, len(perm), c["batch"]):
                b = perm[i: i + c["batch"]]
                mu, lg, lv = self.model(Xt[b].to(dev), Rt[b].to(dev))
                loss = loss_fn(mu, lg, lv, Yt[b].to(dev))
                opt.zero_grad(); loss.backward(); nn.utils.clip_grad_norm_(self.model.parameters(), 1.0); opt.step()
                tl += loss.item() * len(b)
            vl = tl / len(Xt)
            if Xv is not None:
                self.model.eval()
                with torch.no_grad():
                    mu, lg, lv = self.model(Xv.to(dev), Rv.to(dev)); vl = loss_fn(mu, lg, lv, Yv.to(dev)).item()
            self.history.append({"epoch": ep + 1, "train_loss": tl / len(Xt), "val_loss": vl})
            if vl < best - 1e-5:
                best, bad = vl, 0; best_state = {k: v.detach().cpu().clone() for k, v in self.model.state_dict().items()}
            else:
                bad += 1
                if bad >= c["patience"]: break
        if best_state: self.model.load_state_dict(best_state)
        self.model.cpu().eval()
        return self

    def predict(self, X_df: pd.DataFrame, R_df: pd.DataFrame) -> dict[str, pd.DataFrame]:
        hk = list(self.horizons)
        Xs = np.clip((X_df[self.features].values.astype(float) - self.mean) / self.std, -6, 6)
        R = R_df.values.astype(np.float32)
        pos = np.array([i for i in valid_end_positions(Xs, self.seq_len) if np.isfinite(R[i]).all()])
        res = {h: pd.DataFrame(np.nan, index=X_df.index, columns=["pred", "prob_pos", "sigma"]) for h in hk}
        if len(pos) == 0: return res
        mus, lgs, lvs = [], [], []
        with torch.no_grad():
            for i in range(0, len(pos), 512):
                p = pos[i: i + 512]
                mu, lg, lv = self.model(torch.tensor(_windows(Xs, p, self.seq_len)), torch.tensor(R[p]))
                mus.append(mu.numpy()); lgs.append(lg.numpy()); lvs.append(lv.clamp(-6, 3).numpy())
        mu, lg, lv = np.vstack(mus) * self.ystd, np.vstack(lgs), np.vstack(lvs)
        sig = np.sqrt(np.exp(lv)) * self.ystd
        for j, h in enumerate(hk):
            res[h].iloc[pos, 0] = mu[:, j]
            res[h].iloc[pos, 1] = 1 / (1 + np.exp(-lg[:, j]))
            res[h].iloc[pos, 2] = sig[:, j]
        return res

    def save(self, d):
        torch.save({"state": self.model.state_dict(), "features": self.features, "horizons": self.horizons,
                    "seq_len": self.seq_len, "fusion": self.fusion, "cfg": self.cfg, "mean": self.mean, "std": self.std,
                    "ystd": self.ystd, "history": self.history}, d / "rcte.pt")

    @staticmethod
    def load(d):
        ck = torch.load(d / "rcte.pt", map_location="cpu", weights_only=False)
        e = RCTEExpert(ck["features"], ck["horizons"], ck["seq_len"], ck["fusion"], ck["cfg"]["d_model"], ck["cfg"]["layers"])
        e.cfg, e.mean, e.std, e.ystd, e.history = ck["cfg"], ck["mean"], ck["std"], ck["ystd"], ck["history"]
        e.model = RCTE(len(e.features), len(e.horizons), e.cfg["d_model"], 4, e.cfg["layers"], e.cfg["d_model"] * 2, 0.15,
                       e.fusion, 3, max(512, e.seq_len + 1))
        e.model.load_state_dict(ck["state"]); e.model.eval()
        return e
