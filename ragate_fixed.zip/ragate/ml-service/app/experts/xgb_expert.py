from __future__ import annotations
import joblib
import numpy as np
import pandas as pd
from xgboost import XGBRegressor, XGBClassifier
from .common import prob_positive


class XGBExpert:
    name = "xgboost"

    def __init__(self, features: list[str], horizons: dict[str, int], seed: int = 42):
        self.features, self.horizons, self.seed = features, horizons, seed
        self.reg, self.clf, self.resid_std, self.importance = {}, {}, {}, {}

    def fit(self, X_tr, Y_tr: pd.DataFrame, X_va, Y_va: pd.DataFrame):
        common = dict(n_estimators=400, max_depth=4, learning_rate=0.03, subsample=0.8, colsample_bytree=0.8,
                      reg_lambda=2.0, random_state=self.seed, n_jobs=2, tree_method="hist")
        for h in self.horizons:
            mt, mv = Y_tr[h].notna().values, Y_va[h].notna().values
            es = 30 if mv.sum() > 30 else None
            reg = XGBRegressor(**common, early_stopping_rounds=es)
            reg.fit(X_tr[mt], Y_tr[h][mt], eval_set=[(X_va[mv], Y_va[h][mv])] if es else None, verbose=False)
            self.reg[h] = reg
            yb = (Y_tr[h][mt] > 0).astype(int)
            if yb.nunique() == 2:
                clf = XGBClassifier(**common, early_stopping_rounds=es)
                ev = [(X_va[mv], (Y_va[h][mv] > 0).astype(int))] if es and (Y_va[h][mv] > 0).nunique() == 2 else None
                if ev is None: clf = XGBClassifier(**common)
                clf.fit(X_tr[mt], yb, eval_set=ev, verbose=False)
                self.clf[h] = clf
            ref = (X_va[mv], Y_va[h][mv]) if mv.sum() > 30 else (X_tr[mt], Y_tr[h][mt])
            self.resid_std[h] = float(np.std(ref[1].values - reg.predict(ref[0])))
            self.importance[h] = dict(sorted(zip(self.features, map(float, reg.feature_importances_)),
                                             key=lambda kv: -kv[1]))
        return self

    def predict(self, X: pd.DataFrame) -> dict[str, pd.DataFrame]:
        out = {}
        Xf = X[self.features]
        for h, reg in self.reg.items():
            mu = reg.predict(Xf)
            sig = np.full(len(Xf), self.resid_std[h])
            p = self.clf[h].predict_proba(Xf)[:, 1] if h in self.clf else prob_positive(mu, sig)
            df = pd.DataFrame({"pred": mu, "prob_pos": p, "sigma": sig}, index=X.index)
            df.loc[Xf.isna().any(axis=1).values, :] = np.nan   # warm-up rows: no forecast
            out[h] = df
        return out

    def save(self, d): joblib.dump(self, d / "xgboost.joblib")

    @staticmethod
    def load(d): return joblib.load(d / "xgboost.joblib")
