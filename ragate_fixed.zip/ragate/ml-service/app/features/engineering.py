"""Causal feature engineering: every value at row t uses only rows <= t (no look-ahead)."""
from __future__ import annotations
import numpy as np
import pandas as pd

# Scale-free columns usable by models
MODEL_FEATURES = [
    "ret_1", "logret_1", "ret_roll_6", "ret_roll_18", "oc_diff", "hl_range",
    "dist_ema_20", "dist_ema_50", "dist_ema_100", "dist_sma_20", "dist_sma_50",
    "macd_n", "macd_signal_n", "macd_hist_n", "ema_slope_20", "ema_slope_50", "sma_slope_20",
    "rsi_14", "roc_10", "atr_n", "roll_std_20", "roll_std_50", "bb_width", "bb_pos",
    "vol_change", "rel_volume", "body_ratio", "upper_wick", "lower_wick",
]
CHART_COLUMNS = ["ema_20", "ema_50", "ema_100", "sma_20", "sma_50", "macd", "macd_signal", "macd_hist",
                 "rsi_14", "atr_14", "bb_mid", "bb_upper", "bb_lower"]
HORIZON_DAYS = {"1d": 1, "3d": 3, "5d": 5}


def horizons_for(interval_seconds: float) -> dict[str, int]:
    """1/3/5-day horizons expressed in candles (4h candles -> 6/18/30)."""
    cpd = 86400.0 / interval_seconds
    return {k: max(1, int(round(d * cpd))) for k, d in HORIZON_DAYS.items()}


def _ema(s, n): return s.ewm(span=n, adjust=False, min_periods=n).mean()


def _rsi(close, n=14):
    d = close.diff()
    up = d.clip(lower=0).ewm(alpha=1 / n, adjust=False, min_periods=n).mean()
    dn = (-d.clip(upper=0)).ewm(alpha=1 / n, adjust=False, min_periods=n).mean()
    rs = up / dn.replace(0, np.nan)
    out = 100 - 100 / (1 + rs)
    return out.where(dn != 0, 100.0).where(up.notna())


def compute_features(df: pd.DataFrame) -> pd.DataFrame:
    c, o, h, l = df["close"], df["open"], df["high"], df["low"]
    f = pd.DataFrame(index=df.index)
    f["ret_1"] = c.pct_change()
    f["logret_1"] = np.log(c / c.shift(1))
    f["ret_roll_6"] = c.pct_change(6)
    f["ret_roll_18"] = c.pct_change(18)
    f["oc_diff"] = (c - o) / o
    f["hl_range"] = (h - l) / c
    for n in (20, 50, 100):
        f[f"ema_{n}"] = _ema(c, n)
        f[f"dist_ema_{n}"] = c / f[f"ema_{n}"] - 1
    for n in (20, 50):
        f[f"sma_{n}"] = c.rolling(n).mean()
        f[f"dist_sma_{n}"] = c / f[f"sma_{n}"] - 1
    macd = _ema(c, 12) - _ema(c, 26)
    sig = macd.ewm(span=9, adjust=False, min_periods=9).mean()
    f["macd"], f["macd_signal"], f["macd_hist"] = macd, sig, macd - sig
    f["macd_n"], f["macd_signal_n"], f["macd_hist_n"] = macd / c, sig / c, (macd - sig) / c
    f["ema_slope_20"] = f["ema_20"].pct_change(5)
    f["ema_slope_50"] = f["ema_50"].pct_change(5)
    f["sma_slope_20"] = f["sma_20"].pct_change(5)
    f["rsi_14"] = _rsi(c, 14)
    f["roc_10"] = c.pct_change(10) * 100
    tr = pd.concat([h - l, (h - c.shift()).abs(), (l - c.shift()).abs()], axis=1).max(axis=1)
    f["atr_14"] = tr.ewm(alpha=1 / 14, adjust=False, min_periods=14).mean()
    f["atr_n"] = f["atr_14"] / c
    f["roll_std_20"] = f["logret_1"].rolling(20).std()
    f["roll_std_50"] = f["logret_1"].rolling(50).std()
    mid, sd = c.rolling(20).mean(), c.rolling(20).std()
    f["bb_mid"], f["bb_upper"], f["bb_lower"] = mid, mid + 2 * sd, mid - 2 * sd
    f["bb_width"] = (f["bb_upper"] - f["bb_lower"]) / mid
    f["bb_pos"] = (c - f["bb_lower"]) / (f["bb_upper"] - f["bb_lower"]).replace(0, np.nan)
    if "volume" in df and df["volume"].notna().any():
        v = df["volume"]
        f["vol_change"] = v.pct_change().replace([np.inf, -np.inf], np.nan).clip(-5, 5)
        f["rel_volume"] = (v / v.rolling(20).mean().replace(0, np.nan))
    else:
        f["vol_change"], f["rel_volume"] = 0.0, 1.0
    rng = (h - l).replace(0, np.nan)
    f["body_ratio"] = (c - o) / rng
    f["upper_wick"] = (h - pd.concat([o, c], axis=1).max(axis=1)) / rng
    f["lower_wick"] = (pd.concat([o, c], axis=1).min(axis=1) - l) / rng
    return f.replace([np.inf, -np.inf], np.nan)


def make_targets(close: pd.Series, horizons: dict[str, int]) -> pd.DataFrame:
    """Forward log return from close[t] to close[t+h]. NaN where the future is unknown."""
    return pd.DataFrame({k: np.log(close.shift(-h) / close) for k, h in horizons.items()}, index=close.index)
