"""RAGATE ML service (FastAPI). All /internal endpoints require the X-Internal-Key header."""
from __future__ import annotations
import asyncio, json, logging, time
from contextlib import asynccontextmanager
from typing import Any
import numpy as np
import pandas as pd
from fastapi import Depends, FastAPI, Header, HTTPException, Query
from fastapi.responses import JSONResponse
from pydantic import BaseModel, Field

from . import config
from .data import columns as cols
from .data.binance import BinanceClient, BinanceError, LiveFeed, INTERVAL_SECONDS, freshness, normalize_symbol
from .features.engineering import compute_features, MODEL_FEATURES, CHART_COLUMNS
from .ragate import engine as rg
from .risk.engine import evaluate_risk
from .decision.engine import decide, DecisionConfig
from .training.bundle import get_bundle, list_models, EXPERTS
from .training.pipeline import train_models
from .backtest.engine import run_backtest

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")
log = logging.getLogger("ragate.ml")
feed = LiveFeed(config.DEFAULT_SYMBOLS)


@asynccontextmanager
async def lifespan(app):
    if config.ENABLE_LIVE_WS: feed.start()
    yield
    await feed.stop()


app = FastAPI(title="RAGATE ML Service", version="1.0", lifespan=lifespan)


def auth(x_internal_key: str = Header(default="")):
    if x_internal_key != config.INTERNAL_API_KEY: raise HTTPException(401, "Invalid internal API key")


@app.exception_handler(cols.DataValidationError)
async def _dv(_, e): return JSONResponse(status_code=422, content={"error": "DATA_VALIDATION", "message": str(e)})
@app.exception_handler(BinanceError)
async def _bn(_, e): return JSONResponse(status_code=502, content={"error": "BINANCE", "message": str(e)})
@app.exception_handler(FileNotFoundError)
async def _nf(_, e): return JSONResponse(status_code=404, content={"error": "NOT_FOUND", "message": str(e)})
@app.exception_handler(ValueError)
async def _ve(_, e): return JSONResponse(status_code=422, content={"error": "INVALID", "message": str(e)})


def _clean(o):
    """JSON-safe: NaN/inf -> None, numpy -> python."""
    if isinstance(o, dict): return {k: _clean(v) for k, v in o.items()}
    if isinstance(o, (list, tuple)): return [_clean(v) for v in o]
    if isinstance(o, (np.floating, float)): return None if not np.isfinite(o) else float(o)
    if isinstance(o, (np.integer,)): return int(o)
    if isinstance(o, (np.bool_,)): return bool(o)
    if isinstance(o, pd.Timestamp): return o.isoformat()
    return o


def _ds(dataset_id: str) -> pd.DataFrame:
    return cols.load_dataset(config.DATASET_DIR / f"{dataset_id}.csv")


def _frame_rows(df: pd.DataFrame, tail: int | None, ts: pd.Series) -> list:
    d = df.iloc[-tail:] if tail else df
    d = d.copy(); d.insert(0, "timestamp", ts.loc[d.index].dt.strftime("%Y-%m-%dT%H:%M:%SZ"))
    return _clean(d.to_dict("records"))


# ---------------------------------------------------------------- health
@app.get("/health")
def health():
    import torch, xgboost
    return {"status": "ok", "torch": torch.__version__, "xgboost": xgboost.__version__, "live_ws": config.ENABLE_LIVE_WS,
            "ws_symbols_live": list(feed.last), "storage": str(config.ROOT)}


# ---------------------------------------------------------------- data
class ValidateReq(BaseModel):
    path: str                                  # storage-relative (e.g. uploads/abc.csv)
    mapping: dict[str, str | None] | None = None
    commit: bool = False
    dataset_id: str | None = None
    options: dict[str, Any] | None = None
    symbol: str | None = None


@app.post("/internal/v1/data/validate", dependencies=[Depends(auth)])
def data_validate(r: ValidateReq):
    raw = cols.load_table(config.safe_path(r.path))
    mapping = r.mapping or cols.detect_columns(raw.columns)
    rep = cols.validate(raw, mapping)
    if not r.commit: return _clean(rep)
    if not r.dataset_id: raise ValueError("dataset_id required when commit=true")
    df, log_ = cols.clean(raw, mapping, r.options)
    cols.save_dataset(df, config.DATASET_DIR / f"{r.dataset_id}.csv")
    post = cols.validate(df.assign(timestamp=df["timestamp"].astype(str)), {c: c for c in df.columns})
    iv = cols.infer_interval_seconds(df["timestamp"])
    return _clean({"report": rep, "cleaning_log": log_, "post_clean": {"status": post["status"], "missing_candles": post["missing_candles"]},
                   "dataset": {"rows": len(df), "start": df["timestamp"].iloc[0], "end": df["timestamp"].iloc[-1], "interval_seconds": iv,
                               "symbol": r.symbol or rep.get("symbol") or "UNKNOWN", "overall_missing_pct": rep["overall_missing_pct"]}})


class BinanceReq(BaseModel):
    symbol: str = "BTCUSDT"
    interval: str = "4h"
    start: str = Field(default="2021-01-01")
    end: str | None = None
    dataset_id: str


@app.post("/internal/v1/data/binance", dependencies=[Depends(auth)])
def data_binance(r: BinanceReq):
    cli = BinanceClient()
    info = cli.symbol_info(r.symbol)                       # validates the pair exists and is TRADING
    df = cli.fetch_history(r.symbol, r.interval, pd.Timestamp(r.start, tz="UTC"), pd.Timestamp(r.end, tz="UTC") if r.end else None)
    df["symbol"] = info["symbol"]
    cols.save_dataset(df, config.DATASET_DIR / f"{r.dataset_id}.csv")
    rep = cols.validate(df.assign(timestamp=df["timestamp"].astype(str)), {c: c for c in df.columns})
    fr = freshness(df["timestamp"].iloc[-1], INTERVAL_SECONDS[r.interval])
    return _clean({"report": rep, "symbol_info": info, "freshness": fr,
                   "dataset": {"rows": len(df), "start": df["timestamp"].iloc[0], "end": df["timestamp"].iloc[-1],
                               "interval_seconds": INTERVAL_SECONDS[r.interval], "symbol": info["symbol"],
                               "overall_missing_pct": rep["overall_missing_pct"]}})


@app.get("/internal/v1/data/{dataset_id}/candles", dependencies=[Depends(auth)])
def dataset_candles(dataset_id: str, offset: int = 0, limit: int = Query(2000, le=20000), tail: int | None = None):
    df = _ds(dataset_id)
    d = df.iloc[-tail:] if tail else df.iloc[offset: offset + limit]
    d = d.copy(); d["timestamp"] = d["timestamp"].dt.strftime("%Y-%m-%dT%H:%M:%SZ")
    return {"total": len(df), "candles": _clean(d.to_dict("records"))}


class FeatReq(BaseModel):
    dataset_id: str
    tail: int = 500
    selected: list[str] | None = None


@app.post("/internal/v1/data/features", dependencies=[Depends(auth)])
def data_features(r: FeatReq):
    df = _ds(r.dataset_id); f = compute_features(df)
    sel = [c for c in (r.selected or (MODEL_FEATURES + CHART_COLUMNS)) if c in f.columns]
    return {"available_model_features": MODEL_FEATURES, "chart_columns": CHART_COLUMNS, "rows": _frame_rows(f[sel], r.tail, df["timestamp"])}


# ---------------------------------------------------------------- market (live)
@app.get("/internal/v1/market/overview", dependencies=[Depends(auth)])
def market_overview(symbols: str = ",".join(config.DEFAULT_SYMBOLS)):
    syms = [normalize_symbol(s) for s in symbols.split(",")]
    out, missing = {}, []
    for s in syms:
        d = feed.get(s)
        if d: out[s] = {**d, "source": "websocket"}
        else: missing.append(s)
    if missing:
        for k, v in BinanceClient().ticker_24h(missing).items(): out[k] = {**v, "source": "rest"}
    return _clean(out)


@app.get("/internal/v1/market/{symbol}/candles", dependencies=[Depends(auth)])
def market_candles(symbol: str, interval: str = "4h", limit: int = Query(500, le=1000)):
    cli = BinanceClient()
    rows = cli._to_df(cli.klines(symbol, interval, limit=limit), int(time.time() * 1000))
    rows["timestamp"] = rows["timestamp"].dt.strftime("%Y-%m-%dT%H:%M:%SZ")
    return {"symbol": normalize_symbol(symbol), "interval": interval, "candles": _clean(rows.to_dict("records"))}


@app.get("/internal/v1/market/{symbol}/info", dependencies=[Depends(auth)])
def market_info(symbol: str):
    cli = BinanceClient(); i = cli.symbol_info(symbol)
    try: i["spread_bps"] = cli.book_ticker(symbol)["spread_bps"]
    except BinanceError: pass
    return i


@app.get("/internal/v1/market/{symbol}/book", dependencies=[Depends(auth)])
def market_book(symbol: str): return BinanceClient().book_ticker(symbol)


# ---------------------------------------------------------------- regime / train / predict
class RegimeReq(BaseModel):
    dataset_id: str
    model_id: str
    tail: int = 300


@app.post("/internal/v1/regime/predict", dependencies=[Depends(auth)])
def regime_predict(r: RegimeReq):
    df, b = _ds(r.dataset_id), None
    b = get_bundle(r.model_id)
    proba = b.hmm.filtered_proba(compute_features(df))
    return _clean({"summary": b.hmm.summary(proba), "transition_matrix": b.hmm.transition_matrix().tolist(),
                   "state_means": b.hmm.fit_info.get("state_means"), "rows": _frame_rows(proba, r.tail, df["timestamp"])})


class TrainReq(BaseModel):
    dataset_id: str
    symbol: str
    config: dict[str, Any] = {}


@app.post("/internal/v1/train", dependencies=[Depends(auth)])
def train(r: TrainReq):
    df = _ds(r.dataset_id)
    meta = train_models(df, r.dataset_id, normalize_symbol(r.symbol), r.config)
    get_bundle.cache_clear()
    return _clean(meta)


class PredictReq(BaseModel):
    dataset_id: str
    model_id: str
    historical_mode: bool = True      # uploaded datasets: skip live freshness check


@app.post("/internal/v1/predict", dependencies=[Depends(auth)])
def predict(r: PredictReq):
    df = _ds(r.dataset_id); b = get_bundle(r.model_id)
    feat, proba, preds = b.run(df)
    t = len(df) - 1
    interval = b.meta["interval_seconds"]
    fr = freshness(df["timestamp"].iloc[-1], interval)
    outs, unavailable = [], [e for e in EXPERTS if e not in preds]
    for e, byh in preds.items():
        for h, frame in byh.items():
            row = frame.iloc[t]
            outs.append({"expert": e, "horizon": h, "asof": df["timestamp"].iloc[t].isoformat(),
                         "target_end": (df["timestamp"].iloc[t] + pd.Timedelta(seconds=interval * b.meta["horizons"][h])).isoformat(),
                         "pred": row["pred"], "prob_pos": row["prob_pos"], "sigma": row["sigma"], "model_version": r.model_id,
                         "scale": rg.vol_scale(feat["roll_std_50"].iloc[t], b.meta["horizons"][h], b.meta["scale"][h])})
    return _clean({"asset": b.meta["symbol"], "asof": df["timestamp"].iloc[t].isoformat(), "last_close": df["close"].iloc[t],
                   "interval_seconds": interval, "horizons": b.meta["horizons"], "regime_probs": proba.iloc[t].to_dict(),
                   "regime_summary": b.hmm.summary(proba), "expert_outputs": outs, "unavailable_experts": unavailable,
                   "freshness": {**fr, "stale": False if r.historical_mode else fr["stale"], "historical_mode": r.historical_mode},
                   "periods_per_year": 365 * 86400 / interval, "model_version": r.model_id,
                   "recent_returns": (np.log(df["close"]).diff().dropna().iloc[-250:]).tolist()})


class RagateReq(BaseModel):
    dataset_id: str
    model_id: str | None = None
    horizon: str
    pending: list[dict] = []
    state: dict = {}
    expert_outputs: list[dict]
    regime_probs: dict[str, float]
    config: dict = {}
    compat: dict | None = None
    scale: dict | None = None
    ref_loss: dict | None = None
    uncertainty_scale: dict | None = None


@app.post("/internal/v1/ragate/evaluate", dependencies=[Depends(auth)])
def ragate_evaluate(r: RagateReq):
    df = _ds(r.dataset_id)
    meta = get_bundle(r.model_id).meta if r.model_id else {}
    close = pd.Series(df["close"].values, index=df["timestamp"])
    return _clean(rg.evaluate(r.model_dump(), close, meta))


class RiskReq(BaseModel):
    asset: str
    horizon_candles: int
    periods_per_year: float
    ragate: dict                      # output of /ragate/evaluate
    regime_probs: dict[str, float]
    current_weight: float = 0.0
    cash_fraction: float = 1.0
    spread_bps: float | None = None
    returns: dict[str, list[float]] | None = None
    other_weights: dict[str, float] | None = None
    data_stale: bool = False
    risk_config: dict = {}
    decision_config: dict = {}


@app.post("/internal/v1/risk/evaluate", dependencies=[Depends(auth)])
def risk_evaluate(r: RiskReq):
    comb = r.ragate.get("combined")
    risk = None
    if comb:
        risk = evaluate_risk({"asset": r.asset, "combined_return": comb["combined_return"], "sigma_total": comb["sigma_total"],
                              "disagreement": comb["disagreement"], "regime_probs": r.regime_probs, "horizon_candles": r.horizon_candles,
                              "periods_per_year": r.periods_per_year, "current_weight": r.current_weight, "cash_fraction": r.cash_fraction,
                              "spread_bps": r.spread_bps, "returns": r.returns, "other_weights": r.other_weights or {},
                              "config": r.risk_config})
    dec = decide(r.ragate, risk, r.current_weight, r.regime_probs, r.data_stale, DecisionConfig(**r.decision_config))
    return _clean({"risk": risk, "decision": dec})


class BacktestReq(BaseModel):
    assets: list[dict]                 # [{dataset_id, model_id}]
    start: str | None = None
    end: str | None = None
    initial_capital: float = 10000
    horizon: str = "1d"
    costs: dict = {}
    risk: dict = {}
    decision: dict = {}
    ragate: dict = {}
    allow_in_sample: bool = False


@app.post("/internal/v1/backtest", dependencies=[Depends(auth)])
def backtest(r: BacktestReq):
    return _clean(run_backtest(r.model_dump()))


@app.get("/internal/v1/models", dependencies=[Depends(auth)])
def models(): return _clean(list_models())


@app.get("/internal/v1/models/{model_id}", dependencies=[Depends(auth)])
def model_detail(model_id: str): return _clean(get_bundle(model_id).meta)
