"""RAGATE: Reliability-Aware Gating And Adaptive Trading Exposure - reliability/gating part.

Pure functions + JSON-serialisable state (state is persisted by the caller, e.g. PostgreSQL).
  * forecasts are scored ONCE, only after their target candle exists (matured)
  * EWMA of normalised forecast loss  -> recent reliability
  * one-sided CUSUM on excess loss    -> persistent deterioration flag (flag only; never auto-replaces a model)
  * regime-expert compatibility (from validation data) x current regime probabilities
  * softmax weights over available experts (non-negative, sum to 1)
"""
from __future__ import annotations
from dataclasses import dataclass, asdict
import numpy as np
import pandas as pd
from scipy.stats import norm

REGIMES = ["bull", "range", "stress"]


@dataclass
class RagateConfig:
    ewma_lambda: float = 0.9      # decay: weight on history
    prior_n: float = 10.0         # shrinkage toward neutral loss while few matured forecasts exist
    cusum_k: float = 0.5          # allowance (in normalised-loss units)
    cusum_h: float = 5.0          # alarm threshold
    beta_compat: float = 3.0
    beta_loss: float = 1.0
    beta_cusum: float = 2.0
    temperature: float = 1.0
    regime_unc_gamma: float = 0.5
    loss_clip: float = 10.0
    neutral_loss: float = 1.0     # expected normalised loss of a zero forecast


def forecast_loss(pred: float, actual: float, scale: float, clip: float = 10.0) -> float:
    z = (pred - actual) / max(scale, 1e-12)
    return float(min(z * z, clip))


def _ts(x) -> pd.Timestamp:
    t = pd.Timestamp(x)
    return t.tz_localize("UTC") if t.tzinfo is None else t.tz_convert("UTC")


def vol_scale(roll_std: float, h: int, fallback: float) -> float:
    """Forecast-time loss scale: contemporaneous volatility x sqrt(horizon), floored so calm periods do not explode losses.
    Normalising by volatility known AT forecast time stops a pure volatility shift from looking like model deterioration."""
    if roll_std is None or not np.isfinite(roll_std) or roll_std <= 0: return fallback
    return float(max(roll_std * np.sqrt(h), 0.25 * fallback))


def key(expert: str, horizon: str) -> str: return f"{expert}|{horizon}"


def mature_forecasts(pending: list[dict], close: pd.Series) -> tuple[list[dict], list[dict]]:
    """Return (matured_with_actuals, still_pending). A forecast matures when its target candle exists in `close`.
    Timestamps are candle OPEN times; return = ln(close[target]/close[asof])."""
    matured, rest = [], []
    for f in pending:
        if f.get("scored"): continue
        a, t = _ts(f["asof"]), _ts(f["target_end"])
        if t in close.index and a in close.index:
            g = dict(f); g["actual_return"] = float(np.log(close.loc[t] / close.loc[a])); matured.append(g)
        else:
            rest.append(f)
    return matured, rest


def score_matured(state: dict, matured: list[dict], scale: dict, ref_loss: dict, cfg: RagateConfig) -> tuple[dict, list[dict]]:
    state = {k: dict(v) for k, v in (state or {}).items()}
    seen, scored = set(), []
    for f in sorted(matured, key=lambda x: x["target_end"]):
        fid = f.get("id") or f"{f['expert']}|{f['horizon']}|{f['asof']}"
        if fid in seen or f.get("scored"): continue   # each forecast is scored exactly once
        seen.add(fid)
        k = key(f["expert"], f["horizon"])
        s = state.setdefault(k, {"ewma": None, "n": 0, "cusum": 0.0, "flagged": False, "last_scored_target": None})
        loss = forecast_loss(f["predicted_return"], f["actual_return"], f.get("scale") or scale.get(f["horizon"], 1.0), cfg.loss_clip)
        s["ewma"] = loss if s["ewma"] is None else cfg.ewma_lambda * s["ewma"] + (1 - cfg.ewma_lambda) * loss
        ref = ref_loss.get(k, cfg.neutral_loss)
        s["cusum"] = max(0.0, s["cusum"] + (loss - ref) - cfg.cusum_k)
        s["flagged"] = bool(s["cusum"] >= cfg.cusum_h)
        s["n"] += 1; s["last_scored_target"] = f["target_end"]
        scored.append({**f, "loss": loss, "id": fid})
    return state, scored


def _softmax(x, t):
    z = np.asarray(x, float) / max(t, 1e-9); z -= z.max(); e = np.exp(z); return e / e.sum()


def compute_weights(experts: list[str], state: dict, horizon: str, regime_probs: dict, compat: dict,
                    cfg: RagateConfig) -> tuple[dict, dict]:
    if not experts: return {}, {}
    p = np.array([regime_probs.get(r, 0.0) for r in REGIMES]); p = p / p.sum() if p.sum() > 0 else np.ones(3) / 3
    rows = {}
    for e in experts:
        s = (state or {}).get(key(e, horizon), {})
        n, ew = s.get("n", 0), s.get("ewma")
        c = compat.get(e, {}).get(horizon, {})
        comp = float(sum(p[i] * c.get(r, c.get("overall", 0.5)) for i, r in enumerate(REGIMES)))
        L = cfg.neutral_loss if not n else (n * ew + cfg.prior_n * cfg.neutral_loss) / (n + cfg.prior_n)
        D = min(s.get("cusum", 0.0) / cfg.cusum_h, 2.0)
        rows[e] = {"compat": comp, "loss_eff": float(L), "n_matured": int(n), "cusum": float(s.get("cusum", 0.0)),
                   "deterioration": float(D), "flagged": bool(s.get("flagged", False)),
                   "terms": {"compat": cfg.beta_compat * comp, "loss": -cfg.beta_loss * L, "cusum": -cfg.beta_cusum * D}}
        rows[e]["logit"] = sum(rows[e]["terms"].values())
    w = _softmax([rows[e]["logit"] for e in experts], cfg.temperature)
    for e, wi in zip(experts, w): rows[e]["weight"] = float(wi)
    for e in experts:   # human-readable explanation: what moved this expert vs. the average
        diffs = {t: rows[e]["terms"][t] - np.mean([rows[x]["terms"][t] for x in experts]) for t in ("compat", "loss", "cusum")}
        name = {"compat": "regime compatibility", "loss": "recent forecast accuracy", "cusum": "CUSUM deterioration"}
        top = max(diffs, key=lambda t: abs(diffs[t]))
        if len(experts) == 1: rows[e]["why"] = "Only available expert: weight 100%."
        elif abs(diffs[top]) < 1e-3: rows[e]["why"] = "Near-average on every reliability factor."
        else: rows[e]["why"] = f"{'Boosted' if diffs[top] > 0 else 'Reduced'} mainly by {name[top]}." + \
                               (" CUSUM flagged persistent deterioration." if rows[e]["flagged"] else "") + \
                               (f" Only {rows[e]['n_matured']} matured forecasts: loss shrunk toward neutral." if rows[e]["n_matured"] < cfg.prior_n else "")
    return {e: rows[e]["weight"] for e in experts}, rows


def combine(outputs: dict[str, dict], weights: dict, regime_probs: dict, cfg: RagateConfig, unc_scale: float = 1.0) -> dict:
    es = [e for e in weights if e in outputs]
    w = np.array([weights[e] for e in es]); mu = np.array([outputs[e]["pred"] for e in es])
    sg = np.array([outputs[e]["sigma"] for e in es])
    mc = float(w @ mu)
    dis = float(np.sqrt(w @ (mu - mc) ** 2))
    within = float(w @ sg ** 2)
    p = np.array([regime_probs.get(r, 0) for r in REGIMES]); p = p[p > 0]
    hn = float(-(p * np.log(p)).sum() / np.log(3)) if len(p) else 1.0
    sigma = float(unc_scale * np.sqrt(within + dis ** 2) * (1 + cfg.regime_unc_gamma * hn))
    return {"combined_return": mc, "disagreement": dis, "within_variance": within, "regime_entropy": hn,
            "sigma_total": sigma, "prob_positive": float(norm.cdf(mc / max(sigma, 1e-12)))}


def calibrate_uncertainty(sigma_pred: np.ndarray, errors: np.ndarray) -> float:
    """Scale factor s.t. mean squared standardised error ~ 1 on held-out (validation) data."""
    m = np.isfinite(sigma_pred) & np.isfinite(errors)
    if m.sum() < 30: return 1.0
    return float(np.clip(np.sqrt(np.mean(errors[m] ** 2) / np.mean(sigma_pred[m] ** 2)), 0.5, 3.0))


def evaluate(req: dict, close: pd.Series, meta: dict | None = None) -> dict:
    """Full RAGATE step for one asset/horizon. `meta` supplies compat/scale/ref_loss/uncertainty_scale if absent in req."""
    meta = meta or {}
    cfg = RagateConfig(**req.get("config", {}))
    horizon = req["horizon"]
    scale = req.get("scale") or meta.get("scale", {})
    ref = req.get("ref_loss") or meta.get("ref_loss", {})
    compat = req.get("compat") or meta.get("compat", {})
    unc = (req.get("uncertainty_scale") or meta.get("uncertainty_scale", {})).get(horizon, 1.0)
    matured, still = mature_forecasts(req.get("pending", []), close)
    state, scored = score_matured(req.get("state", {}), matured, scale, ref, cfg)
    outs = {o["expert"]: o for o in req.get("expert_outputs", []) if o.get("pred") is not None and np.isfinite(o["pred"])}
    unavailable = [o["expert"] for o in req.get("expert_outputs", []) if o["expert"] not in outs]
    rp = req["regime_probs"]
    if not outs:
        return {"status": "no_experts", "weights": {}, "details": {}, "state": state, "scored": scored,
                "unavailable": unavailable, "config": asdict(cfg), "combined": None}
    w, details = compute_weights(list(outs), state, horizon, rp, compat, cfg)
    comb = combine(outs, w, rp, cfg, unc)
    flagged = [e for e, d in details.items() if d["flagged"]]
    return {"status": "ok", "weights": w, "details": details, "combined": comb, "state": state, "scored": scored,
            "n_pending": len(still), "flagged_experts": flagged, "unavailable": unavailable,
            "all_flagged": len(flagged) == len(outs), "config": asdict(cfg)}
