"""3-state Gaussian HMM (bull / range / stress) with causal *filtered* probabilities (forward algorithm)."""
from __future__ import annotations
import numpy as np
import pandas as pd
from scipy.special import logsumexp
from scipy.stats import multivariate_normal
from hmmlearn.hmm import GaussianHMM

REGIMES = ["bull", "range", "stress"]
HMM_FEATURES = ["logret_1", "roll_std_20", "rel_volume"]


def _obs(feat: pd.DataFrame) -> pd.DataFrame:
    x = feat[HMM_FEATURES].copy()
    x["rel_volume"] = np.log(x["rel_volume"].clip(lower=1e-3))
    return x


class RegimeModel:
    def __init__(self, seed: int = 42, n_restarts: int = 5):
        self.seed, self.n_restarts = seed, n_restarts
        self.hmm: GaussianHMM | None = None
        self.mu = self.sd = None
        self.order: list[int] = []  # order[i] = hidden state index for REGIMES[i]
        self.fit_info: dict = {}

    def fit(self, feat_train: pd.DataFrame) -> "RegimeModel":
        x = _obs(feat_train).dropna()
        if len(x) < 200: raise ValueError("Need at least 200 clean training rows to fit the HMM")
        self.mu, self.sd = x.mean().values, x.std().replace(0, 1).values
        z = ((x.values - self.mu) / self.sd)
        best, best_ll = None, -np.inf
        for k in range(self.n_restarts):
            m = GaussianHMM(3, covariance_type="full", n_iter=200, tol=1e-4, min_covar=1e-3, random_state=self.seed + k)
            try:
                m.fit(z); ll = m.score(z)
            except Exception:
                continue
            if ll > best_ll: best, best_ll = m, ll
        if best is None: raise RuntimeError("HMM failed to converge")
        self.hmm = best
        means = best.means_ * self.sd + self.mu  # back to natural units
        stress = int(np.argmax(means[:, 1]))     # highest volatility
        rest = [i for i in range(3) if i != stress]
        bull = max(rest, key=lambda i: means[i, 0])  # highest mean return of the others
        rng = [i for i in rest if i != bull][0]
        self.order = [bull, rng, stress]
        self.fit_info = {"train_loglik": float(best_ll), "n_train": int(len(z)),
                         "state_means": {REGIMES[i]: dict(zip(HMM_FEATURES, map(float, means[s]))) for i, s in enumerate(self.order)},
                         "transition_matrix": self.transition_matrix().tolist()}
        return self

    def transition_matrix(self) -> np.ndarray:
        A = self.hmm.transmat_
        return A[np.ix_(self.order, self.order)]

    def filtered_proba(self, feat: pd.DataFrame) -> pd.DataFrame:
        """Causal P(regime_t | observations_<=t). Rows with NaN features are NaN until the first valid row."""
        x = _obs(feat)
        valid = x.notna().all(axis=1).values
        out = np.full((len(x), 3), np.nan)
        if not valid.any(): return pd.DataFrame(out, index=feat.index, columns=REGIMES)
        z = (x.values - self.mu) / self.sd
        K, h = 3, self.hmm
        logb = np.full((len(x), K), np.nan)
        for k in range(K):
            cov = h.covars_[k] if h.covariance_type == "full" else np.diag(h.covars_[k])
            logb[valid, k] = multivariate_normal(h.means_[k], cov, allow_singular=True).logpdf(z[valid])
        logA, logpi = np.log(np.clip(h.transmat_, 1e-12, None)), np.log(np.clip(h.startprob_, 1e-12, None))
        la = None
        for t in np.where(valid)[0]:
            prior = logpi if la is None else logsumexp(la[:, None] + logA, axis=0)
            la = prior + logb[t]
            la = la - logsumexp(la)
            out[t] = np.exp(la)
        return pd.DataFrame(out[:, self.order], index=feat.index, columns=REGIMES)

    @staticmethod
    def summary(proba: pd.DataFrame, tail: int = 200) -> dict:
        p = proba.dropna()
        if p.empty: return {}
        lab = p.idxmax(axis=1)
        changes = lab != lab.shift()
        run = int((lab.iloc[::-1] == lab.iloc[-1]).cumprod().sum())
        recent = lab.iloc[-tail:]
        trans = [{"timestamp": str(i), "from": str(lab.shift().loc[i]), "to": str(lab.loc[i])}
                 for i in lab.index[changes][1:][-25:]]
        return {"current": p.iloc[-1].to_dict(), "current_label": str(lab.iloc[-1]), "run_length": run,
                "changes_last_window": int((recent != recent.shift()).sum() - 1),
                "stability": float(1 - (recent != recent.shift()).sum() / max(len(recent), 1)),
                "recent_transitions": trans}
