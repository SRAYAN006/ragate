"""Independent risk engine: costs, adaptive exposure cap, mean-variance sizing, portfolio-vol limit. Can veto a signal."""
from __future__ import annotations
from dataclasses import dataclass
import numpy as np


@dataclass
class RiskConfig:
    fee_rate: float = 0.001          # per side
    slippage_bps: float = 5.0        # per side
    default_spread_bps: float = 2.0
    max_asset_exposure: float = 0.6  # fraction of equity
    max_portfolio_vol: float = 0.9   # annualised
    risk_aversion: float = 3.0
    min_net_return: float = 0.0
    min_snr: float = 0.15            # net return / total sigma
    stress_block: float = 0.6        # block new entries above this stress probability
    min_trade_weight: float = 0.02


def _cov(returns: dict | None, asset: str, sigma_per_period: float):
    if returns and len(returns) >= 2:
        n = min(len(v) for v in returns.values())
        if n >= 30:
            from sklearn.covariance import LedoitWolf
            names = list(returns)
            M = np.array([returns[a][-n:] for a in names]).T
            return names, LedoitWolf().fit(M).covariance_
    return [asset], np.array([[sigma_per_period ** 2]])


def evaluate_risk(inp: dict, cfg: RiskConfig | None = None) -> dict:
    cfg = cfg or RiskConfig(**inp.get("config", {}))
    mu, sig, dis = inp["combined_return"], max(inp["sigma_total"], 1e-9), inp.get("disagreement", 0.0)
    rp = inp["regime_probs"]; stress = rp.get("stress", 0.0)
    h, ppy = max(inp["horizon_candles"], 1), inp["periods_per_year"]
    spread = inp.get("spread_bps") or cfg.default_spread_bps
    one_way = cfg.fee_rate + cfg.slippage_bps / 1e4 + spread / 2e4
    net_entry, net_hold = mu - 2 * one_way, mu - one_way
    cw, cash = inp.get("current_weight", 0.0), inp.get("cash_fraction", 1.0)
    snr = net_entry / sig
    f_stress = max(0.0, 1 - stress)
    f_snr = float(np.clip(snr / 2.0, 0, 1))
    f_dis = 1 - 0.5 * float(np.clip(dis / sig, 0, 1))
    cap = cfg.max_asset_exposure * f_stress * f_snr * f_dis
    w_mv = max(0.0, net_entry / (cfg.risk_aversion * sig ** 2))
    avail = min(cfg.max_asset_exposure, cw + cash)
    target = float(min(w_mv, cap, avail))
    names, cov = _cov(inp.get("returns"), inp["asset"], sig / np.sqrt(h))
    wv = np.array([target if n == inp["asset"] else inp.get("other_weights", {}).get(n, 0.0) for n in names])
    pvol = float(np.sqrt(max(wv @ cov @ wv, 0)) * np.sqrt(ppy))
    if pvol > cfg.max_portfolio_vol and pvol > 0:
        target *= cfg.max_portfolio_vol / pvol; pvol = cfg.max_portfolio_vol
    checks = [
        {"name": "net_return_after_costs", "passed": net_entry > cfg.min_net_return, "value": net_entry, "limit": cfg.min_net_return},
        {"name": "signal_to_noise", "passed": snr >= cfg.min_snr, "value": snr, "limit": cfg.min_snr},
        {"name": "stress_probability", "passed": stress < cfg.stress_block, "value": stress, "limit": cfg.stress_block},
        {"name": "capacity", "passed": target >= cfg.min_trade_weight, "value": target, "limit": cfg.min_trade_weight},
    ]
    failed = [c["name"] for c in checks if not c["passed"]]
    return {"allowed_entry": not failed, "failed_checks": failed, "checks": checks, "net_return_entry": net_entry,
            "net_return_hold": net_hold, "round_trip_cost": 2 * one_way, "exposure_cap": float(cap),
            "cap_factors": {"stress": f_stress, "signal_to_noise": f_snr, "disagreement": f_dis},
            "target_weight": float(target if not failed else min(target, cw) if cw > 0 else 0.0),
            "mean_variance_weight": float(w_mv), "portfolio_vol_annual": pvol, "snr": snr, "config": cfg.__dict__}
