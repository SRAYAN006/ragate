"""ModelBundle: loads every artifact of a trained model_id and produces expert predictions for all rows (causal)."""
from __future__ import annotations
import json
from functools import lru_cache
import pandas as pd
from .. import config
from ..features.engineering import compute_features
from ..regime.hmm import RegimeModel
from ..experts.xgb_expert import XGBExpert
from ..experts.mean_reversion import MeanReversionExpert
from ..experts.rcte import RCTEExpert

EXPERTS = ["rcte", "xgboost", "mean_reversion"]


class ModelBundle:
    def __init__(self, model_id: str):
        self.dir = config.MODEL_DIR / model_id
        if not self.dir.exists(): raise FileNotFoundError(f"Unknown model_id '{model_id}'")
        self.model_id = model_id
        self.meta = json.loads((self.dir / "meta.json").read_text())
        self.hmm = __import__("joblib").load(self.dir / "hmm.joblib")
        self.experts: dict = {}
        for name, cls in (("xgboost", XGBExpert), ("mean_reversion", MeanReversionExpert), ("rcte", RCTEExpert)):
            try: self.experts[name] = cls.load(self.dir)
            except Exception: pass     # unavailable expert: handled safely downstream

    def run(self, df: pd.DataFrame):
        feat = compute_features(df)
        proba = self.hmm.filtered_proba(feat)
        preds: dict = {}
        if "xgboost" in self.experts: preds["xgboost"] = self.experts["xgboost"].predict(feat)
        if "mean_reversion" in self.experts: preds["mean_reversion"] = self.experts["mean_reversion"].predict(df, feat)
        if "rcte" in self.experts: preds["rcte"] = self.experts["rcte"].predict(feat, proba.fillna(0.0).where(proba.notna().all(axis=1), other=float("nan")))
        return feat, proba, preds


@lru_cache(maxsize=8)
def get_bundle(model_id: str) -> ModelBundle:
    return ModelBundle(model_id)


def list_models() -> list[dict]:
    out = []
    for d in sorted(config.MODEL_DIR.glob("*/meta.json")):
        m = json.loads(d.read_text())
        out.append({k: m.get(k) for k in ("model_id", "dataset_id", "symbol", "interval", "trained_at", "horizons", "splits", "experts_available")} |
                   {"test_metrics": m.get("metrics", {}).get("test")})
    return out
