"""Chronological training pipeline with purged splits. Test period is never used for fitting or model selection."""
from __future__ import annotations
import json, time
import numpy as np
import pandas as pd
import joblib
from .. import config
from ..data.columns import infer_interval_seconds
from ..features.engineering import compute_features, make_targets, horizons_for, MODEL_FEATURES
from ..regime.hmm import RegimeModel, REGIMES
from ..experts.xgb_expert import XGBExpert
from ..experts.mean_reversion import MeanReversionExpert
from ..experts.rcte import RCTEExpert, valid_end_positions
from ..experts.common import classification_metrics
from ..ragate.engine import forecast_loss, calibrate_uncertainty, combine, RagateConfig, vol_scale


def split_positions(start: int, n: int, train_frac=0.70, val_frac=0.15) -> dict:
    a = start + int((n - start) * train_frac); b = start + int((n - start) * (train_frac + val_frac))
    return {"start": start, "train_end": a, "val_end": b, "n": n}


def _expert_frames(preds: dict, horizon: str, idx) -> dict:
    return {e: p[horizon].iloc[idx] for e, p in preds.items()}


def train_models(df: pd.DataFrame, dataset_id: str, symbol: str, cfg: dict | None = None, seed: int = config.SEED) -> dict:
    cfg = cfg or {}
    t0 = time.time()
    interval = infer_interval_seconds(df["timestamp"])
    hz = horizons_for(interval); hmax = max(hz.values())
    feats_sel = [f for f in (cfg.get("features") or MODEL_FEATURES) if f in MODEL_FEATURES]
    feat = compute_features(df)
    if "volume" not in df:
        feats_sel = [f for f in feats_sel if f not in ("vol_change", "rel_volume")]
    Y = make_targets(df["close"], hz)
    first_valid = int(feat[feats_sel].notna().all(axis=1).values.argmax())
    seq_len = int(cfg.get("seq_len", 48))
    start = first_valid + seq_len
    sp = split_positions(start, len(df), cfg.get("train_frac", 0.70), cfg.get("val_frac", 0.15))
    a, b = sp["train_end"], sp["val_end"]
    if a - start < 600 or b - a < 150:
        raise ValueError(f"Dataset too short: {len(df)} candles gives {a-start} training / {b-a} validation rows. "
                         "Need roughly >= 1500 candles (e.g. ~250 days of 4h data).")
    tr_idx = np.arange(start, a - hmax)            # purged: targets end before validation begins
    va_idx = np.arange(a, b - hmax)                # purged: targets end before test begins
    te_idx = np.arange(b, len(df))

    hmm = RegimeModel(seed).fit(feat.iloc[:a][["logret_1", "roll_std_20", "rel_volume"]])   # TRAIN ONLY
    proba = hmm.filtered_proba(feat)
    Rfill = proba.copy()
    X_tr, X_va = feat[feats_sel].iloc[tr_idx], feat[feats_sel].iloc[va_idx]

    d = config.MODEL_DIR / f"{symbol}_{int(interval)}s_{time.strftime('%Y%m%d-%H%M%S')}"
    d.mkdir(parents=True)
    xgb = XGBExpert(feats_sel, hz, seed).fit(X_tr, Y.iloc[tr_idx], X_va, Y.iloc[va_idx]); xgb.save(d)
    Y_mr = Y.iloc[:a].copy(); Y_mr.iloc[a - hmax:] = np.nan       # purge targets that reach into validation
    mr = MeanReversionExpert(hz).fit(df.iloc[:a], feat.iloc[:a], Y_mr); mr.save(d)
    rc_cfg = cfg.get("rcte", {})
    rcte = RCTEExpert(feats_sel, hz, seq_len, rc_cfg.get("fusion", "film"), epochs=rc_cfg.get("epochs", 40),
                      d_model=rc_cfg.get("d_model", 48), layers=rc_cfg.get("layers", 2), seed=seed)
    rcte.fit(feat, Rfill, Y, tr_idx, va_idx); rcte.save(d)
    joblib.dump(hmm, d / "hmm.joblib")

    preds = {"xgboost": xgb.predict(feat), "mean_reversion": mr.predict(df, feat), "rcte": rcte.predict(feat, Rfill)}
    ystd = {h: float(Y[h].iloc[tr_idx].std()) for h in hz}
    sc = {h: np.array([vol_scale(v, hz[h], ystd[h]) for v in feat['roll_std_50'].values]) for h in hz}   # per-row loss scale
    metrics, compat, ref_loss, unc_scale = {"val": {}, "test": {}}, {}, {}, {}
    hard = proba.iloc[va_idx].idxmax(axis=1)
    for e, p in preds.items():
        compat[e] = {}
        for h in hz:
            for name, idx in (("val", va_idx), ("test", te_idx)):
                metrics[name].setdefault(e, {})[h] = classification_metrics(Y[h].iloc[idx].values, p[h]["pred"].iloc[idx].values)
            pv, yv = p[h]["pred"].iloc[va_idx], Y[h].iloc[va_idx]
            L = pd.Series([forecast_loss(x, y, sc[h][i]) if np.isfinite(x) and np.isfinite(y) else np.nan for i, x, y in zip(va_idx, pv, yv)], index=pv.index)
            overall = float(L.mean()) if L.notna().any() else 1.0
            # CUSUM reference: validation loss is optimistic (used for early stopping), so floor it near the no-skill level (~1.0)
            ref_loss[f"{e}|{h}"] = max(overall, 0.8)
            compat[e][h] = {"overall": float(np.exp(-overall))}
            for r in REGIMES:   # regime-conditional skill, validation data only
                m = (hard == r).values & L.notna().values
                compat[e][h][r] = float(np.exp(-L[m].mean())) if m.sum() >= 20 else compat[e][h]["overall"]
    for h in hz:   # calibrate uncertainty on validation with a static equal-weight combination
        sig, err = [], []
        for i in va_idx:
            o = {e: {"pred": preds[e][h]["pred"].iloc[i], "sigma": preds[e][h]["sigma"].iloc[i]} for e in preds}
            if not all(np.isfinite(v["pred"]) for v in o.values()) or not np.isfinite(Y[h].iloc[i]) or proba.iloc[i].isna().any(): continue
            c = combine(o, {e: 1 / 3 for e in o}, proba.iloc[i].to_dict(), RagateConfig())
            sig.append(c["sigma_total"]); err.append(Y[h].iloc[i] - c["combined_return"])
        unc_scale[h] = calibrate_uncertainty(np.array(sig), np.array(err))

    fusion_cmp = {}
    if cfg.get("compare_fusion"):
        for fz in ("film", "concat", "add", "none"):
            e = rcte if fz == rc_cfg.get("fusion", "film") else RCTEExpert(feats_sel, hz, seq_len, fz, epochs=rc_cfg.get("epochs", 40), seed=seed).fit(feat, Rfill, Y, tr_idx, va_idx)
            p = e.predict(feat, Rfill)
            fusion_cmp[fz] = {h: {k: classification_metrics(Y[h].iloc[va_idx].values, p[h]["pred"].iloc[va_idx].values)[k] for k in ("mae", "rmse", "directional_accuracy")} for h in hz}

    walk = walk_forward_xgb(df, feat, Y, feats_sel, hz, seed, cfg.get("walk_forward_folds", 0)) if cfg.get("walk_forward_folds") else None
    ts = df["timestamp"]
    meta = {"model_id": d.name, "dataset_id": dataset_id, "symbol": symbol, "interval": f"{int(interval)}s",
            "interval_seconds": interval, "trained_at": pd.Timestamp.now(tz="UTC").isoformat(), "features": feats_sel,
            "horizons": hz, "seq_len": seq_len, "seed": seed, "config": cfg, "experts_available": list(preds),
            "splits": {"train": [str(ts.iloc[start]), str(ts.iloc[a - 1])], "validation": [str(ts.iloc[a]), str(ts.iloc[b - 1])],
                       "test": [str(ts.iloc[b]), str(ts.iloc[-1])], "positions": sp, "purge_candles": hmax},
            "metrics": metrics, "compat": compat, "ref_loss": ref_loss, "scale": ystd, "uncertainty_scale": unc_scale,
            "feature_importance": {h: dict(list(v.items())[:15]) for h, v in xgb.importance.items()},
            "mean_reversion_params": mr.params, "hmm": hmm.fit_info, "rcte_history": rcte.history[-60:],
            "fusion_comparison": fusion_cmp, "walk_forward": walk, "train_seconds": round(time.time() - t0, 1)}
    (d / "meta.json").write_text(json.dumps(meta, indent=2, default=float))
    return meta


def walk_forward_xgb(df, feat, Y, feats, hz, seed, folds: int):
    """Expanding-window walk-forward for the (fast) XGBoost expert; reports forecast metrics per fold."""
    n = len(df); hmax = max(hz.values()); first = int(feat[feats].notna().all(axis=1).values.argmax())
    cut = np.linspace(first + int((n - first) * 0.5), n, folds + 1).astype(int); res = []
    for k in range(folds):
        tr_end, te_end = cut[k], cut[k + 1]
        tr = np.arange(first, tr_end - hmax); te = np.arange(tr_end, te_end)
        if len(tr) < 300 or len(te) < 30: continue
        sub_tr, sub_va = tr[: int(len(tr) * 0.85)], tr[int(len(tr) * 0.85):]
        m = XGBExpert(feats, hz, seed).fit(feat[feats].iloc[sub_tr], Y.iloc[sub_tr], feat[feats].iloc[sub_va], Y.iloc[sub_va])
        p = m.predict(feat.iloc[te])
        res.append({"fold": k + 1, "train_end": str(df['timestamp'].iloc[tr_end - 1]), "test_end": str(df['timestamp'].iloc[te_end - 1]),
                    "metrics": {h: classification_metrics(Y[h].iloc[te].values, p[h]["pred"].values) for h in hz}})
    return res
