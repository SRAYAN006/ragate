import sys, pathlib
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1]))
import os, tempfile
os.environ.setdefault("RAGATE_STORAGE", tempfile.mkdtemp(prefix="ragate_test_"))
os.environ["ENABLE_LIVE_WS"] = "false"
import numpy as np, pandas as pd, pytest


def synthetic_ohlcv(n=3200, interval="4h", seed=7, start="2022-01-01"):
    """TEST FIXTURE ONLY: regime-switching random walk with a weak mean-reverting component."""
    rng = np.random.default_rng(seed)
    mu = {0: 0.0006, 1: 0.0, 2: -0.0008}; sg = {0: 0.008, 1: 0.005, 2: 0.02}
    P = np.array([[0.985, 0.01, 0.005], [0.01, 0.985, 0.005], [0.02, 0.03, 0.95]])
    s, rets, prev = 1, [], 0.0
    for _ in range(n):
        s = rng.choice(3, p=P[s]); r = mu[s] + sg[s] * rng.standard_normal() - 0.08 * prev; prev = r; rets.append(r)
    close = 20000 * np.exp(np.cumsum(rets)); op = np.concatenate([[20000], close[:-1]])
    hi = np.maximum(op, close) * (1 + np.abs(rng.normal(0, 0.002, n))); lo = np.minimum(op, close) * (1 - np.abs(rng.normal(0, 0.002, n)))
    vol = rng.lognormal(5, 0.4, n) * (1 + 3 * np.abs(np.array(rets)) / 0.01)
    ts = pd.date_range(start, periods=n, freq=interval, tz="UTC")
    return pd.DataFrame({"timestamp": ts, "open": op, "high": hi, "low": lo, "close": close, "volume": vol})


@pytest.fixture(scope="session")
def ohlcv(): return synthetic_ohlcv()
