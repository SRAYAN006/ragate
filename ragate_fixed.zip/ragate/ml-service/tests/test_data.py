import numpy as np, pandas as pd, pytest
from app.data import columns as c
from app.data.binance import freshness
from conftest import synthetic_ohlcv


def test_detect_columns_variants():
    m = c.detect_columns(["Open Time", "Opening_Price", "Highest Price", "LOW", "closing_price", "Traded_Volume", "pair"])
    assert m["timestamp"] == "Open Time" and m["open"] == "Opening_Price" and m["high"] == "Highest Price"
    assert m["low"] == "LOW" and m["close"] == "closing_price" and m["volume"] == "Traded_Volume" and m["symbol"] == "pair"


def test_unsupported_dataset_is_rejected_with_message():
    rep = c.validate(pd.DataFrame({"age": [1, 2], "salary": [3, 4]}))
    assert rep["supported"] is False and "OHLCV" in rep["message"]


def test_validation_detects_problems(ohlcv):
    raw = ohlcv.iloc[:400].copy()
    raw = pd.concat([raw, raw.iloc[[5]]])                       # duplicate timestamp
    raw = raw.drop(raw.index[100:103])                          # 3 missing candles
    raw.loc[raw.index[10], "high"] = raw.loc[raw.index[10], "low"] * 0.5    # OHLC violation
    raw.loc[raw.index[20], "close"] = -1                        # non-positive
    raw["volume"] = raw["volume"].astype(object); raw.iloc[30, raw.columns.get_loc("volume")] = "abc"
    rep = c.validate(raw)
    assert rep["duplicate_timestamps"] == 1 and rep["missing_candles"] == 3
    assert rep["ohlc_violations"] >= 1 and rep["non_positive_prices"] == 1 and rep["non_numeric"]["volume"] == 1
    assert rep["status"] == "FAIL"


def test_clean_requires_explicit_choice_and_logs(ohlcv):
    raw = pd.concat([ohlcv.iloc[:300], ohlcv.iloc[[5]]])
    m = c.detect_columns(raw.columns)
    with pytest.raises(c.DataValidationError): c.clean(raw, m)
    df, log = c.clean(raw, m, {"duplicates": "keep_last"})
    assert len(df) == 300 and any(l["action"] == "dropped_duplicates_last" for l in log)


def test_fill_missing_candles_is_logged(ohlcv):
    raw = ohlcv.iloc[:300].drop(ohlcv.index[50:55])
    df, log = c.clean(raw, c.detect_columns(raw.columns), {"fill_missing_candles": True})
    assert len(df) == 300 and any(l["action"] == "filled_missing_candles_flat" and l["count"] == 5 for l in log)


def test_epoch_ms_timestamps(ohlcv):
    raw = ohlcv.iloc[:200].copy(); raw["timestamp"] = raw["timestamp"].astype("int64") // 10**6
    df, _ = c.clean(raw, c.detect_columns(raw.columns))
    assert df["timestamp"].iloc[0] == ohlcv["timestamp"].iloc[0]


def test_stale_data_detection():
    last = pd.Timestamp("2024-01-01", tz="UTC")
    assert freshness(last, 14400, now=last + pd.Timedelta(hours=5))["stale"] is False
    assert freshness(last, 14400, now=last + pd.Timedelta(days=2))["stale"] is True
