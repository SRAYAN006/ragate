import numpy as np, pandas as pd
from app.features.engineering import compute_features, horizons_for, make_targets, MODEL_FEATURES
from app.regime.hmm import RegimeModel


def test_horizons_for_4h():
    assert horizons_for(14400) == {"1d": 6, "3d": 18, "5d": 30}


def test_features_have_no_lookahead(ohlcv):
    full = compute_features(ohlcv)
    cut = compute_features(ohlcv.iloc[:2000])
    pd.testing.assert_frame_equal(full.iloc[:2000], cut, check_exact=False, rtol=1e-9, atol=1e-12)
    mod = ohlcv.copy(); mod.loc[2500:, ["open", "high", "low", "close"]] *= 3
    pd.testing.assert_frame_equal(compute_features(mod).iloc[:2500], full.iloc[:2500])


def test_feature_values(ohlcv):
    f = compute_features(ohlcv)
    assert f["rsi_14"].dropna().between(0, 100).all()
    assert set(MODEL_FEATURES) <= set(f.columns)
    v = f[["bb_upper", "bb_lower"]].dropna(); assert (v["bb_upper"] >= v["bb_lower"]).all()


def test_targets_use_future_only_at_label(ohlcv):
    y = make_targets(ohlcv["close"], {"1d": 6})
    assert np.isclose(y["1d"].iloc[10], np.log(ohlcv["close"].iloc[16] / ohlcv["close"].iloc[10]))
    assert y["1d"].iloc[-6:].isna().all()


def test_hmm_probabilities_and_causality(ohlcv):
    f = compute_features(ohlcv)
    m = RegimeModel(seed=1, n_restarts=2).fit(f.iloc[:2000][["logret_1", "roll_std_20", "rel_volume"]])
    p = m.filtered_proba(f).dropna()
    assert np.allclose(p.sum(axis=1), 1.0) and (p >= 0).all().all()
    p_cut = m.filtered_proba(f.iloc[:2500]).dropna()
    np.testing.assert_allclose(p.loc[p_cut.index].values, p_cut.values, atol=1e-9)    # filtered => causal
    means = m.fit_info["state_means"]
    assert means["stress"]["roll_std_20"] > means["bull"]["roll_std_20"] and means["stress"]["roll_std_20"] > means["range"]["roll_std_20"]
    assert m.summary(p)["current_label"] in ("bull", "range", "stress")
