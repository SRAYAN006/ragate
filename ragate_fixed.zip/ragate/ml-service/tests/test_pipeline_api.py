import numpy as np, pandas as pd, pytest
from fastapi.testclient import TestClient
from app import config
from app.data import columns as cols
from app.main import app
from app.training.pipeline import train_models
from app.training.bundle import get_bundle
from app.backtest.engine import run_backtest, STRATEGIES
from app.backtest.engine import portfolio_metrics, _strategy_returns

H = {"X-Internal-Key": config.INTERNAL_API_KEY}


@pytest.fixture(scope="module")
def trained(ohlcv):
    cols.save_dataset(ohlcv, config.DATASET_DIR / "ds1.csv")
    meta = train_models(ohlcv, "ds1", "BTCUSDT", {"rcte": {"epochs": 4}, "walk_forward_folds": 2})
    return meta


def test_training_is_chronological_and_leak_free(trained, ohlcv):
    s = trained["splits"]
    assert s["train"][1] < s["validation"][0] < s["validation"][1] < s["test"][0]
    pos = s["positions"]; assert pos["train_end"] < pos["val_end"] < pos["n"]
    assert set(trained["experts_available"]) == {"rcte", "xgboost", "mean_reversion"}
    for e in trained["experts_available"]:
        for h in ("1d", "3d", "5d"): assert trained["metrics"]["test"][e][h]["n"] > 100
    assert trained["walk_forward"] and trained["hmm"]["state_means"]
    assert abs(sum(trained["compat"]["xgboost"]["1d"][r] > 0 for r in ("bull", "range", "stress"))) == 3


def test_prediction_changes_only_with_past_data(trained, ohlcv):
    b = get_bundle(trained["model_id"])
    _, _, p_full = b.run(ohlcv)
    _, _, p_cut = b.run(ohlcv.iloc[:2800])
    for e in p_full:
        a, c = p_full[e]["1d"]["pred"].iloc[2799], p_cut[e]["1d"]["pred"].iloc[2799]
        assert np.isclose(a, c, atol=1e-5, equal_nan=True), e


def test_full_api_flow(trained, ohlcv):
    c = TestClient(app)
    assert c.get("/health").status_code == 200
    assert c.post("/internal/v1/predict", json={"dataset_id": "ds1", "model_id": trained["model_id"]}).status_code == 401
    r = c.post("/internal/v1/predict", headers=H, json={"dataset_id": "ds1", "model_id": trained["model_id"]}).json()
    assert len(r["expert_outputs"]) == 9 and abs(sum(r["regime_probs"].values()) - 1) < 1e-9
    one = [o for o in r["expert_outputs"] if o["horizon"] == "1d"]
    rg_req = {"dataset_id": "ds1", "model_id": trained["model_id"], "horizon": "1d", "expert_outputs": one, "regime_probs": r["regime_probs"],
              "pending": [], "state": {}}
    rg = c.post("/internal/v1/ragate/evaluate", headers=H, json=rg_req).json()
    assert rg["status"] == "ok" and abs(sum(rg["weights"].values()) - 1) < 1e-9
    rk = c.post("/internal/v1/risk/evaluate", headers=H, json={"asset": "BTCUSDT", "horizon_candles": 6, "periods_per_year": r["periods_per_year"],
                                                                "ragate": rg, "regime_probs": r["regime_probs"]}).json()
    assert rk["decision"]["action"] in ("BUY", "HOLD", "REDUCE", "EXIT", "ABSTAIN") and rk["decision"]["reasons"]
    # forecast maturity: use an old asof so the target exists in the dataset
    t = ohlcv["timestamp"].iloc[-40]; tgt = ohlcv["timestamp"].iloc[-34]
    pend = [{"id": "x1", "expert": "xgboost", "horizon": "1d", "asof": t.isoformat(), "target_end": tgt.isoformat(), "predicted_return": 0.01}]
    rg2 = c.post("/internal/v1/ragate/evaluate", headers=H, json={**rg_req, "pending": pend}).json()
    assert len(rg2["scored"]) == 1 and rg2["state"]["xgboost|1d"]["n"] == 1
    reg = c.post("/internal/v1/regime/predict", headers=H, json={"dataset_id": "ds1", "model_id": trained["model_id"], "tail": 50}).json()
    assert len(reg["rows"]) == 50 and reg["summary"]["current_label"]
    assert c.get("/internal/v1/models", headers=H).json()[0]["model_id"]


def test_missing_model_is_404_and_bad_path_rejected():
    c = TestClient(app)
    assert c.post("/internal/v1/predict", headers=H, json={"dataset_id": "ds1", "model_id": "nope"}).status_code == 404
    r = c.post("/internal/v1/data/validate", headers=H, json={"path": "../../etc/passwd"})
    assert r.status_code == 422


def test_upload_validate_commit_flow(ohlcv, tmp_path):
    f = config.UPLOAD_DIR / "t.csv"; ohlcv.iloc[:400].rename(columns={"timestamp": "Date", "close": "Closing_Price"}).to_csv(f, index=False)
    c = TestClient(app)
    rep = c.post("/internal/v1/data/validate", headers=H, json={"path": "uploads/t.csv"}).json()
    assert rep["supported"] and rep["mapping"]["close"] == "Closing_Price" and rep["status"] in ("PASS", "WARN")
    ok = c.post("/internal/v1/data/validate", headers=H, json={"path": "uploads/t.csv", "commit": True, "dataset_id": "up1"}).json()
    assert ok["dataset"]["rows"] == 400
    bad = config.UPLOAD_DIR / "x.csv"; pd.DataFrame({"a": [1, 2, 3], "b": [4, 5, 6]}).to_csv(bad, index=False)
    r = c.post("/internal/v1/data/validate", headers=H, json={"path": "uploads/x.csv"}).json()
    assert r["supported"] is False


def test_execution_timing_has_no_lookahead():
    idx = pd.RangeIndex(6); o = pd.Series([100, 100, 110, 121, 121, 121.0], index=idx)
    w = pd.Series([0, 1, 0, 0, 0, 0.0], index=idx)       # decided at close of candle 1 -> filled at open[2] = 110
    r = _strategy_returns(w, o, cost=0.0)
    assert np.isclose(r.iloc[1], 121 / 110 - 1) and r.iloc[0] == 0   # earns open[2]->open[3], not the move before the signal


def test_metrics_math():
    r = pd.Series([0.01, -0.02, 0.03, 0.0, 0.01]); w = pd.Series([1, 1, 1, 0, 1.0])
    m = portfolio_metrics(r, w, 365)
    assert np.isclose(m["cumulative_return"], np.prod(1 + r) - 1)
    assert m["max_drawdown"] <= 0 and m["n_trades"] == 2 and m["win_rate"] == 1.0


def test_backtest_runs_all_strategies_reproducibly(trained):
    req = {"assets": [{"dataset_id": "ds1", "model_id": trained["model_id"]}], "start": "2022-01-05", "initial_capital": 10000}
    a = run_backtest(req); b = run_backtest(req)
    assert set(a["aggregate"]) == set(STRATEGIES)
    assert any("clamped" in w for w in a["warnings"])            # in-sample start refused
    assert a["aggregate"] == b["aggregate"] and a["config_hash"] == b["config_hash"]
    assert sum(a["per_asset"]["ds1"]["decisions"].values()) > 50
    bh = a["aggregate"]["Buy and Hold"]; assert bh["exposure_avg"] > 0.99
    assert set(a["per_asset"]["ds1"]["forecast_metrics"]) >= {"xgboost", "rcte", "mean_reversion", "ragate_combined"}


def test_short_dataset_gives_clear_error(ohlcv):
    with pytest.raises(ValueError, match="too short"): train_models(ohlcv.iloc[:500], "tiny", "BTCUSDT")
