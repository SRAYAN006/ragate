import numpy as np, pandas as pd
from app.ragate import engine as rg
from app.risk.engine import evaluate_risk
from app.decision.engine import decide

CFG = rg.RagateConfig()
COMPAT = {e: {"1d": {"bull": .7, "range": .6, "stress": .3, "overall": .6}} for e in ("a", "b", "c")}


def fc(i, expert, pred, asof="2024-01-01", target="2024-01-02"):
    return {"id": f"{expert}{i}", "expert": expert, "horizon": "1d", "asof": asof, "target_end": target, "predicted_return": pred}


def test_weights_sum_to_one_nonnegative_and_handle_missing_experts():
    w, d = rg.compute_weights(["a", "b", "c"], {}, "1d", {"bull": .7, "range": .2, "stress": .1}, COMPAT, CFG)
    assert abs(sum(w.values()) - 1) < 1e-12 and all(v >= 0 for v in w.values())
    w2, _ = rg.compute_weights(["a"], {}, "1d", {"bull": 1, "range": 0, "stress": 0}, COMPAT, CFG)
    assert w2 == {"a": 1.0}
    assert rg.compute_weights([], {}, "1d", {}, COMPAT, CFG) == ({}, {})


def test_ewma_and_scoring_once():
    close = pd.Series([100.0, 110.0], index=pd.to_datetime(["2024-01-01", "2024-01-02"], utc=True))
    pend = [fc(1, "a", 0.0953)]
    matured, rest = rg.mature_forecasts(pend, close)
    assert len(matured) == 1 and np.isclose(matured[0]["actual_return"], np.log(1.1))
    st, scored = rg.score_matured({}, matured + matured, {"1d": 0.05}, {}, CFG)   # duplicate in same call
    assert len(scored) == 1 and st["a|1d"]["n"] == 1
    future = [fc(2, "a", 0.0, "2024-01-02", "2024-01-09")]
    assert rg.mature_forecasts(future, close)[0] == []                          # target not yet elapsed


def test_ewma_recursion():
    st, _ = rg.score_matured({}, [dict(fc(i, "a", 0.0, target=f"2024-01-0{i+1}"), actual_return=0.05) for i in range(3)],
                             {"1d": 0.05}, {}, CFG)
    assert np.isclose(st["a|1d"]["ewma"], 1.0)    # loss = 1 every time -> EWMA = 1
    # lower loss afterwards lowers EWMA
    st2, _ = rg.score_matured(st, [dict(fc(9, "a", 0.05, target="2024-02-01"), actual_return=0.05)], {"1d": 0.05}, {}, CFG)
    assert st2["a|1d"]["ewma"] < st["a|1d"]["ewma"]


def test_cusum_flags_persistent_deterioration_only():
    good = [dict(fc(i, "a", 0.05, target=f"2024-01-{i+1:02d}"), actual_return=0.05) for i in range(20)]
    st, _ = rg.score_matured({}, good, {"1d": 0.05}, {"a|1d": 0.3}, CFG)
    assert not st["a|1d"]["flagged"] and st["a|1d"]["cusum"] == 0
    bad = [dict(fc(100 + i, "a", 0.15, target=f"2024-02-{i+1:02d}"), actual_return=-0.05) for i in range(10)]
    st, _ = rg.score_matured(st, bad, {"1d": 0.05}, {"a|1d": 0.3}, CFG)
    assert st["a|1d"]["flagged"]


def test_deteriorating_expert_loses_weight():
    st = {"a|1d": {"ewma": 3.0, "n": 50, "cusum": 9.0, "flagged": True}, "b|1d": {"ewma": 0.3, "n": 50, "cusum": 0.0, "flagged": False}}
    w, _ = rg.compute_weights(["a", "b"], st, "1d", {"bull": 1, "range": 0, "stress": 0}, COMPAT, CFG)
    assert w["b"] > w["a"]


def test_combine_disagreement_and_uncertainty():
    outs = {"a": {"pred": 0.02, "sigma": 0.01}, "b": {"pred": -0.02, "sigma": 0.01}}
    c = rg.combine(outs, {"a": .5, "b": .5}, {"bull": .34, "range": .33, "stress": .33}, CFG)
    assert abs(c["combined_return"]) < 1e-12 and np.isclose(c["disagreement"], 0.02)
    agree = rg.combine({"a": {"pred": .02, "sigma": .01}, "b": {"pred": .02, "sigma": .01}}, {"a": .5, "b": .5}, {"bull": 1, "range": 0, "stress": 0}, CFG)
    assert agree["disagreement"] == 0 and agree["sigma_total"] < c["sigma_total"]


def test_evaluate_handles_unavailable_and_no_experts():
    close = pd.Series([1.0], index=pd.to_datetime(["2024-01-01"], utc=True))
    r = rg.evaluate({"horizon": "1d", "expert_outputs": [{"expert": "a", "pred": None}], "regime_probs": {"bull": 1, "range": 0, "stress": 0}}, close, {"compat": COMPAT})
    assert r["status"] == "no_experts"


def risk_in(**kw):
    base = {"asset": "BTCUSDT", "combined_return": 0.02, "sigma_total": 0.02, "disagreement": 0.002, "regime_probs": {"bull": .8, "range": .15, "stress": .05},
            "horizon_candles": 6, "periods_per_year": 2190, "current_weight": 0.0, "cash_fraction": 1.0}
    base.update(kw); return base


def test_risk_allows_good_signal_and_caps_exposure():
    r = evaluate_risk(risk_in())
    assert r["allowed_entry"] and 0 < r["target_weight"] <= 0.6
    assert r["net_return_entry"] < 0.02       # costs subtracted


def test_risk_vetoes_positive_forecast_when_costs_or_stress_dominate():
    assert not evaluate_risk(risk_in(combined_return=0.002))["allowed_entry"]            # eaten by costs
    r = evaluate_risk(risk_in(regime_probs={"bull": .1, "range": .1, "stress": .8}))
    assert not r["allowed_entry"] and "stress_probability" in r["failed_checks"]
    assert not evaluate_risk(risk_in(sigma_total=0.5))["allowed_entry"]                  # low signal-to-noise


def test_exposure_shrinks_with_uncertainty():
    lo = evaluate_risk(risk_in(sigma_total=0.02))["exposure_cap"]; hi = evaluate_risk(risk_in(sigma_total=0.05))["exposure_cap"]
    assert hi < lo


def _rg(mu=0.02, sig=0.02, status="ok", flagged=False):
    return {"status": status, "combined": {"combined_return": mu, "sigma_total": sig, "prob_positive": .8, "disagreement": 0.001}, "all_flagged": flagged}


def test_all_five_decisions():
    rp = {"bull": .8, "range": .15, "stress": .05}
    def go(rgres, cw=0.0, stale=False, rpx=rp, **k):
        risk = evaluate_risk(risk_in(combined_return=(rgres["combined"] or {}).get("combined_return", 0), sigma_total=(rgres["combined"] or {}).get("sigma_total", .02),
                                     current_weight=cw, cash_fraction=1 - cw, regime_probs=rpx)) if rgres["combined"] else None
        return decide(rgres, risk, cw, rpx, stale)
    assert go(_rg())["action"] == "BUY"
    assert go(_rg(mu=-0.03), cw=0.3)["action"] == "EXIT"
    assert go(_rg(mu=0.012, sig=0.03), cw=0.6)["action"] in ("REDUCE", "HOLD")
    assert go(_rg(), cw=0.0, stale=True)["action"] == "ABSTAIN"
    assert go(_rg(flagged=True))["action"] == "ABSTAIN"
    assert go({"status": "no_experts", "combined": None})["action"] == "ABSTAIN"
    assert go(_rg(mu=-0.01))["action"] == "HOLD"
    veto = go(_rg(mu=0.02), rpx={"bull": .1, "range": .1, "stress": .8})
    assert veto["action"] == "ABSTAIN" and any("risk" in r.lower() for r in veto["reasons"])
    assert any(go(_rg(mu=0.02, sig=0.02), cw=0.05)["action"] == a for a in ("BUY", "HOLD"))
