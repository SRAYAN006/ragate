@echo off
cd /d "%~dp0.."
call scripts\load_env.bat
if not exist backups mkdir backups
set STAMP=%date:~-4%%date:~3,2%%date:~0,2%_%time:~0,2%%time:~3,2%
set STAMP=%STAMP: =0%
docker exec ragate-db pg_dump -U %DB_USER% %DB_NAME% > backups\ragate_%STAMP%.sql && echo Backup written to backups\ragate_%STAMP%.sql
