@echo off
rem Loads KEY=VALUE pairs from ..\.env into the current process (skips comments and blanks).
if not exist "%~dp0..\.env" (
  copy "%~dp0..\.env.example" "%~dp0..\.env" >nul
  echo Created .env from .env.example. Edit it to change secrets.
)
for /f "usebackq eol=# tokens=1,* delims==" %%a in ("%~dp0..\.env") do if not "%%b"=="" set "%%a=%%b"
if "%RAGATE_STORAGE%"=="" set "RAGATE_STORAGE=%~dp0..\storage"
