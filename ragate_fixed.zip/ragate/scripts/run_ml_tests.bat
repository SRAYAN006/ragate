@echo off
cd /d "%~dp0..\ml-service"
call .venv\Scripts\activate.bat
python -m pytest tests -q
