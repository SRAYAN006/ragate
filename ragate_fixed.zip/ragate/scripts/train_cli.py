"""Train from the command line without the web UI:
   python scripts/train_cli.py --csv path\to\btc_4h.csv --symbol BTCUSDT --epochs 30
The CSV must contain timestamp/open/high/low/close (volume recommended); columns are auto-detected."""
import argparse, sys, pathlib, json
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1] / "ml-service"))
from app import config
from app.data import columns as cols
from app.training.pipeline import train_models

ap = argparse.ArgumentParser()
ap.add_argument("--csv", required=True); ap.add_argument("--symbol", required=True); ap.add_argument("--epochs", type=int, default=40)
ap.add_argument("--dataset-id", default="cli"); ap.add_argument("--dups", default="keep_last"); ap.add_argument("--missing", default="drop_rows")
a = ap.parse_args()
raw = cols.load_table(pathlib.Path(a.csv))
df, log = cols.clean(raw, cols.detect_columns(raw.columns), {"duplicates": a.dups, "missing_values": a.missing, "invalid_rows": "drop"})
print("cleaning log:", json.dumps(log))
cols.save_dataset(df, config.DATASET_DIR / f"{a.dataset_id}.csv")
meta = train_models(df, a.dataset_id, a.symbol.upper(), {"rcte": {"epochs": a.epochs}})
print("model_id:", meta["model_id"]); print(json.dumps(meta["metrics"]["test"], indent=2))
