@echo off
setlocal EnableExtensions
cd /d "%~dp0"
echo === RAGATE setup (run once) ===
call scripts\load_env.bat

where python >nul 2>&1 || (echo [ERROR] Python 3.11+ not found. Install Python 3.11 or 3.12 and tick Add to PATH. & exit /b 1)
where node   >nul 2>&1 || (echo [ERROR] Node.js 20+ not found. Install Node.js 20 LTS or later. & exit /b 1)
where java   >nul 2>&1 || (echo [ERROR] JDK 21+ not found. Install a JDK and add it to PATH. & exit /b 1)
where mvn    >nul 2>&1 || (echo [ERROR] Apache Maven 3.9+ not found. Install Maven and add it to PATH. & exit /b 1)
where docker >nul 2>&1 || (echo [ERROR] Docker Desktop not found. Install it and start it. & exit /b 1)

python -c "import sys; raise SystemExit(0 if (3,11) <= sys.version_info[:2] < (3,13) else 1)" || (echo [ERROR] Python 3.11 or 3.12 is required for the tested ML dependency set. & exit /b 1)
node -e "process.exit(Number(process.versions.node.split('.')[0]) >= 20 ? 0 : 1)" || (echo [ERROR] Node.js 20 or newer is required. & exit /b 1)

echo.
echo [1/4] Creating Python environment and installing ML dependencies...
if not exist ml-service\.venv python -m venv ml-service\.venv
call ml-service\.venv\Scripts\activate.bat
python -m pip install --upgrade pip || (echo [ERROR] Could not upgrade pip. & exit /b 1)
pip install -r ml-service\requirements.txt || (echo [ERROR] Python dependency installation failed. & exit /b 1)

echo.
echo [2/4] Installing frontend dependencies...
pushd frontend
call npm ci || (echo [ERROR] npm ci failed. & popd & exit /b 1)
popd

echo.
echo [3/4] Compiling and packaging the backend (this also verifies Lombok annotation processing)...
pushd backend
call mvn -U -DskipTests clean package || (echo [ERROR] Backend Maven build failed. See the first [ERROR] above. & popd & exit /b 1)
popd

echo.
echo [4/4] Starting PostgreSQL...
docker compose up -d db || (echo [ERROR] Docker failed. Is Docker Desktop running? & exit /b 1)
echo.
echo Setup complete. Run start.bat to launch RAGATE.
endlocal
