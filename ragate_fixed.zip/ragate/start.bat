@echo off
setlocal EnableExtensions
cd /d "%~dp0"
call scripts\load_env.bat
echo === Starting RAGATE ===

if not exist ml-service\.venv\Scripts\activate.bat (echo [ERROR] ML environment missing. Run setup.bat first. & exit /b 1)
if not exist frontend\node_modules (echo [ERROR] Frontend dependencies missing. Run setup.bat first. & exit /b 1)
if not exist backend\target\classes (echo [ERROR] Backend has not been built. Run setup.bat first. & exit /b 1)

docker compose up -d db || (echo [ERROR] Could not start PostgreSQL. Start Docker Desktop first. & exit /b 1)
echo Waiting for PostgreSQL...
set /a DB_TRIES=0
:waitdb
docker exec ragate-db pg_isready -U %DB_USER% -d %DB_NAME% >nul 2>&1
if not errorlevel 1 goto dbready
set /a DB_TRIES+=1
if %DB_TRIES% GEQ 30 (echo [ERROR] PostgreSQL did not become ready within 60 seconds. & exit /b 1)
timeout /t 2 >nul
goto waitdb
:dbready

start "RAGATE ML service :8000" cmd /k "cd /d ""%~dp0ml-service"" && call .venv\Scripts\activate.bat && uvicorn app.main:app --host 127.0.0.1 --port 8000"
timeout /t 3 >nul
start "RAGATE Backend :8080" cmd /k "cd /d ""%~dp0backend"" && mvn spring-boot:run"
timeout /t 3 >nul
start "RAGATE Frontend :5173" cmd /k "cd /d ""%~dp0frontend"" && npm run dev -- --host 127.0.0.1"

echo.
echo  Frontend : http://localhost:5173
echo  Backend  : http://localhost:8080
echo  ML docs  : http://localhost:8000/docs
echo.
echo Wait for the backend terminal to report Started RagateApplication before registering.
timeout /t 5 >nul
start http://localhost:5173
endlocal
