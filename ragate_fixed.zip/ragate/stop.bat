@echo off
cd /d "%~dp0"
echo Stopping RAGATE windows and database...
taskkill /FI "WINDOWTITLE eq RAGATE ML service*" /T /F >nul 2>&1
taskkill /FI "WINDOWTITLE eq RAGATE Backend*" /T /F >nul 2>&1
taskkill /FI "WINDOWTITLE eq RAGATE Frontend*" /T /F >nul 2>&1
docker compose stop db
echo Done. Data is kept in the Docker volume; use "docker compose down -v" only if you want to erase the database.
